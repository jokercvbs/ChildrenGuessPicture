//
//  MusicSwitch.m
//  ChildIdentifyPicture
//
//  Created by the9_15 on 12-3-5.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "MusicSwitch.h"

static MusicSwitch * configItem=nil;

@implementation MusicSwitch
@synthesize gameSoundState;

+(MusicSwitch *)shareConfig
{
	if (configItem==nil) 
	{
		configItem=[[MusicSwitch alloc] init];
	}
	return configItem;
}
@end
