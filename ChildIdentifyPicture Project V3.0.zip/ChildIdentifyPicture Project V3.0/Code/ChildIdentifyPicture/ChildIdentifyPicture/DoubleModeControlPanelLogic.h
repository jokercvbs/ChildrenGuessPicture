//
//  DoubleModeControlPanelLogic.h
//  ChildIdentifyPicture
//
//  Created by the9_15 on 12-3-9.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "DoubleModePlayGameScene.h"
#import "PlayGameMusic.h"

BOOL upHide;

int doubleModePictureInfoID;
NSMutableArray* doubleModeSaveRandomArray;
NSString *doubleModePlistPath;

@interface DoubleModeControlPanelLogic : CCNode 
{
	NSString* optionAString;
	NSString* optionBString;
	NSString* optionCString;
	NSString* optionDString;
}
-(void)controlPanelLabelInit;
-(void)controlPanelLabelUpdate:(int)spriteInfoNumber;
@end
