//
//  PopInfoLayer.m
//  ChildIdentifyPicture
//
//  Created by the9_15 on 12-2-28.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "PopInfoLayer.h"


@implementation PopInfoLayer
-(id) init
{
	if( (self=[super init])) 
	{
		CCSprite* infoFrame = [CCSprite spriteWithSpriteFrameName:@"Frame.png"];
		infoFrame.position = CGPointZero;
		[self addChild:infoFrame];
		
		CCSprite* info = [CCSprite spriteWithSpriteFrameName:@"Good.png"];
		info.position = CGPointZero;
		[self addChild:info z:2 tag:kFrameInfo];
	}
	return self;
}

- (void) dealloc
{
	[super dealloc];
}
@end
