//
//  HelloWorldLayer.m
//  ChildIdentifyPicture
//
//  Created by LXC on 12-2-18.
//  Copyright __MyCompanyName__ 2012年. All rights reserved.
//


#import "PlayGameScene.h"

@implementation PlayGameScene

+(CCScene *) scene
{
	CCScene *scene = [CCScene node];
	PlayGameScene *layer = [PlayGameScene node];
	[scene addChild: layer];
	return scene;
}

-(id) init
{
	if( (self=[super init])) 
	{
		winSize = [[CCDirector sharedDirector] winSize];
		[[CCScheduler sharedScheduler]setTimeScale:1.0];
		rightHide = NO;
		leftHide = NO;
		time=ROUND_TIME;
		[self playGameSceneUIInit];
		attenuation = 120.0f;
	}
	return self;
}

-(void)playGameSceneUIInit
{
	//游戏主场景背景加载
	playGameSceneBG = [CCSprite spriteWithSpriteFrameName:@"PlayGameSceneBG.png"];
	playGameSceneBG.position = ccp(winSize.width*0.5f,winSize.height*0.5f);
	[self addChild:playGameSceneBG];
	
	//黄色便签纸加载
	CCSprite* yellowPaper = [CCSprite spriteWithSpriteFrameName:@"Paper.png"];
	yellowPaper.position = ccp(523,358);
	[self addChild:yellowPaper];
	
	//红色小花加载
	CCSprite* redFlower = [CCSprite spriteWithSpriteFrameName:@"RedFlower.png"];
	redFlower.position = ccp(334,544);
	[self addChild:redFlower];
	
	//风车加载
	Windmill = [CCSprite spriteWithSpriteFrameName:@"Windmill2.png"];
	Windmill.position = ccp(176,754);
	[self addChild:Windmill];
	
	//水彩笔加载
	CCSprite* penOnly = [CCSprite spriteWithSpriteFrameName:@"PenOnly.png"];
	penOnly.position = ccp(797,20);
	penOnly.rotation = 45;
	[self addChild:penOnly];
	
	//橡皮加载
	CCSprite* eraser = [CCSprite spriteWithSpriteFrameName:@"Eraser.png"];
	eraser.position = ccp(545,161);
	eraser.rotation = -20;
	[self addChild:eraser];
	
	//右方玩家控制面板初始化
	rightControlPanel = [RightControlPanelUI node];
	rightControlPanel.position = ccp(winSize.width+223,winSize.height*0.5);
	rightControlPanel.rotation = -90;
	[self addChild:rightControlPanel];
	[rightPanel_leftHalf setIsTouchEnabled:NO];
	
	//左方玩家控制面板初始化
	leftControlPanel = [LeftControlPanelUI node];
	leftControlPanel.position = ccp(-223,winSize.height*0.5);
	leftControlPanel.rotation = 90;
	[self addChild:leftControlPanel];
	[leftPanel_rightHalf setIsTouchEnabled:NO];
	
	//右方花瓣初始化
	rightControlPanelYellowFlower = [CCSprite spriteWithSpriteFrameName:@"RightFlower-Yellow.png"];
	rightControlPanelYellowFlower.anchorPoint = ccp(0.5,1);
	rightControlPanelYellowFlower.scale = 0;
	rightControlPanelYellowFlower.position = ccp(995,342);
	[self addChild:rightControlPanelYellowFlower];
	
	rightControlPanelGreenFlower = [CCSprite spriteWithSpriteFrameName:@"RightFlower-Green.png"];
	rightControlPanelGreenFlower.anchorPoint = ccp(1, 0.65);
	rightControlPanelGreenFlower.scale = 0;
	rightControlPanelGreenFlower.position = ccp(989,353);
	[self addChild:rightControlPanelGreenFlower];
	
	rightControlPanelBlueFlower = [CCSprite spriteWithSpriteFrameName:@"RightFlower-Blue.png"];
	rightControlPanelBlueFlower.anchorPoint = ccp(1, 0.3);
	rightControlPanelBlueFlower.scale = 0;
	rightControlPanelBlueFlower.position = ccp(999,392);
	[self addChild:rightControlPanelBlueFlower];
	
	rightControlPanelPinkFlower = [CCSprite spriteWithSpriteFrameName:@"RightFlower-Pink.png"];
	rightControlPanelPinkFlower.anchorPoint = ccp(0.7, 0);
	rightControlPanelPinkFlower.scale = 0;
	rightControlPanelPinkFlower.position = ccp(1017,415);
	[self addChild:rightControlPanelPinkFlower];
	
	rightControlPanelCountBG = [CCSprite spriteWithSpriteFrameName:@"CircularScore.png"];
	rightControlPanelCountBG.position = ccp(winSize.width+223,380);
	rightControlPanelCountBG.scaleX = -1;
	[self addChild:rightControlPanelCountBG];
	
	leftControlPanelYellowFlower = [CCSprite spriteWithSpriteFrameName:@"LeftFlower-Yellow.png"];
	leftControlPanelYellowFlower.anchorPoint = ccp(0.5,0);
	leftControlPanelYellowFlower.scale = 0;
	leftControlPanelYellowFlower.position = ccp(30,425);
	[self addChild:leftControlPanelYellowFlower];
	
	leftControlPanelGreenFlower = [CCSprite spriteWithSpriteFrameName:@"LeftFlower-Green.png"];
	leftControlPanelGreenFlower.anchorPoint = ccp(0,0.3);
	leftControlPanelGreenFlower.scale = 0;
	leftControlPanelGreenFlower.position = ccp(40,404);
	[self addChild:leftControlPanelGreenFlower];
	
	leftControlPanelBlueFlower = [CCSprite spriteWithSpriteFrameName:@"LeftFlower-Blue.png"];
	leftControlPanelBlueFlower.anchorPoint = ccp(0, 0.7);
	leftControlPanelBlueFlower.scale = 0;
	leftControlPanelBlueFlower.position = ccp(23,365);
	[self addChild:leftControlPanelBlueFlower];
	
	leftControlPanelPinkFlower = [CCSprite spriteWithSpriteFrameName:@"LeftFlower-Pink.png"];
	leftControlPanelPinkFlower.anchorPoint = ccp(0.25, 1);
	leftControlPanelPinkFlower.scale = 0;
	leftControlPanelPinkFlower.position = ccp(3,346);
	[self addChild:leftControlPanelPinkFlower];
	
	leftControlPanelCountBG = [CCSprite spriteWithSpriteFrameName:@"CircularScore.png"];
	leftControlPanelCountBG.position = ccp(-223,380);
	[self addChild:leftControlPanelCountBG];
	
	//黑板初始化加载
	blackboard = [CCSprite spriteWithSpriteFrameName:@"Blackboard.png"];
	blackboard.position = ccp(521,389);
	blackboard.scale = 0;
	[self addChild:blackboard];
	
	//识别图片初始化
	identifyPicture = [CCSprite spriteWithSpriteFrameName:@"Things-Apple.png"];
	identifyPicture.position = ccp(winSize.width*0.5f,winSize.height*0.5f);
	identifyPicture.scale = 0;
	[self addChild:identifyPicture z:2];
	
	//返回主菜单按钮
	CCMenuItemSprite* goToMainSceneMenuItem = [CCMenuItemImage itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"GoToMainSceneNormalImage.png"]
											     selectedSprite:[CCSprite spriteWithSpriteFrameName:@"GoToMainSceneSelectedImage.png"]
													 target:self
												     selector:@selector(gotoMainMenuScene)];
	
	//游戏运行状态按钮按钮
	gamePauseMenuItem = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"GamePauseNormal.png"]
								  selectedSprite:[CCSprite spriteWithSpriteFrameName:@"GamePauseSelected.png"]];
	
	gameResumeMenuItem = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"GameResumeNormal.png"]
								   selectedSprite:[CCSprite spriteWithSpriteFrameName:@"GameResumeSelected.png"]];
	
	gameStateChange = [CCMenuItemToggle itemWithTarget:self 
								selector:@selector(gameRunStateChange)
								   items:gamePauseMenuItem,gameResumeMenuItem,nil];
	//游戏音乐
	gameMusicPlayMenuItem = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"SoundOnNormal.png"]
									selectedSprite:[CCSprite spriteWithSpriteFrameName:@"SoundOnSelected.png"]];
	
	gameMusicStopMenuItem = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"SoundOffNormal.png"]
									selectedSprite:[CCSprite spriteWithSpriteFrameName:@"SoundOffSelected.png"]];
	if ([MusicSwitch shareConfig].gameSoundState) 
	{
		gameMusicStateChange = [CCMenuItemToggle itemWithTarget:playGameMusic
									     selector:@selector(gameSoundStateChangeOn)
										  items:gameMusicPlayMenuItem,gameMusicStopMenuItem,nil];
	}
	else 
	{
		gameMusicStateChange = [CCMenuItemToggle itemWithTarget:playGameMusic
									     selector:@selector(gameSoundStateChangeOff)
										  items:gameMusicStopMenuItem,gameMusicPlayMenuItem,nil];
	}
	
	[gameStateChange setOpacity:0];
	gameStateChange.isEnabled = NO;
	CCMenu* UIMainMenu = [CCMenu menuWithItems:goToMainSceneMenuItem,gameStateChange,gameMusicStateChange,nil];
	[UIMainMenu alignItemsHorizontallyWithPadding:20];
	UIMainMenu.position = ccp(500,700);
	[self addChild:UIMainMenu];
	
	
	//游戏开始按钮
	CCMenuItemSprite* playGameMenuItem = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"GameStartNormal.png"]
											 selectedSprite:[CCSprite spriteWithSpriteFrameName:@"GameStartSelected.png"]
												   target:self 
												 selector:@selector(gameReady)];
	playGameMenu = [CCMenu menuWithItems:playGameMenuItem, nil];
	[playGameMenu setOpacity:0];
	[playGameMenu setIsTouchEnabled:NO];
	playGameMenu.position = ccp(winSize.width*0.5,winSize.height*0.5);
	[self addChild:playGameMenu];
	
	//右上方计时器背景初始化
	CCSprite* rightUpCornerClock = [CCSprite spriteWithSpriteFrameName:@"Clock.png"];
	rightUpCornerClock.position = ccp(830,642);
	rightUpCornerClock.rotation = -45;
	[self addChild:rightUpCornerClock];
	
	//左下方计时器背景初始化
	CCSprite* leftDownCornerClock = [CCSprite spriteWithSpriteFrameName:@"Clock.png"];
	leftDownCornerClock.position = ccp(214,135);
	leftDownCornerClock.rotation = 135;
	[self addChild:leftDownCornerClock];
	
	//右上方计时器Label初始化
	rightUpCornerClockLabel = [CCLabelTTF labelWithString:@"0:00" 
								   fontName:@"FZKaTong-M19S" 
								   fontSize:42];
	
	rightUpCornerClockLabel.position = ccp(829,647);
	rightUpCornerClockLabel.rotation = -50;
	[self addChild:rightUpCornerClockLabel];
	
	//左下方计时器Label初始化
	leftDownCornerClockLabel = [CCLabelTTF labelWithString:@"0:00"
								    fontName:@"FZKaTong-M19S" 
								    fontSize:42];
	
	leftDownCornerClockLabel.position = ccp(214,131);
	leftDownCornerClockLabel.rotation = 140;
	[self addChild:leftDownCornerClockLabel];
	
	//右方计分Label
	rightPlayerScoreCountLabel = [CCLabelTTF labelWithString:@"0"
									fontName:@"FZKaTong-M19S" 
									fontSize:45];
	rightPlayerScoreCountLabel.position = ccp(winSize.width+203,winSize.height*0.5);
	rightPlayerScoreCountLabel.rotation = -90;
	[self addChild:rightPlayerScoreCountLabel];
	id rightPlayerScoreCountLabelScale1 = [CCScaleTo actionWithDuration:1.0 scale:1.1];
	id rightPlayerScoreCountLabelScale4 = [CCScaleTo actionWithDuration:1.0 scaleX:0.8 scaleY:1.1];
	id rightPlayerScoreCountLabelScale3 = [CCScaleTo actionWithDuration:1.0 scale:0.8];
	id rightPlayerScoreCountLabelScale2 = [CCScaleTo actionWithDuration:1.0 scaleX:1.1 scaleY:0.8];
	id rightPlayerScoreCountLabelAction = [CCSequence actions:rightPlayerScoreCountLabelScale1,rightPlayerScoreCountLabelScale2,rightPlayerScoreCountLabelScale3,rightPlayerScoreCountLabelScale4,nil];
	id rightPlayerScoreCountLabelRepeat = [CCRepeatForever actionWithAction:rightPlayerScoreCountLabelAction];
	[rightPlayerScoreCountLabel runAction:rightPlayerScoreCountLabelRepeat];
	
	//左方计分Label
	leftPlayerScoreCountLabel = [CCLabelTTF labelWithString:@"0" 
								     fontName:@"FZKaTong-M19S" 
								     fontSize:45];
	leftPlayerScoreCountLabel.position = ccp(-203,winSize.height*0.5);
	[self addChild:leftPlayerScoreCountLabel];
	leftPlayerScoreCountLabel.rotation = 90;
	id leftPlayerScoreCountLabelScale1 = [CCScaleTo actionWithDuration:1.0 scale:1.1];
	id leftPlayerScoreCountLabelScale4 = [CCScaleTo actionWithDuration:1.0 scaleX:0.8 scaleY:1.1];
	id leftPlayerScoreCountLabelScale3 = [CCScaleTo actionWithDuration:1.0 scale:0.8];
	id leftPlayerScoreCountLabelScale2 = [CCScaleTo actionWithDuration:1.0 scaleX:1.1 scaleY:0.8];
	id leftPlayerScoreCountLabelAction = [CCSequence actions:leftPlayerScoreCountLabelScale1,leftPlayerScoreCountLabelScale2,leftPlayerScoreCountLabelScale3,leftPlayerScoreCountLabelScale4,nil];
	id leftPlayerScoreCountLabelRepeat = [CCRepeatForever actionWithAction:leftPlayerScoreCountLabelAction];
	[leftPlayerScoreCountLabel runAction:leftPlayerScoreCountLabelRepeat];
	
	popInfoLayer = [PopInfoLayer node];
	popInfoLayer.position = ccp(512,384);
	popInfoLayer.scale = 0;
	[self addChild:popInfoLayer z:3];
	
	readyLabelOne = [CCSprite spriteWithSpriteFrameName:@"One.png"];
	readyLabelOne.position = ccp(winSize.width*0.5,winSize.height*0.5);
	[readyLabelOne setOpacity:0];
	[self addChild:readyLabelOne];
	
	readyLabelTwo = [CCSprite spriteWithSpriteFrameName:@"Two.png"];
	readyLabelTwo.position = ccp(winSize.width*0.5,winSize.height*0.5);
	[readyLabelTwo setOpacity:0];
	[self addChild:readyLabelTwo];
	
	readyLabelThree = [CCSprite spriteWithSpriteFrameName:@"Three.png"];
	readyLabelThree.position = ccp(winSize.width*0.5,winSize.height*0.5);
	[readyLabelThree setOpacity:0];
	[self addChild:readyLabelThree];
}

-(void)gameRunStateChange
{
	[playGameMusic gameMenuClickSound];
	pauseState = YES;
	[self show];
}

//进场动画
-(void)PlayGameSceneUIAnimation
{
	//右方控制面板进场动画
	id rightControlDelay = [CCDelayTime actionWithDuration:1.0];
	id rightControlIntoScreen = [CCMoveTo actionWithDuration:1.0 position:ccp(winSize.width,winSize.height*0.5)];
	id rightControlAction = [CCSequence actions:rightControlDelay,rightControlIntoScreen,nil];
	[rightControlPanel runAction:rightControlAction];
	
	//右方计分背景
	id rightControlPanelCountBGDelay = [CCDelayTime actionWithDuration:1.0];
	id rightControlPanelCountBGIntoScreen = [CCMoveTo actionWithDuration:1.0 position:ccp(winSize.width,winSize.height*0.5-4)];
	id rightControlPanelCountBGAction = [CCSequence actions:rightControlPanelCountBGDelay,rightControlPanelCountBGIntoScreen,nil];
	[rightControlPanelCountBG runAction:rightControlPanelCountBGAction];
	
	//右方计分Label
	id rightControlPanelCountLabelDelay = [CCDelayTime actionWithDuration:1.0];
	id rightControlPanelCountLabelIntoScreen = [CCMoveTo actionWithDuration:1.0 position:ccp(winSize.width-20,winSize.height*0.5)];
	id rightControlPanelCountLabelAction = [CCSequence actions:rightControlPanelCountLabelDelay,rightControlPanelCountLabelIntoScreen,nil];
	[rightPlayerScoreCountLabel runAction:rightControlPanelCountLabelAction];
	
	//左方计分背景
	id leftControlPanelCountBGDealy = [CCDelayTime actionWithDuration:1.0];
	id leftControlPanelCountBGIntoScreen = [CCMoveTo actionWithDuration:1.0 position:ccp(0,winSize.height*0.5-4)];
	id leftControlPanelCountBGAction = [CCSequence actions:leftControlPanelCountBGDealy,leftControlPanelCountBGIntoScreen,nil];
	[leftControlPanelCountBG runAction:leftControlPanelCountBGAction];
	
	//左方计分Label
	id leftControlPanelCountLabelDelay = [CCDelayTime actionWithDuration:1.0];
	id leftControlPanelCountLabelIntoScreen = [CCMoveTo actionWithDuration:1.0 position:ccp(20,winSize.height*0.5)];
	id leftControlPanelCountLabelAction = [CCSequence actions:leftControlPanelCountLabelDelay,leftControlPanelCountLabelIntoScreen,nil];
	[leftPlayerScoreCountLabel runAction:leftControlPanelCountLabelAction];
	
	//左方控制面板进场动画
	id leftControlDelay = [CCDelayTime actionWithDuration:1.0];
	id leftControlIntoScreen = [CCMoveTo actionWithDuration:1.0 position:ccp(0,winSize.height*0.5)];
	id leftControlAction = [CCSequence actions:leftControlDelay,leftControlIntoScreen,nil];
	[leftControlPanel runAction:leftControlAction];
	
	//黑板进场动画
	id blackboardRotateIntoScreen = [CCRotateTo actionWithDuration:1.0 angle:1080];
	id blackboardScale = [CCScaleTo actionWithDuration:1.0 scale:1.0];
	id blackboardAction = [CCSpawn actions:blackboardRotateIntoScreen,blackboardScale,nil];
	[blackboard runAction:blackboardAction];
	
	//开始按钮进场动画
	id playGameMenuDelayTime1 = [CCDelayTime actionWithDuration:2.0];
	id playGameMenuIsTouchEnabledChange = [CCCallFunc actionWithTarget:self selector:@selector(playGameMenuIsTouchEnabledChangeFun)];
	id playGameMenuFadeInitIn = [CCFadeIn actionWithDuration:1.0];
	id playGameMenuAction = [CCSequence actions:playGameMenuDelayTime1,playGameMenuIsTouchEnabledChange,playGameMenuFadeInitIn,nil];
	[playGameMenu runAction:playGameMenuAction];
}

-(void)playGameMenuFadeAnimation
{
	id playGameMenuIsTouchEnabledChange = [CCCallFunc actionWithTarget:self selector:@selector(playGameMenuIsTouchEnabledChangeFun)];
	id playGameMenuFadeInitIn = [CCFadeIn actionWithDuration:1.0];
	id playGameMenuAction = [CCSequence actions:playGameMenuIsTouchEnabledChange,playGameMenuFadeInitIn,nil];
	[playGameMenu runAction:playGameMenuAction];
}

-(void)playGameMenuIsTouchEnabledChangeFun
{
	[playGameMenu setIsTouchEnabled:YES];
}

-(void)gameReady
{
	[playGameMusic gameMenuClickSound];
	rightRoundCount = 0;
	leftRoundCount = 0;
	rightControlPanelYellowFlower.scale = 0;
	rightControlPanelGreenFlower.scale = 0;
	rightControlPanelBlueFlower.scale = 0;
	rightControlPanelPinkFlower.scale = 0;
	leftControlPanelYellowFlower.scale = 0;
	leftControlPanelGreenFlower.scale = 0;
	leftControlPanelBlueFlower.scale = 0;
	leftControlPanelPinkFlower.scale = 0;
	
	//游戏开始按钮消退动画
	[playGameMenu setIsTouchEnabled:NO];
	[playGameMenu stopAllActions];
	id playGameMenuFadeOut = [CCFadeOut actionWithDuration:0.5];
	[playGameMenu runAction:[CCSequence actions:playGameMenuFadeOut,nil]];
	[self readyTime];
}

-(void)timeDown1Sound
{
	[playGameMusic timeDown1Sound];
}

-(void)timeDown2Sound
{
	[playGameMusic timeDown2Sound];
}

-(void)readyTime
{	
	id readyLabelThreeSound = [CCCallFunc actionWithTarget:self selector:@selector(timeDown2Sound)];
	id readyLabelThreeOpacityFadeIn = [CCFadeIn actionWithDuration:0.01];
	id readyLabelThreeOpacityFadeOut = [CCFadeOut actionWithDuration:0.01];
	id readyLabelThreeAction = [CCSequence actions:readyLabelThreeOpacityFadeIn,readyLabelThreeSound,[CCDelayTime actionWithDuration:1.0],readyLabelThreeOpacityFadeOut,nil];
	[readyLabelThree runAction:[CCSequence actions:[CCDelayTime actionWithDuration:0.5],readyLabelThreeAction,nil]];
	
	id readyLabelTwoSound = [CCCallFunc actionWithTarget:self selector:@selector(timeDown2Sound)];
	id readyLabelTwoOpacityFadeIn = [CCFadeIn actionWithDuration:0.01];
	id readyLabelTwoOpacityFadeOut = [CCFadeOut actionWithDuration:0.01];
	id readyLabelTwoAction = [CCSequence actions:readyLabelTwoOpacityFadeIn,readyLabelTwoSound,[CCDelayTime actionWithDuration:1.0],readyLabelTwoOpacityFadeOut,nil];
	[readyLabelTwo runAction:[CCSequence actions:[CCDelayTime actionWithDuration:1.5],readyLabelTwoAction,nil]];
	
	id readyLabelOneSound = [CCCallFunc actionWithTarget:self selector:@selector(timeDown1Sound)];
	id readyLabelOneOpacityFadeIn = [CCFadeIn actionWithDuration:0.01];
	id readyLabelOneOpacityFadeOut = [CCFadeOut actionWithDuration:0.01];
	id readyLabelOneAction = [CCSequence actions:readyLabelOneOpacityFadeIn,readyLabelOneSound,[CCDelayTime actionWithDuration:1.0],readyLabelOneOpacityFadeOut,nil];
	id gameStartCallFun = [CCCallFunc actionWithTarget:self selector:@selector(gameStart)];
	[readyLabelOne runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.5],readyLabelOneAction,gameStartCallFun,nil]];
}

//游戏开始附属回调方法
-(void)gameStart
{
	[rightControlPanelLogic rightControlPanelLabelInit];
	[leftControlPanelLogic leftControlPanelLabelInit];
	attenuation = 120.0f;
	time = ROUND_TIME;
	
	//计分归零
	[rightPlayerScoreCountLabel setString:[NSString stringWithFormat:@"%d",rightPlayerScoreCount=0]];
	[leftPlayerScoreCountLabel setString:[NSString stringWithFormat:@"%d",leftPlayerScoreCount=0]];
	
	//右方控制面板动画
	id rightPanelRotate = [CCRotateBy actionWithDuration:0.5 angle:180];
	id rightControlPanelCanTouchChange = [CCCallFunc actionWithTarget:self selector:@selector(rightControlPanelCanTouchChangeFun)];
	id leftHideChange = [CCCallFunc actionWithTarget:self selector:@selector(leftHideChangeFun)];
	id rightPanelActionSequence = [CCSequence actions:rightControlPanelCanTouchChange,leftHideChange,rightPanelRotate,nil];
	[rightControlPanel runAction:rightPanelActionSequence];
	
	//左方控制面板动画
	id leftPanelRotate = [CCRotateBy actionWithDuration:0.5 angle:180];
	id leftControlPanelCanTouchChange = [CCCallFunc actionWithTarget:self selector:@selector(leftControlPanelCanTouchChangeFun)];
	id rightHideChange = [CCCallFunc actionWithTarget:self selector:@selector(rightHideChangeFun)];
	id leftPanelActionSequence = [CCSequence actions:leftControlPanelCanTouchChange,rightHideChange,leftPanelRotate,nil];
	[leftControlPanel runAction:leftPanelActionSequence];
	
	//计时器启动
	[self schedule:@selector(timer) interval:1.0];
	
	//游戏暂停按钮进场动画
	id gamePauseMenuFadeIn = [CCFadeIn actionWithDuration:0.5];
	id gamePauseMenuEnableChange = [CCCallFunc actionWithTarget:self selector:@selector(gamePauseMenuEnableChangeFun1)];
	id gamePauseMenuAction = [CCSequence actions:gamePauseMenuEnableChange,gamePauseMenuFadeIn,nil];
	[gameStateChange runAction:gamePauseMenuAction];
	
	//识别图片旋转启动
	[self scheduleUpdate];
	
	//识别图片动画
	id identifyPictureScaleToLarge = [CCScaleTo actionWithDuration:1.0 scale:1.4];
	id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.4 scale:1.0];
	id identifyPictureSound = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureSoundFun)];
	id identifyPictureSequence = [CCSequence actions:identifyPictureScaleToLarge,identifyPictureSound,identifyPictureScaleToSmall, nil];
	[identifyPicture runAction:identifyPictureSequence];
}

-(void)identifyPictureSoundFun
{
	[playGameMusic thingsRotateInSound];
}

-(void)rightControlPanelCanTouchChangeFun
{
	leftHide
	?[rightPanel_leftHalf setIsTouchEnabled:YES]
	:[rightPanel_rightHalf setIsTouchEnabled:YES];
}

-(void)leftControlPanelCanTouchChangeFun
{
	rightHide
	?[leftPanel_rightHalf setIsTouchEnabled:YES]
	:[leftPanel_leftHalf setIsTouchEnabled:YES];
}

-(void)leftHideChangeFun
{
	if (leftHide)
		leftHide = NO;
	else
		leftHide = YES;
}

-(void)rightHideChangeFun
{
	if (rightHide)
		rightHide = NO;
	else
		rightHide = YES;
}

-(void)rightPanelToEmpty
{
	if (!leftHide)
	{
		[rightPanel_rightHalfLabel1 setString:@""];
		[rightPanel_rightHalfLabel2 setString:@""];
		[rightPanel_rightHalfLabel3 setString:@""];
		[rightPanel_rightHalfLabel4 setString:@""];
	}
	else
	{
		[rightPanel_leftHalfLabel1 setString:@""];
		[rightPanel_leftHalfLabel2 setString:@""];
		[rightPanel_leftHalfLabel3 setString:@""];
		[rightPanel_leftHalfLabel4 setString:@""];
	}
}

-(void)leftPanelToEmpty
{
	if (!rightHide) 
	{
		[leftPanel_leftHalfLabel1 setString:@""];
		[leftPanel_leftHalfLabel2 setString:@""];
		[leftPanel_leftHalfLabel3 setString:@""];
		[leftPanel_leftHalfLabel4 setString:@""];
	}
	else
	{
		[leftPanel_rightHalfLabel1 setString:@""];
		[leftPanel_rightHalfLabel2 setString:@""];
		[leftPanel_rightHalfLabel3 setString:@""];
		[leftPanel_rightHalfLabel4 setString:@""];
	}
}

//暂停按钮可点击状态切换附属回调方法
-(void)gamePauseMenuEnableChangeFun1
{
	gameStateChange.isEnabled = YES;
}

-(void)gamePauseMenuEnableChangeFun2
{
	gameStateChange.isEnabled = NO;
}
//旋转帧频事件
- (void)update:(ccTime)delta
{
	++Windmill.rotation;
	if (attenuation>2) 
	{
		identifyPicture.rotation += attenuation;
		attenuation *= 0.99f;
	}
	else
		identifyPicture.rotation += 2;
}

//计时器事件
-(void)timer
{
	--time;
	if (time>=0) 
	{
		if (time<=4)
		{
			[playGameMusic finalFiveSecondSound];
		}
		[rightUpCornerClockLabel setString:[NSString stringWithFormat:@"0:%02d",time]];
		[leftDownCornerClockLabel setString:[NSString stringWithFormat:@"0:%02d",time]];
	}
	else 
	{
		id gamePauseMenuFadeOut = [CCFadeOut actionWithDuration:0.5];
		id gamePauseMenuEnableChange = [CCCallFunc actionWithTarget:self selector:@selector(gamePauseMenuEnableChangeFun2)];
		id gamePauseMenuAction = [CCSequence actions:gamePauseMenuEnableChange,gamePauseMenuFadeOut,nil];
		[gameStateChange runAction:gamePauseMenuAction];
		
		[self unschedule:@selector(timer)];
		CCSprite* flower = nil;
		[rightPanel_leftHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]];
		[rightPanel_leftHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]];
		[rightPanel_leftHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]];
		[rightPanel_leftHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]];
		[rightPanel_rightHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]];
		[rightPanel_rightHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]];
		[rightPanel_rightHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]];
		[rightPanel_rightHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]];
		[rightPanel_leftHalfMenuItem1 setIsEnabled:NO];
		[rightPanel_leftHalfMenuItem2 setIsEnabled:NO];
		[rightPanel_leftHalfMenuItem3 setIsEnabled:NO];
		[rightPanel_leftHalfMenuItem4 setIsEnabled:NO];
		[rightPanel_rightHalfMenuItem1 setIsEnabled:NO];
		[rightPanel_rightHalfMenuItem2 setIsEnabled:NO];
		[rightPanel_rightHalfMenuItem3 setIsEnabled:NO];
		[rightPanel_rightHalfMenuItem4 setIsEnabled:NO];
		
		[leftPanel_leftHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]];
		[leftPanel_leftHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]];
		[leftPanel_leftHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]];
		[leftPanel_leftHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]];
		[leftPanel_rightHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]];
		[leftPanel_rightHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]];
		[leftPanel_rightHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]];
		[leftPanel_rightHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]];
		[leftPanel_leftHalfMenuItem1 setIsEnabled:NO];
		[leftPanel_leftHalfMenuItem2 setIsEnabled:NO];
		[leftPanel_leftHalfMenuItem3 setIsEnabled:NO];
		[leftPanel_leftHalfMenuItem4 setIsEnabled:NO];
		[leftPanel_rightHalfMenuItem1 setIsEnabled:NO];
		[leftPanel_rightHalfMenuItem2 setIsEnabled:NO];
		[leftPanel_rightHalfMenuItem3 setIsEnabled:NO];
		[leftPanel_rightHalfMenuItem4 setIsEnabled:NO];
		
		id leftControlPanelRotate = [CCRotateBy actionWithDuration:1.0 angle:180];
		id rightControlPanelRotate = [CCRotateBy actionWithDuration:1.0 angle:180];
		
		id leftHideChange = [CCCallFunc actionWithTarget:self selector:@selector(leftHideChangeFun)];
		id rightHideChange = [CCCallFunc actionWithTarget:self selector:@selector(rightHideChangeFun)];
		
		id leftPanelEmpty = [CCCallFunc actionWithTarget:self selector:@selector(leftPanelToEmpty)];
		id rightPanelEmpty = [CCCallFunc actionWithTarget:self selector:@selector(rightPanelToEmpty)];
		
		id leftControlPanelActionSequence = [CCSequence actions:leftPanelEmpty,rightHideChange,leftControlPanelRotate,nil];
		id rightControlPanelActionSequence = [CCSequence actions:rightPanelEmpty,leftHideChange,rightControlPanelRotate,nil];
		if (![leftControlPanel numberOfRunningActions])
		{
			[leftControlPanel runAction:leftControlPanelActionSequence];
			[rightControlPanel runAction:rightControlPanelActionSequence];
		}
		else 
		{
			[self schedule:@selector(frameTestPanelActionStop)];
		}
		//右方大于左方
		if(rightPlayerScoreCount>leftPlayerScoreCount)
		{
			[playGameMusic starSound];
			rightControlPanelParticle = [ARCH_OPTIMAL_PARTICLE_SYSTEM particleWithFile:@"RightWinParticle.plist"];
			rightControlPanelParticle.position = ccp(winSize.width,winSize.height*0.5);
			rightControlPanelParticle.autoRemoveOnFinish=YES;
			[self addChild:rightControlPanelParticle];
			switch (rightRoundCount)
			{
				case kRoundOne:
					flower = rightControlPanelYellowFlower;
					break;
				case kRoundTwo:
					flower = rightControlPanelGreenFlower;
					break;
				case kRoundThree:
					flower = rightControlPanelBlueFlower;
					break;
				case kRoundFour:
					flower = rightControlPanelPinkFlower;
					break;
				default:
					break;
			}
			id action1 = [CCScaleTo actionWithDuration:0.2 scale:1.5];
			id action2 = [CCScaleTo actionWithDuration:0.1 scale:1.0];
			id action3 = [CCSequence actions:action1,action2,nil];
			[flower runAction:action3];
			if (rightRoundCount<3)
			{
				++rightRoundCount;
				time = ROUND_TIME;
				
				id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:1.0 scale:0];
				id nextRoundReadyAction = [CCSequence actions:identifyPictureScaleToSmall,nil];
				[identifyPicture runAction:nextRoundReadyAction];
				
				popInfoLayer.position = ccp(winSize.width*0.5,winSize.height*0.5);
				id popInfoScaleToLarge = [CCScaleTo actionWithDuration:0.6 scale:1.2];
				[playGameMusic infoLayerSound];
				id popInfoScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
				id popInfoDelayTime = [CCDelayTime actionWithDuration:1.0];
				id popInfoEndisableScale = [CCScaleTo actionWithDuration:0.6 scale:0];
				id popInfoMoveTo = [CCMoveTo actionWithDuration:0.6 position:ccp(winSize.width+popInfoLayer.contentSize.width*0.5,winSize.height*0.5)];
				id popInfoSpawn = [CCSpawn actions:popInfoEndisableScale,popInfoMoveTo,nil];
				id readyTimeDown = [CCCallFunc actionWithTarget:self selector:@selector(readyTime)]; 
				id nextRound = [CCCallFunc actionWithTarget:self selector:@selector(gotoNextRound)];
				id popInfoSequence = [CCSequence actions:popInfoScaleToLarge,popInfoScaleToSmall,popInfoDelayTime,popInfoSpawn,nextRound,readyTimeDown,nil];
				CCSprite* popInfoLayerInfo = (CCSprite*)[popInfoLayer getChildByTag:kFrameInfo];
				[popInfoLayerInfo setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"Clever.png"]];
				[popInfoLayer runAction:popInfoSequence];
			}
			else 
			{
				id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:1.0 scale:0];
				id nextRoundReadyAction = [CCSequence actions:identifyPictureScaleToSmall,nil];
				[identifyPicture runAction:nextRoundReadyAction];
				
				id playGameMenuIsTouchEnabledChange = [CCCallFunc actionWithTarget:self selector:@selector(playGameMenuIsTouchEnabledChangeFun)];
				id playGameMenuFadeInitIn = [CCFadeIn actionWithDuration:1.0];
				id playGameMenuRepeat = [CCCallFunc actionWithTarget:self selector:@selector(playGameMenuFadeAnimation)];
				id nextRound = [CCCallFunc actionWithTarget:self selector:@selector(gotoNextRound)];
				id playGameMenuAction = [CCSequence actions:nextRound,playGameMenuIsTouchEnabledChange,playGameMenuFadeInitIn,playGameMenuRepeat,nil];
				
				popInfoLayer.position = ccp(winSize.width*0.5,winSize.height*0.5);
				[playGameMusic infoLayerSound];
				id popInfoScaleToLarge = [CCScaleTo actionWithDuration:0.6 scale:1.2];
				id popInfoScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
				id popInfoDelayTime = [CCDelayTime actionWithDuration:1.0];
				id popInfoEndisableScale = [CCScaleTo actionWithDuration:0.6 scale:0];
				id popInfoMoveTo = [CCMoveTo actionWithDuration:0.6 position:ccp(winSize.width+popInfoLayer.contentSize.width*0.5,winSize.height*0.5)];
				id popInfoSpawn = [CCSpawn actions:popInfoEndisableScale,popInfoMoveTo,nil];
				id popInfoSequence = [CCSequence actions:popInfoScaleToLarge,popInfoScaleToSmall,popInfoDelayTime,popInfoSpawn,playGameMenuAction,nil];
				CCSprite* popInfoLayerInfo = (CCSprite*)[popInfoLayer getChildByTag:kFrameInfo];
				[popInfoLayerInfo setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"Good.png"]];
				[popInfoLayer runAction:popInfoSequence];
			}
		}
		//左方大于右方
		else if(rightPlayerScoreCount<leftPlayerScoreCount)
		{
			[playGameMusic starSound];
			leftControlPanelParticle = [ARCH_OPTIMAL_PARTICLE_SYSTEM particleWithFile:@"LeftWinParticle.plist"];
			leftControlPanelParticle.position = ccp(0,winSize.height*0.5);
			leftControlPanelParticle.autoRemoveOnFinish=YES;
			[self addChild:leftControlPanelParticle];
			switch (leftRoundCount)
			{
				case kRoundOne:
					flower = leftControlPanelYellowFlower;
					break;
				case kRoundTwo:
					flower = leftControlPanelGreenFlower;
					break;
				case kRoundThree:
					flower = leftControlPanelBlueFlower;
					break;
				case kRoundFour:
					flower = leftControlPanelPinkFlower;
					break;
				default:
					break;
			}
			
			id action1 = [CCScaleTo actionWithDuration:0.2 scale:1.5];
			id action2 = [CCScaleTo actionWithDuration:0.1 scale:1.0];
			id action3 = [CCSequence actions:action1,action2,nil];
			[flower runAction:action3];
			if (leftRoundCount<3)
			{
				++leftRoundCount;
				time = ROUND_TIME;
				
				id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:1.0 scale:0];
				id nextRoundReadyAction = [CCSequence actions:identifyPictureScaleToSmall,nil];
				[identifyPicture runAction:nextRoundReadyAction];
				[playGameMusic infoLayerSound];
				popInfoLayer.position = ccp(winSize.width*0.5,winSize.height*0.5);
				id popInfoScaleToLarge = [CCScaleTo actionWithDuration:0.6 scale:1.2];
				id popInfoScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
				id popInfoDelayTime = [CCDelayTime actionWithDuration:1.0];
				id popInfoEndisableScale = [CCScaleTo actionWithDuration:0.6 scale:0];
				id popInfoMoveTo = [CCMoveTo actionWithDuration:0.6 position:ccp(-popInfoLayer.contentSize.width*0.5,winSize.height*0.5)];
				id popInfoSpawn = [CCSpawn actions:popInfoEndisableScale,popInfoMoveTo,nil];
				id readyTimeDown = [CCCallFunc actionWithTarget:self selector:@selector(readyTime)]; 
				id nextRound = [CCCallFunc actionWithTarget:self selector:@selector(gotoNextRound)];
				id popInfoSequence = [CCSequence actions:popInfoScaleToLarge,popInfoScaleToSmall,popInfoDelayTime,popInfoSpawn,nextRound,readyTimeDown,nil];
				CCSprite* popInfoLayerInfo = (CCSprite*)[popInfoLayer getChildByTag:kFrameInfo];
				[popInfoLayerInfo setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"Clever.png"]];
				[popInfoLayer runAction:popInfoSequence];
			}
			else 
			{
				id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:1.0 scale:0];
				id nextRoundReadyAction = [CCSequence actions:identifyPictureScaleToSmall,nil];
				[identifyPicture runAction:nextRoundReadyAction];
				
				id playGameMenuIsTouchEnabledChange = [CCCallFunc actionWithTarget:self selector:@selector(playGameMenuIsTouchEnabledChangeFun)];
				id playGameMenuFadeInitIn = [CCFadeIn actionWithDuration:1.0];
				id playGameMenuRepeat = [CCCallFunc actionWithTarget:self selector:@selector(playGameMenuFadeAnimation)];
				id nextRound = [CCCallFunc actionWithTarget:self selector:@selector(gotoNextRound)];
				id playGameMenuAction = [CCSequence actions:nextRound,playGameMenuIsTouchEnabledChange,playGameMenuFadeInitIn,playGameMenuRepeat,nil];
				[playGameMusic infoLayerSound];
				popInfoLayer.position = ccp(winSize.width*0.5,winSize.height*0.5);
				id popInfoScaleToLarge = [CCScaleTo actionWithDuration:0.6 scale:1.2];
				id popInfoScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
				id popInfoDelayTime = [CCDelayTime actionWithDuration:1.0];
				id popInfoEndisableScale = [CCScaleTo actionWithDuration:0.6 scale:0];
				id popInfoMoveTo = [CCMoveTo actionWithDuration:0.6 position:ccp(-popInfoLayer.contentSize.width*0.5,winSize.height*0.5)];
				id popInfoSpawn = [CCSpawn actions:popInfoEndisableScale,popInfoMoveTo,nil];
				id popInfoSequence = [CCSequence actions:popInfoScaleToLarge,popInfoScaleToSmall,popInfoDelayTime,popInfoSpawn,playGameMenuAction,nil];
				CCSprite* popInfoLayerInfo = (CCSprite*)[popInfoLayer getChildByTag:kFrameInfo];
				[popInfoLayerInfo setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"Good.png"]];
				[popInfoLayer runAction:popInfoSequence];
			}
		}
		//比分相同
		else 
		{
			[playGameMusic starSound];
			rightControlPanelParticle = [ARCH_OPTIMAL_PARTICLE_SYSTEM particleWithFile:@"RightWinParticle.plist"];
			rightControlPanelParticle.position = ccp(winSize.width,winSize.height*0.5);
			rightControlPanelParticle.autoRemoveOnFinish=YES;
			[self addChild:rightControlPanelParticle];
			leftControlPanelParticle = [ARCH_OPTIMAL_PARTICLE_SYSTEM particleWithFile:@"LeftWinParticle.plist"];
			leftControlPanelParticle.position = ccp(0,winSize.height*0.5);
			leftControlPanelParticle.autoRemoveOnFinish=YES;
			[self addChild:leftControlPanelParticle];
			
			CCSprite* flower = nil;
			switch (rightRoundCount)
			{
				case kRoundOne:
					flower = rightControlPanelYellowFlower;
					break;
				case kRoundTwo:
					flower = rightControlPanelGreenFlower;
					break;
				case kRoundThree:
					flower = rightControlPanelBlueFlower;
					break;
				case kRoundFour:
					flower = rightControlPanelPinkFlower;
					break;
				default:
					break;
			}
			id rightAction1 = [CCScaleTo actionWithDuration:0.2 scale:1.5];
			id rightAction2 = [CCScaleTo actionWithDuration:0.1 scale:1.0];
			id rightAction3 = [CCSequence actions:rightAction1,rightAction2,nil];
			[flower runAction:rightAction3];
			
			switch (leftRoundCount)
			{
				case kRoundOne:
					flower = leftControlPanelYellowFlower;
					break;
				case kRoundTwo:
					flower = leftControlPanelGreenFlower;
					break;
				case kRoundThree:
					flower = leftControlPanelBlueFlower;
					break;
				case kRoundFour:
					flower = leftControlPanelPinkFlower;
					break;
				default:
					break;
			}
			
			id leftAction1 = [CCScaleTo actionWithDuration:0.2 scale:1.5];
			id leftAction2 = [CCScaleTo actionWithDuration:0.1 scale:1.0];
			id leftAction3 = [CCSequence actions:leftAction1,leftAction2,nil];
			[flower runAction:leftAction3];
			if (leftRoundCount<3 && rightRoundCount<3)
			{
				++leftRoundCount;
				++rightRoundCount;
				time = ROUND_TIME;
				
				id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:1.0 scale:0];
				id nextRoundReadyAction = [CCSequence actions:identifyPictureScaleToSmall,nil];
				[identifyPicture runAction:nextRoundReadyAction];
				
				popInfoLayer.position = ccp(winSize.width*0.5,winSize.height*0.5);
				id popInfoScaleToLarge = [CCScaleTo actionWithDuration:0.6 scale:1.2];
				id popInfoScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
				id popInfoDelayTime = [CCDelayTime actionWithDuration:1.0];
				id popInfoEndisableScale = [CCScaleTo actionWithDuration:0.6 scale:0];
				id popInfoSpawn = [CCSpawn actions:popInfoEndisableScale,nil];
				id readyTimeDown = [CCCallFunc actionWithTarget:self selector:@selector(readyTime)]; 
				id nextRound = [CCCallFunc actionWithTarget:self selector:@selector(gotoNextRound)];
				[playGameMusic infoLayerSound];
				id popInfoSequence = [CCSequence actions:popInfoScaleToLarge,popInfoScaleToSmall,popInfoDelayTime,popInfoSpawn,nextRound,readyTimeDown,nil];
				CCSprite* popInfoLayerInfo = (CCSprite*)[popInfoLayer getChildByTag:kFrameInfo];
				[popInfoLayerInfo setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"Clever.png"]];
				[popInfoLayer runAction:popInfoSequence];
			}
			else
			{
				if(leftRoundCount==3&&rightRoundCount==3)
				{
					id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:1.0 scale:0];
					id nextRoundReadyAction = [CCSequence actions:identifyPictureScaleToSmall,nil];
					[identifyPicture runAction:nextRoundReadyAction];
					
					id playGameMenuIsTouchEnabledChange = [CCCallFunc actionWithTarget:self selector:@selector(playGameMenuIsTouchEnabledChangeFun)];
					id playGameMenuFadeInitIn = [CCFadeIn actionWithDuration:1.0];
					id playGameMenuRepeat = [CCCallFunc actionWithTarget:self selector:@selector(playGameMenuFadeAnimation)];
					id nextRound = [CCCallFunc actionWithTarget:self selector:@selector(gotoNextRound)];
					id playGameMenuAction = [CCSequence actions:nextRound,playGameMenuIsTouchEnabledChange,playGameMenuFadeInitIn,playGameMenuRepeat,nil];
					
					popInfoLayer.position = ccp(winSize.width*0.5,winSize.height*0.5);
					id popInfoScaleToLarge = [CCScaleTo actionWithDuration:0.6 scale:1.2];
					id popInfoScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
					id popInfoDelayTime = [CCDelayTime actionWithDuration:1.0];
					id popInfoEndisableScale = [CCScaleTo actionWithDuration:0.6 scale:0];
					id popInfoSpawn = [CCSpawn actions:popInfoEndisableScale,nil];
					[playGameMusic infoLayerSound];
					id popInfoSequence = [CCSequence actions:popInfoScaleToLarge,popInfoScaleToSmall,popInfoDelayTime,popInfoSpawn,playGameMenuAction,nil];
					CCSprite* popInfoLayerInfo = (CCSprite*)[popInfoLayer getChildByTag:kFrameInfo];
					[popInfoLayerInfo setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"Good.png"]];
					[popInfoLayer runAction:popInfoSequence];
				}
				else if(leftRoundCount == 3)
				{
					id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:1.0 scale:0];
					id nextRoundReadyAction = [CCSequence actions:identifyPictureScaleToSmall,nil];
					[identifyPicture runAction:nextRoundReadyAction];
					
					id playGameMenuIsTouchEnabledChange = [CCCallFunc actionWithTarget:self selector:@selector(playGameMenuIsTouchEnabledChangeFun)];
					id playGameMenuFadeInitIn = [CCFadeIn actionWithDuration:1.0];
					id playGameMenuRepeat = [CCCallFunc actionWithTarget:self selector:@selector(playGameMenuFadeAnimation)];
					id nextRound = [CCCallFunc actionWithTarget:self selector:@selector(gotoNextRound)];
					id playGameMenuAction = [CCSequence actions:nextRound,playGameMenuIsTouchEnabledChange,playGameMenuFadeInitIn,playGameMenuRepeat,nil];
					
					popInfoLayer.position = ccp(winSize.width*0.5,winSize.height*0.5);
					id popInfoScaleToLarge = [CCScaleTo actionWithDuration:0.6 scale:1.2];
					id popInfoScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
					id popInfoDelayTime = [CCDelayTime actionWithDuration:1.0];
					id popInfoEndisableScale = [CCScaleTo actionWithDuration:0.6 scale:0];
					id popInfoMoveTo = [CCMoveTo actionWithDuration:0.6 position:ccp(-popInfoLayer.contentSize.width*0.5,winSize.height*0.5)];
					id popInfoSpawn = [CCSpawn actions:popInfoEndisableScale,popInfoMoveTo,nil];
					[playGameMusic infoLayerSound];
					id popInfoSequence = [CCSequence actions:popInfoScaleToLarge,popInfoScaleToSmall,popInfoDelayTime,popInfoSpawn,playGameMenuAction,nil];
					CCSprite* popInfoLayerInfo = (CCSprite*)[popInfoLayer getChildByTag:kFrameInfo];
					[popInfoLayerInfo setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"Good.png"]];
					[popInfoLayer runAction:popInfoSequence];
				}
				else
				{
					id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:1.0 scale:0];
					id nextRoundReadyAction = [CCSequence actions:identifyPictureScaleToSmall,nil];
					[identifyPicture runAction:nextRoundReadyAction];
					
					id playGameMenuIsTouchEnabledChange = [CCCallFunc actionWithTarget:self selector:@selector(playGameMenuIsTouchEnabledChangeFun)];
					id playGameMenuFadeInitIn = [CCFadeIn actionWithDuration:1.0];
					id playGameMenuRepeat = [CCCallFunc actionWithTarget:self selector:@selector(playGameMenuFadeAnimation)];
					id nextRound = [CCCallFunc actionWithTarget:self selector:@selector(gotoNextRound)];
					id playGameMenuAction = [CCSequence actions:nextRound,playGameMenuIsTouchEnabledChange,playGameMenuFadeInitIn,playGameMenuRepeat,nil];
					
					popInfoLayer.position = ccp(winSize.width*0.5,winSize.height*0.5);
					id popInfoScaleToLarge = [CCScaleTo actionWithDuration:0.6 scale:1.2];
					id popInfoScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
					id popInfoDelayTime = [CCDelayTime actionWithDuration:1.0];
					id popInfoEndisableScale = [CCScaleTo actionWithDuration:0.6 scale:0];
					id popInfoMoveTo = [CCMoveTo actionWithDuration:0.6 position:ccp(winSize.width+popInfoLayer.contentSize.width*0.5,winSize.height*0.5)];
					id popInfoSpawn = [CCSpawn actions:popInfoEndisableScale,popInfoMoveTo,nil];
					[playGameMusic infoLayerSound];
					id popInfoSequence = [CCSequence actions:popInfoScaleToLarge,popInfoScaleToSmall,popInfoDelayTime,popInfoSpawn,playGameMenuAction,nil];
					CCSprite* popInfoLayerInfo = (CCSprite*)[popInfoLayer getChildByTag:kFrameInfo];
					[popInfoLayerInfo setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"Good.png"]];
					[popInfoLayer runAction:popInfoSequence];
				}
			}
			time = ROUND_TIME;
		}
	}
}

-(void)frameTestPanelActionStop
{
	if([rightControlPanel numberOfRunningActions]==0)
	{
		[self unschedule:@selector(frameTestPanelActionStop)];
		id leftControlPanelRotate = [CCRotateBy actionWithDuration:0.5 angle:180];
		id rightControlPanelRotate = [CCRotateBy actionWithDuration:0.5 angle:180];
		id leftHideChange = [CCCallFunc actionWithTarget:self selector:@selector(leftHideChangeFun)];
		id rightHideChange = [CCCallFunc actionWithTarget:self selector:@selector(rightHideChangeFun)];
		
		id leftPanelEmpty = [CCCallFunc actionWithTarget:self selector:@selector(leftPanelToEmpty)];
		id rightPanelEmpty = [CCCallFunc actionWithTarget:self selector:@selector(rightPanelToEmpty)];
		
		id leftControlPanelActionSequence = [CCSequence actions:leftPanelEmpty,rightHideChange,leftControlPanelRotate,nil];
		id rightControlPanelActionSequence = [CCSequence actions:rightPanelEmpty,leftHideChange,rightControlPanelRotate,nil];
		[leftControlPanel runAction:leftControlPanelActionSequence];
		[rightControlPanel runAction:rightControlPanelActionSequence];
		
		id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:1.0 scale:0];
		id nextRoundReadyAction = [CCSequence actions:identifyPictureScaleToSmall,nil];
		[identifyPicture runAction:nextRoundReadyAction];
	}
}

-(void)gotoNextRound
{
	[self unscheduleUpdate];
}

-(void)show
{
	CCRenderTexture* renderTexture = [CCRenderTexture renderTextureWithWidth:winSize.width height:winSize.height];        
	[renderTexture begin];
	[self visit];
	[renderTexture end];
	[renderTexture setPosition:ccp(winSize.width*0.5, winSize.height*0.5)];        
	CCScene* pauseScene = [CCScene node];
	CCLayerColor* colorLayer = [CCLayerColor layerWithColor:ccc4(0, 0, 0, 200)];
	[pauseScene addChild:renderTexture];
	[pauseScene addChild:colorLayer z:1 tag:1];
	[pauseScene addChild:[GamePauseScene scene] z:2 tag:2];
	[[CCDirector sharedDirector] pushScene:pauseScene];
}

-(void)gotoMainMenuScene
{
	[playGameMusic gameMenuClickSound];
	pauseState = NO;
	[[CCDirector sharedDirector] replaceScene: [CCTransitionFade transitionWithDuration:1.6f 
														scene:[MainMenuScene scene] 
													  withColor:ccBLACK]];
}

-(void) onEnterTransitionDidFinish
{
	if(!pauseState)
		[self PlayGameSceneUIAnimation];
	else 
		[gameStateChange setSelectedIndex:0];

	[super onEnterTransitionDidFinish];
}

- (void) dealloc
{
	[super dealloc];
}

@end