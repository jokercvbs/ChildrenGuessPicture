//
//  DoubleModeGamePauseScene.h
//  ChildIdentifyPicture
//
//  Created by the9_15 on 12-3-19.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "MainMenuScene.h"
@interface DoubleModeGamePauseScene : CCLayer 
{
	
}

+(CCScene *) scene;
@end
