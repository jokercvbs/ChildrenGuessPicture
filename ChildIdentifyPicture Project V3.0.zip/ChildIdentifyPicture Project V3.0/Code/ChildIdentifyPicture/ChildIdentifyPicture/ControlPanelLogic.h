//
//  ControlPanel.h
//  ChildIdentifyPicture
//
//  Created by LXC on 12-2-18.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "PlayGameScene.h"
#import "ControlPanelUI.h"
#import "GameConfigDefine.h"

//圆环半圆方位确认
BOOL leftHide;
BOOL rightHide;

//正确选项
int trueOption;

//关卡计数
int pictureInfoID;

//plist路径
NSString *plistPath;

//双方玩家的操作控制权
BOOL rightDirectionPlayerControl;
BOOL leftDirectionPlayerControl;

NSMutableArray* saveRandomArray;

@interface RightControlPanelLogic : CCSprite
{
	NSString* optionAString;
	NSString* optionBString;
	NSString* optionCString;
	NSString* optionDString;
}

-(void)rightControlPanelLabelUpdate:(int)spriteInfoNumber;
-(void)leftControlPanelLabelUpdate:(int)spriteInfoNumber;
-(void)rightControlPanelLabelInit;
-(void)randomPictureInfoID;

@end


@interface LeftControlPanelLogic : CCSprite
{
	NSString* optionAString;
	NSString* optionBString;
	NSString* optionCString;
	NSString* optionDString;
}

-(void)rightControlPanelLabelUpdate:(int)spriteInfoNumber;
-(void)leftControlPanelLabelUpdate:(int)spriteInfoNumber;
-(void)leftControlPanelLabelInit;
-(void)randomPictureInfoID;

@end