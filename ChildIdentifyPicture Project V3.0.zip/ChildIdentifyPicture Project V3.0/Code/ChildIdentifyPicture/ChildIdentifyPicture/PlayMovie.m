//
//  PlayMovie.m
//  childflower
//
//  Created by Ben on 12-2-20.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "PlayMovie.h"
#import "MainMenuScene.h"

@implementation PlayMovie
@synthesize view;
+(id) scene
{
	CCScene *scene = [CCScene node];
	PlayMovie *layer = [PlayMovie node];
	[scene addChild: layer];
	return scene;
}

-(id) init
{
	if((self=[super init])) 
	{
		CGSize winSize = [[CCDirector sharedDirector] winSize];
		CCSprite *defaultBG = [CCSprite spriteWithFile:@"Default.png"];
		defaultBG.position = ccp (winSize.width*0.5,winSize.height*0.5);
		[self addChild:defaultBG];
		[self performSelector:@selector(play) withObject:nil afterDelay:0.3];
	}
	return self;
}

-(void)play
{
	view = [[CCDirector sharedDirector] openGLView];
	NSString *movieFilePath=[[NSBundle mainBundle]pathForResource:@"CompanyLogo" ofType:@"mp4"];
	NSURL *theMovieURL = [NSURL fileURLWithPath:movieFilePath];
	moviePlayer=[[MPMoviePlayerController alloc] initWithContentURL:theMovieURL];//用url初始化对象
	
	
	//设置电影装载时的回调方法 
	[[NSNotificationCenter defaultCenter] addObserver:self
							     selector:@selector(myMovieChangeCallback:)
								   name:MPMoviePlayerLoadStateDidChangeNotification
								 object:moviePlayer];
}


-(void)myMovieFinishedCallback:(NSNotification*)notification
{
	MPMoviePlayerController *video = [notification object];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:video];
	[video release];
	video = nil;
	[[UIApplication sharedApplication] setStatusBarHidden:YES  withAnimation:UIStatusBarAnimationNone];
	[moviePlayer.view removeFromSuperview];
	[[CCDirector sharedDirector]replaceScene:[MainMenuScene node]];
}

-(void)myMovieChangeCallback:(NSNotification*)notification
{
	//设置电影结束后的回调方法 
	[[NSNotificationCenter defaultCenter] addObserver:self
							     selector:@selector(myMovieFinishedCallback:)
								   name:MPMoviePlayerPlaybackDidFinishNotification
								 object:moviePlayer];
	
	
	moviePlayer.controlStyle = MPMovieControlStyleNone; 
	moviePlayer.fullscreen = YES;
	moviePlayer.scalingMode=MPMovieScalingModeAspectFill;
	[[moviePlayer view] setTransform:CGAffineTransformMakeRotation(M_PI*2)];
	[[moviePlayer view] setFrame:[view bounds]]; 
	[view addSubview:[moviePlayer view]]; 
	
	//开始播放
	[moviePlayer play];
}

- (void)dealloc 
{
	[view release];
	view = nil;
	
	[super dealloc];
}
@end
