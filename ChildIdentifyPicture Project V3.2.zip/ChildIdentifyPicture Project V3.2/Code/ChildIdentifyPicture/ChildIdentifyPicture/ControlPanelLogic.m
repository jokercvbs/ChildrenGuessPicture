//
//  ControlPanel.m
//  ChildIdentifyPicture
//
//  Created by LXC on 12-2-18.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "ControlPanelLogic.h"


@implementation RightControlPanelLogic

-(id) init
{
	if( (self=[super init])) 
	{
		plistPath= [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
		saveRandomArray = [[NSMutableArray alloc] initWithCapacity:20];
		
		rightDirectionPlayerControl = YES;
		leftDirectionPlayerControl = YES;
	}
	return self;
}

//生成指定范围中的不重复随机数
/*
 算法说明:将随机生成的数与数组中保存的随机数作比较
 第一次随机出来的数字直接保存入数组,后续每次都遍历
 到数组尾部,如果中途有重复(与数组中保存的数值冲突)
 数再次随机一个数再次从头开始与数组中保存的数值做
 比较,直到到达末尾都没有匹配到重复的数值,将该随机
 数插入数组中。
 */
-(void)randomPictureInfoID
{
	pictureInfoID = arc4random()%INFO_COUNT;
	if ([saveRandomArray count])
	{
		for (int i=0; i<[saveRandomArray count];) 
		{
			for (int j=0; j<=100; ++j)
			{
				if (pictureInfoID == [[saveRandomArray objectAtIndex:i] intValue])
				{
					i=0;
					pictureInfoID = arc4random()%INFO_COUNT;
					//break;
				}
				else if (i==[saveRandomArray count]-1)
				{
					[saveRandomArray addObject:[NSNumber numberWithInt:pictureInfoID]];
					break;
				}
				else
				{
					++i;
					continue;
				}
			}
			break;
		}
	}
	else
	{
		[saveRandomArray addObject:[NSNumber numberWithInt:pictureInfoID]];
	}
}

-(void)identifyPictureFun
{
	plistPath= [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
	NSDictionary *roundGameData=[[NSDictionary dictionaryWithContentsOfFile:plistPath] valueForKey:[NSString stringWithFormat:@"%d",pictureInfoID]];
	pictureName = [roundGameData objectForKey:@"PictureName"];
	[identifyPicture setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:pictureName]];
	attenuation = 120.0f;
}

-(void)leftHideChangeFun
{
	if (leftHide)
		leftHide = NO;
	else
		leftHide = YES;
}

-(void)rightHideChangeFun
{
	if (rightHide)
		rightHide = NO;
	else
		rightHide = YES;
}

-(void)rightControlPanelCanTouchChangeFun
{
	leftHide
	?[rightPanel_leftHalf setIsTouchEnabled:YES]
	:[rightPanel_rightHalf setIsTouchEnabled:YES];
}

-(void)leftControlPanelCanTouchChangeFun
{
	rightHide
	?[leftPanel_rightHalf setIsTouchEnabled:YES]
	:[leftPanel_leftHalf setIsTouchEnabled:YES];
}

-(void)identifyPictureSoundFun
{
	[playGameMusic thingsRotateInSound];
}

-(void)chooseOption1
{
	plistPath= [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
	NSDictionary *roundGameData=[[NSDictionary dictionaryWithContentsOfFile:plistPath] valueForKey:[NSString stringWithFormat:@"%d",pictureInfoID]];
	trueOption = [[roundGameData objectForKey:@"TrueOptions"] intValue];
	
	id leftCallLabelUpdate = [CCCallFunc actionWithTarget:self selector:@selector(leftControlPanelSendArgument)];
	id rightCallLabelUpdate = [CCCallFunc actionWithTarget:self selector:@selector(rightControlPanelSendArgument)];
	
	id leftControlpanelCanTouchChange = [CCCallFunc actionWithTarget:self selector:@selector(leftControlPanelCanTouchChangeFun)];
	id rightControlPanelCanTouchChange = [CCCallFunc actionWithTarget:self selector:@selector(rightControlPanelCanTouchChangeFun)];
	
	id leftHideChange = [CCCallFunc actionWithTarget:self selector:@selector(leftHideChangeFun)];
	id rightHideChange = [CCCallFunc actionWithTarget:self selector:@selector(rightHideChangeFun)];
	
	id leftControlPanelRotateAction = [CCRotateBy actionWithDuration:0.5 angle:180];
	id rightControlPanelRotateAction = [CCRotateBy actionWithDuration:0.5 angle:180];
	
	
	id preIdentifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.4 scale:0];
	id identifyPictureChange = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureFun)];
	
	id identifyPictureScaleToLarge = [CCScaleTo actionWithDuration:0.4 scale:1.4];
	id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
	
	id identifyPictureSound = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureSoundFun)];
	
	if (trueOption == kOptionA)
	{
		if(![rightControlPanel numberOfRunningActions])
		{
			if(rightHide)
			{
				[leftPanel_leftHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_leftHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_leftHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_leftHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_leftHalfMenuItem1 setIsEnabled:NO];
				[leftPanel_leftHalfMenuItem2 setIsEnabled:NO];
				[leftPanel_leftHalfMenuItem3 setIsEnabled:NO];
				[leftPanel_leftHalfMenuItem4 setIsEnabled:NO];
			}
			else 
			{
				[leftPanel_rightHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_rightHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_rightHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_rightHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_rightHalfMenuItem1 setIsEnabled:NO];
				[leftPanel_rightHalfMenuItem2 setIsEnabled:NO];
				[leftPanel_rightHalfMenuItem3 setIsEnabled:NO];
				[leftPanel_rightHalfMenuItem4 setIsEnabled:NO];
			}
			[playGameMusic chooseTrueSound];
			++rightPlayerScoreCount;
			[rightPlayerScoreCountLabel setString:[NSString stringWithFormat:@"%d",rightPlayerScoreCount]];
			[self randomPictureInfoID];
			[leftControlPanel runAction:[CCSequence actions:leftControlpanelCanTouchChange,leftCallLabelUpdate,rightHideChange,leftControlPanelRotateAction,nil]];
			[rightControlPanel runAction:[CCSequence actions:rightControlPanelCanTouchChange,rightCallLabelUpdate,leftHideChange,rightControlPanelRotateAction,nil]];
			[identifyPicture runAction:[CCSequence actions:preIdentifyPictureScaleToSmall,identifyPictureChange,identifyPictureScaleToLarge,identifyPictureSound,identifyPictureScaleToSmall, nil]];
		}
	}
	else 
	{
		[playGameMusic chooseFalseSound];
		rightDirectionPlayerControl = NO;
		if(leftHide)
		{
			[rightPanel_rightHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_rightHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_rightHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_rightHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_rightHalfMenuItem1 setIsEnabled:NO];
			[rightPanel_rightHalfMenuItem2 setIsEnabled:NO];
			[rightPanel_rightHalfMenuItem3 setIsEnabled:NO];
			[rightPanel_rightHalfMenuItem4 setIsEnabled:NO];
		}
		else 
		{
			[rightPanel_leftHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_leftHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_leftHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_leftHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_leftHalfMenuItem1 setIsEnabled:NO];
			[rightPanel_leftHalfMenuItem2 setIsEnabled:NO];
			[rightPanel_leftHalfMenuItem3 setIsEnabled:NO];
			[rightPanel_leftHalfMenuItem4 setIsEnabled:NO];
		}
		
		
		if (!rightDirectionPlayerControl&&!leftDirectionPlayerControl) 
		{
			[self randomPictureInfoID];
			popInfoLayer.position = ccp(512,384);
			[playGameMusic infoLayerSound];
			id popInfoScaleToLarge = [CCScaleTo actionWithDuration:0.6 scale:1.2];
			id popInfoScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
			id popInfoDelayTime = [CCDelayTime actionWithDuration:1.0];
			id popInfoEndisableScale = [CCScaleTo actionWithDuration:0.6 scale:0];
			id popInfoSequence = [CCSequence actions:popInfoScaleToLarge,popInfoScaleToSmall,popInfoDelayTime,popInfoEndisableScale,nil];
			CCSprite* popInfoLayerInfo = (CCSprite*)[popInfoLayer getChildByTag:kFrameInfo];
			[popInfoLayerInfo setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"ComeOn.png"]];
			[popInfoLayer runAction:popInfoSequence];
			
			[leftControlPanel runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.4],leftControlpanelCanTouchChange,leftCallLabelUpdate,rightHideChange,leftControlPanelRotateAction,nil]];
			[rightControlPanel runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.4],rightControlPanelCanTouchChange,rightCallLabelUpdate,leftHideChange,rightControlPanelRotateAction,nil]];
			[identifyPicture runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.4],preIdentifyPictureScaleToSmall,identifyPictureChange,identifyPictureScaleToLarge,identifyPictureSound,identifyPictureScaleToSmall, nil]];
			rightDirectionPlayerControl = YES;
			leftDirectionPlayerControl = YES;
		}
	}
}

-(void)chooseOption2
{
	plistPath= [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
	NSDictionary *roundGameData=[[NSDictionary dictionaryWithContentsOfFile:plistPath] valueForKey:[NSString stringWithFormat:@"%d",pictureInfoID]];
	trueOption = [[roundGameData objectForKey:@"TrueOptions"] intValue];
	
	id leftCallLabelUpdate = [CCCallFunc actionWithTarget:self selector:@selector(leftControlPanelSendArgument)];
	id rightCallLabelUpdate = [CCCallFunc actionWithTarget:self selector:@selector(rightControlPanelSendArgument)];
	
	id leftControlpanelCanTouchChange = [CCCallFunc actionWithTarget:self selector:@selector(leftControlPanelCanTouchChangeFun)];
	id rightControlPanelCanTouchChange = [CCCallFunc actionWithTarget:self selector:@selector(rightControlPanelCanTouchChangeFun)];
	
	id leftControlPanelRotateAction = [CCRotateBy actionWithDuration:0.5 angle:180];
	id rightControlPanelRotateAction = [CCRotateBy actionWithDuration:0.5 angle:180];
	
	id leftHideChange = [CCCallFunc actionWithTarget:self selector:@selector(leftHideChangeFun)];
	id rightHideChange = [CCCallFunc actionWithTarget:self selector:@selector(rightHideChangeFun)];
	
	
	id preIdentifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.4 scale:0];
	id identifyPictureChange = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureFun)];
	
	id identifyPictureScaleToLarge = [CCScaleTo actionWithDuration:0.4 scale:1.4];
	id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
	
	id identifyPictureSound = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureSoundFun)];
	
	if (trueOption == kOptionB)
	{
		if(![rightControlPanel numberOfRunningActions])
		{
			if(rightHide)
			{
				[leftPanel_leftHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_leftHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_leftHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_leftHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_leftHalfMenuItem1 setIsEnabled:NO];
				[leftPanel_leftHalfMenuItem2 setIsEnabled:NO];
				[leftPanel_leftHalfMenuItem3 setIsEnabled:NO];
				[leftPanel_leftHalfMenuItem4 setIsEnabled:NO];
			}
			else 
			{
				[leftPanel_rightHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_rightHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_rightHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_rightHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_rightHalfMenuItem1 setIsEnabled:NO];
				[leftPanel_rightHalfMenuItem2 setIsEnabled:NO];
				[leftPanel_rightHalfMenuItem3 setIsEnabled:NO];
				[leftPanel_rightHalfMenuItem4 setIsEnabled:NO];
			}
			[playGameMusic chooseTrueSound];
			++rightPlayerScoreCount;
			[rightPlayerScoreCountLabel setString:[NSString stringWithFormat:@"%d",rightPlayerScoreCount]];
			[self randomPictureInfoID];
			[leftControlPanel runAction:[CCSequence actions:leftControlpanelCanTouchChange,leftCallLabelUpdate,rightHideChange,leftControlPanelRotateAction,nil]];
			[rightControlPanel runAction:[CCSequence actions:rightControlPanelCanTouchChange,rightCallLabelUpdate,leftHideChange,rightControlPanelRotateAction,nil]];
			[identifyPicture runAction:[CCSequence actions:preIdentifyPictureScaleToSmall,identifyPictureChange,identifyPictureScaleToLarge,identifyPictureSound,identifyPictureScaleToSmall, nil]];
		}
	}
	else 
	{
		[playGameMusic chooseFalseSound];
		rightDirectionPlayerControl = NO;
		if(leftHide)
		{
			[rightPanel_rightHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_rightHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_rightHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_rightHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_rightHalfMenuItem1 setIsEnabled:NO];
			[rightPanel_rightHalfMenuItem2 setIsEnabled:NO];
			[rightPanel_rightHalfMenuItem3 setIsEnabled:NO];
			[rightPanel_rightHalfMenuItem4 setIsEnabled:NO];
		}
		else 
		{
			[rightPanel_leftHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_leftHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_leftHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_leftHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_leftHalfMenuItem1 setIsEnabled:NO];
			[rightPanel_leftHalfMenuItem2 setIsEnabled:NO];
			[rightPanel_leftHalfMenuItem3 setIsEnabled:NO];
			[rightPanel_leftHalfMenuItem4 setIsEnabled:NO];
		}
		
		
		if (!rightDirectionPlayerControl&&!leftDirectionPlayerControl) 
		{
			[self randomPictureInfoID];
			popInfoLayer.position = ccp(512,384);
			[playGameMusic infoLayerSound];
			id popInfoScaleToLarge = [CCScaleTo actionWithDuration:0.6 scale:1.2];
			id popInfoScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
			id popInfoDelayTime = [CCDelayTime actionWithDuration:1.0];
			id popInfoEndisableScale = [CCScaleTo actionWithDuration:0.6 scale:0];
			id popInfoSequence = [CCSequence actions:popInfoScaleToLarge,popInfoScaleToSmall,popInfoDelayTime,popInfoEndisableScale,nil];
			CCSprite* popInfoLayerInfo = (CCSprite*)[popInfoLayer getChildByTag:kFrameInfo];
			[popInfoLayerInfo setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"ComeOn.png"]];
			[popInfoLayer runAction:popInfoSequence];
			[leftControlPanel runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.4],leftControlpanelCanTouchChange,leftCallLabelUpdate,rightHideChange,leftControlPanelRotateAction,nil]];
			[rightControlPanel runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.4],rightControlPanelCanTouchChange,rightCallLabelUpdate,leftHideChange,rightControlPanelRotateAction,nil]];
			[identifyPicture runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.4],preIdentifyPictureScaleToSmall,identifyPictureChange,identifyPictureScaleToLarge,identifyPictureSound,identifyPictureScaleToSmall, nil]];			
			rightDirectionPlayerControl = YES;
			leftDirectionPlayerControl = YES;
		}
	}
}

-(void)chooseOption3
{
	plistPath= [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
	NSDictionary *roundGameData=[[NSDictionary dictionaryWithContentsOfFile:plistPath] valueForKey:[NSString stringWithFormat:@"%d",pictureInfoID]];
	trueOption = [[roundGameData objectForKey:@"TrueOptions"] intValue];
	
	id leftCallLabelUpdate = [CCCallFunc actionWithTarget:self selector:@selector(leftControlPanelSendArgument)];
	id rightCallLabelUpdate = [CCCallFunc actionWithTarget:self selector:@selector(rightControlPanelSendArgument)];
	
	id leftControlpanelCanTouchChange = [CCCallFunc actionWithTarget:self selector:@selector(leftControlPanelCanTouchChangeFun)];
	id rightControlPanelCanTouchChange = [CCCallFunc actionWithTarget:self selector:@selector(rightControlPanelCanTouchChangeFun)];
	
	id leftControlPanelRotateAction = [CCRotateBy actionWithDuration:0.5 angle:180];
	id rightControlPanelRotateAction = [CCRotateBy actionWithDuration:0.5 angle:180];
	
	id leftHideChange = [CCCallFunc actionWithTarget:self selector:@selector(leftHideChangeFun)];
	id rightHideChange = [CCCallFunc actionWithTarget:self selector:@selector(rightHideChangeFun)];
	
	id preIdentifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.4 scale:0];
	id identifyPictureChange = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureFun)];
	
	id identifyPictureScaleToLarge = [CCScaleTo actionWithDuration:0.4 scale:1.4];
	id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
	
	id identifyPictureSound = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureSoundFun)];
	
	if (trueOption == kOptionC)
	{
		if(![rightControlPanel numberOfRunningActions])
		{
			if(rightHide)
			{
				[leftPanel_leftHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_leftHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_leftHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_leftHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_leftHalfMenuItem1 setIsEnabled:NO];
				[leftPanel_leftHalfMenuItem2 setIsEnabled:NO];
				[leftPanel_leftHalfMenuItem3 setIsEnabled:NO];
				[leftPanel_leftHalfMenuItem4 setIsEnabled:NO];
			}
			else 
			{
				[leftPanel_rightHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_rightHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_rightHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_rightHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_rightHalfMenuItem1 setIsEnabled:NO];
				[leftPanel_rightHalfMenuItem2 setIsEnabled:NO];
				[leftPanel_rightHalfMenuItem3 setIsEnabled:NO];
				[leftPanel_rightHalfMenuItem4 setIsEnabled:NO];
			}
			[playGameMusic chooseTrueSound];
			++rightPlayerScoreCount;
			[rightPlayerScoreCountLabel setString:[NSString stringWithFormat:@"%d",rightPlayerScoreCount]];
			[self randomPictureInfoID];
			[leftControlPanel runAction:[CCSequence actions:leftControlpanelCanTouchChange,leftCallLabelUpdate,rightHideChange,leftControlPanelRotateAction,nil]];
			[rightControlPanel runAction:[CCSequence actions:rightControlPanelCanTouchChange,rightCallLabelUpdate,leftHideChange,rightControlPanelRotateAction,nil]];
			[identifyPicture runAction:[CCSequence actions:preIdentifyPictureScaleToSmall,identifyPictureChange,identifyPictureScaleToLarge,identifyPictureSound,identifyPictureScaleToSmall, nil]];			
		}
	}
	else 
	{
		[playGameMusic chooseFalseSound];
		rightDirectionPlayerControl = NO;
		if(leftHide)
		{
			[rightPanel_rightHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_rightHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_rightHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_rightHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_rightHalfMenuItem1 setIsEnabled:NO];
			[rightPanel_rightHalfMenuItem2 setIsEnabled:NO];
			[rightPanel_rightHalfMenuItem3 setIsEnabled:NO];
			[rightPanel_rightHalfMenuItem4 setIsEnabled:NO];
		}
		else 
		{
			[rightPanel_leftHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_leftHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_leftHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_leftHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_leftHalfMenuItem1 setIsEnabled:NO];
			[rightPanel_leftHalfMenuItem2 setIsEnabled:NO];
			[rightPanel_leftHalfMenuItem3 setIsEnabled:NO];
			[rightPanel_leftHalfMenuItem4 setIsEnabled:NO];
		}
		
		
		if (!rightDirectionPlayerControl&&!leftDirectionPlayerControl) 
		{
			[self randomPictureInfoID];
			popInfoLayer.position = ccp(512,384);
			[playGameMusic infoLayerSound];
			id popInfoScaleToLarge = [CCScaleTo actionWithDuration:0.6 scale:1.2];
			id popInfoScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
			id popInfoDelayTime = [CCDelayTime actionWithDuration:1.0];
			id popInfoEndisableScale = [CCScaleTo actionWithDuration:0.6 scale:0];
			id popInfoSequence = [CCSequence actions:popInfoScaleToLarge,popInfoScaleToSmall,popInfoDelayTime,popInfoEndisableScale,nil];
			CCSprite* popInfoLayerInfo = (CCSprite*)[popInfoLayer getChildByTag:kFrameInfo];
			[popInfoLayerInfo setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"ComeOn.png"]];
			[popInfoLayer runAction:popInfoSequence];
			[leftControlPanel runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.4],leftControlpanelCanTouchChange,leftCallLabelUpdate,rightHideChange,leftControlPanelRotateAction,nil]];
			[rightControlPanel runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.4],rightControlPanelCanTouchChange,rightCallLabelUpdate,leftHideChange,rightControlPanelRotateAction,nil]];
			[identifyPicture runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.4],preIdentifyPictureScaleToSmall,identifyPictureChange,identifyPictureScaleToLarge,identifyPictureSound,identifyPictureScaleToSmall, nil]];			
			rightDirectionPlayerControl = YES;
			leftDirectionPlayerControl = YES;
		}
	}
}

-(void)chooseOption4
{
	plistPath= [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
	NSDictionary *roundGameData=[[NSDictionary dictionaryWithContentsOfFile:plistPath] valueForKey:[NSString stringWithFormat:@"%d",pictureInfoID]];
	trueOption = [[roundGameData objectForKey:@"TrueOptions"] intValue];
	
	id leftCallLabelUpdate = [CCCallFunc actionWithTarget:self selector:@selector(leftControlPanelSendArgument)];
	id rightCallLabelUpdate = [CCCallFunc actionWithTarget:self selector:@selector(rightControlPanelSendArgument)];
	
	id leftControlpanelCanTouchChange = [CCCallFunc actionWithTarget:self selector:@selector(leftControlPanelCanTouchChangeFun)];
	id rightControlPanelCanTouchChange = [CCCallFunc actionWithTarget:self selector:@selector(rightControlPanelCanTouchChangeFun)];
	
	id leftControlPanelRotateAction = [CCRotateBy actionWithDuration:0.5 angle:180];
	id rightControlPanelRotateAction = [CCRotateBy actionWithDuration:0.5 angle:180];
	
	id leftHideChange = [CCCallFunc actionWithTarget:self selector:@selector(leftHideChangeFun)];
	id rightHideChange = [CCCallFunc actionWithTarget:self selector:@selector(rightHideChangeFun)];
	
	id preIdentifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.4 scale:0];
	id identifyPictureChange = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureFun)];
	
	id identifyPictureScaleToLarge = [CCScaleTo actionWithDuration:0.4 scale:1.4];
	id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
	
	id identifyPictureSound = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureSoundFun)];
	
	if (trueOption == kOptionD)
	{
		if(![rightControlPanel numberOfRunningActions])
		{
			if(rightHide)
			{
				[leftPanel_leftHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_leftHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_leftHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_leftHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_leftHalfMenuItem1 setIsEnabled:NO];
				[leftPanel_leftHalfMenuItem2 setIsEnabled:NO];
				[leftPanel_leftHalfMenuItem3 setIsEnabled:NO];
				[leftPanel_leftHalfMenuItem4 setIsEnabled:NO];
			}
			else 
			{
				[leftPanel_rightHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_rightHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_rightHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_rightHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[leftPanel_rightHalfMenuItem1 setIsEnabled:NO];
				[leftPanel_rightHalfMenuItem2 setIsEnabled:NO];
				[leftPanel_rightHalfMenuItem3 setIsEnabled:NO];
				[leftPanel_rightHalfMenuItem4 setIsEnabled:NO];
			}
			[playGameMusic chooseTrueSound];
			++rightPlayerScoreCount;
			[rightPlayerScoreCountLabel setString:[NSString stringWithFormat:@"%d",rightPlayerScoreCount]];
			[self randomPictureInfoID];
			[leftControlPanel runAction:[CCSequence actions:leftControlpanelCanTouchChange,leftCallLabelUpdate,rightHideChange,leftControlPanelRotateAction,nil]];
			[rightControlPanel runAction:[CCSequence actions:rightControlPanelCanTouchChange,rightCallLabelUpdate,leftHideChange,rightControlPanelRotateAction,nil]];
			[identifyPicture runAction:[CCSequence actions:preIdentifyPictureScaleToSmall,identifyPictureChange,identifyPictureScaleToLarge,identifyPictureSound,identifyPictureScaleToSmall, nil]];			
		}
	}
	else 
	{
		[playGameMusic chooseFalseSound];
		rightDirectionPlayerControl = NO;
		if(leftHide)
		{
			[rightPanel_rightHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_rightHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_rightHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_rightHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_rightHalfMenuItem1 setIsEnabled:NO];
			[rightPanel_rightHalfMenuItem2 setIsEnabled:NO];
			[rightPanel_rightHalfMenuItem3 setIsEnabled:NO];
			[rightPanel_rightHalfMenuItem4 setIsEnabled:NO];
		}
		else 
		{
			[rightPanel_leftHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_leftHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_leftHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_leftHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[rightPanel_leftHalfMenuItem1 setIsEnabled:NO];
			[rightPanel_leftHalfMenuItem2 setIsEnabled:NO];
			[rightPanel_leftHalfMenuItem3 setIsEnabled:NO];
			[rightPanel_leftHalfMenuItem4 setIsEnabled:NO];
		}
		
		
		if (!rightDirectionPlayerControl&&!leftDirectionPlayerControl) 
		{
			popInfoLayer.position = ccp(512,384);
			[playGameMusic infoLayerSound];
			id popInfoScaleToLarge = [CCScaleTo actionWithDuration:0.6 scale:1.2];
			id popInfoScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
			id popInfoDelayTime = [CCDelayTime actionWithDuration:1.0];
			id popInfoEndisableScale = [CCScaleTo actionWithDuration:0.6 scale:0];
			id popInfoSequence = [CCSequence actions:popInfoScaleToLarge,popInfoScaleToSmall,popInfoDelayTime,popInfoEndisableScale,nil];
			CCSprite* popInfoLayerInfo = (CCSprite*)[popInfoLayer getChildByTag:kFrameInfo];
			[popInfoLayerInfo setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"ComeOn.png"]];
			[popInfoLayer runAction:popInfoSequence];
			[self randomPictureInfoID];
			[leftControlPanel runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.4],leftControlpanelCanTouchChange,leftCallLabelUpdate,rightHideChange,leftControlPanelRotateAction,nil]];
			[rightControlPanel runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.4],rightControlPanelCanTouchChange,rightCallLabelUpdate,leftHideChange,rightControlPanelRotateAction,nil]];
			[identifyPicture runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.4],preIdentifyPictureScaleToSmall,identifyPictureChange,identifyPictureScaleToLarge,identifyPictureSound,identifyPictureScaleToSmall, nil]];			
			rightDirectionPlayerControl = YES;
			leftDirectionPlayerControl = YES;
		}
	}
}

-(void)rightControlPanelSendArgument
{
	[self rightControlPanelLabelUpdate:pictureInfoID];
}

-(void)leftControlPanelSendArgument
{
	[self leftControlPanelLabelUpdate:pictureInfoID];
}

-(void)rightControlPanelLabelInit
{
	[self randomPictureInfoID];
	plistPath= [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
	NSDictionary *roundGameData=[[NSDictionary dictionaryWithContentsOfFile:plistPath] valueForKey:[NSString stringWithFormat:@"%d",pictureInfoID]];
	pictureName = [roundGameData objectForKey:@"PictureName"];
	[identifyPicture setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:pictureName]];
	
	if(!leftHide)
	{
		optionAString = [[roundGameData objectForKey:@"Options"]objectForKey:@"OptionA"];
		[rightPanel_rightHalfLabel1 setString:optionAString];
		optionBString = [[roundGameData objectForKey:@"Options"]objectForKey:@"OptionB"];
		[rightPanel_rightHalfLabel2 setString:optionBString];
		optionCString = [[roundGameData objectForKey:@"Options"] objectForKey:@"OptionC"];
		[rightPanel_rightHalfLabel3 setString:optionCString];
		optionDString = [[roundGameData objectForKey:@"Options"] objectForKey:@"OptionD"];
		[rightPanel_rightHalfLabel4 setString:optionDString];
		[rightPanel_rightHalfMenuItem1 setIsEnabled:YES];
		[rightPanel_rightHalfMenuItem2 setIsEnabled:YES];
		[rightPanel_rightHalfMenuItem3 setIsEnabled:YES];
		[rightPanel_rightHalfMenuItem4 setIsEnabled:YES];
		[rightPanel_rightHalf setIsTouchEnabled:YES];
		rightDirectionPlayerControl = YES;
		leftDirectionPlayerControl = YES;
	}
	else
	{
		optionAString = [[roundGameData objectForKey:@"Options"]objectForKey:@"OptionA"];
		[rightPanel_leftHalfLabel1 setString:optionAString];
		optionBString = [[roundGameData objectForKey:@"Options"]objectForKey:@"OptionB"];
		[rightPanel_leftHalfLabel2 setString:optionBString];
		optionCString = [[roundGameData objectForKey:@"Options"] objectForKey:@"OptionC"];
		[rightPanel_leftHalfLabel3 setString:optionCString];
		optionDString = [[roundGameData objectForKey:@"Options"] objectForKey:@"OptionD"];
		[rightPanel_leftHalfLabel4 setString:optionDString];
		[rightPanel_leftHalfMenuItem1 setIsEnabled:YES];
		[rightPanel_leftHalfMenuItem2 setIsEnabled:YES];
		[rightPanel_leftHalfMenuItem3 setIsEnabled:YES];
		[rightPanel_leftHalfMenuItem4 setIsEnabled:YES];
		[rightPanel_leftHalf setIsTouchEnabled:YES];
		rightDirectionPlayerControl = YES;
		leftDirectionPlayerControl = YES;
	}
}

-(void)rightControlPanelLabelUpdate:(int)spriteInfoNumber
{
	
	plistPath= [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
	
	if (leftHide)
	{
		NSDictionary *nextRoundGameData = [[NSDictionary dictionaryWithContentsOfFile:plistPath] valueForKey:[NSString stringWithFormat:@"%d",spriteInfoNumber]];
		optionAString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionA"];
		[rightPanel_leftHalfLabel1 setString:optionAString];
		optionBString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionB"];
		[rightPanel_leftHalfLabel2 setString:optionBString];
		optionCString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionC"];
		[rightPanel_leftHalfLabel3 setString:optionCString];
		optionDString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionD"];
		[rightPanel_leftHalfLabel4 setString:optionDString];
		[rightPanel_leftHalfMenuItem1 setIsEnabled:YES];
		[rightPanel_leftHalfMenuItem2 setIsEnabled:YES];
		[rightPanel_leftHalfMenuItem3 setIsEnabled:YES];
		[rightPanel_leftHalfMenuItem4 setIsEnabled:YES];
		rightDirectionPlayerControl = YES;
		leftDirectionPlayerControl = YES;
	}
	else 
	{
		NSDictionary *nextRoundGameData = [[NSDictionary dictionaryWithContentsOfFile:plistPath] valueForKey:[NSString stringWithFormat:@"%d",spriteInfoNumber]];
		optionAString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionA"];
		[rightPanel_rightHalfLabel1 setString:optionAString];
		optionBString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionB"];
		[rightPanel_rightHalfLabel2 setString:optionBString];
		optionCString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionC"];
		[rightPanel_rightHalfLabel3 setString:optionCString];
		optionDString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionD"];
		[rightPanel_rightHalfLabel4 setString:optionDString];
		[rightPanel_rightHalfMenuItem1 setIsEnabled:YES];
		[rightPanel_rightHalfMenuItem2 setIsEnabled:YES];
		[rightPanel_rightHalfMenuItem3 setIsEnabled:YES];
		[rightPanel_rightHalfMenuItem4 setIsEnabled:YES];
		rightDirectionPlayerControl = YES;
		leftDirectionPlayerControl = YES;
	}
}

-(void)leftControlPanelLabelUpdate:(int)spriteInfoNumber
{
	
	NSString *plistPath= [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
	if (rightHide)
	{
		NSDictionary *nextRoundGameData = [[NSDictionary dictionaryWithContentsOfFile:plistPath] valueForKey:[NSString stringWithFormat:@"%d",spriteInfoNumber]];
		optionAString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionA"];
		[leftPanel_rightHalfLabel1 setString:optionAString];
		optionBString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionB"];
		[leftPanel_rightHalfLabel2 setString:optionBString];
		optionCString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionC"];
		[leftPanel_rightHalfLabel3 setString:optionCString];
		optionDString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionD"];
		[leftPanel_rightHalfLabel4 setString:optionDString];
		[leftPanel_rightHalfMenuItem1 setIsEnabled:YES];
		[leftPanel_rightHalfMenuItem2 setIsEnabled:YES];
		[leftPanel_rightHalfMenuItem3 setIsEnabled:YES];
		[leftPanel_rightHalfMenuItem4 setIsEnabled:YES];
		rightDirectionPlayerControl = YES;
		leftDirectionPlayerControl = YES;
	}
	else 
	{
		NSDictionary *nextRoundGameData = [[NSDictionary dictionaryWithContentsOfFile:plistPath] valueForKey:[NSString stringWithFormat:@"%d",spriteInfoNumber]];
		optionAString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionA"];
		[leftPanel_leftHalfLabel1 setString:optionAString];
		optionBString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionB"];
		[leftPanel_leftHalfLabel2 setString:optionBString];
		optionCString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionC"];
		[leftPanel_leftHalfLabel3 setString:optionCString];
		optionDString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionD"];
		[leftPanel_leftHalfLabel4 setString:optionDString];
		[leftPanel_leftHalfMenuItem1 setIsEnabled:YES];
		[leftPanel_leftHalfMenuItem2 setIsEnabled:YES];
		[leftPanel_leftHalfMenuItem3 setIsEnabled:YES];
		[leftPanel_leftHalfMenuItem4 setIsEnabled:YES];
		rightDirectionPlayerControl = YES;
		leftDirectionPlayerControl = YES;
	}
}

- (void) dealloc
{
	[saveRandomArray release];
	saveRandomArray = nil;
	[super dealloc];
}

@end


@implementation LeftControlPanelLogic

-(id) init
{
	if( (self=[super init])) 
	{
		
	}
	return self;
}

-(void)randomPictureInfoID
{
	pictureInfoID = arc4random()%INFO_COUNT;
	if ([saveRandomArray count])
	{
		for (int i=0; i<[saveRandomArray count];) 
		{
			for (int j=0; j<=100; ++j)
			{
				if (pictureInfoID == [[saveRandomArray objectAtIndex:i] intValue])
				{
					i=0;
					pictureInfoID = arc4random()%INFO_COUNT;
					//break;
				}
				else if (i==[saveRandomArray count]-1)
				{
					[saveRandomArray addObject:[NSNumber numberWithInt:pictureInfoID]];
					break;
				}
				else
				{
					++i;
					continue;
				}
			}
			break;
		}
	}
	else
	{
		[saveRandomArray addObject:[NSNumber numberWithInt:pictureInfoID]];
	}
}

-(void)identifyPictureFun
{
	plistPath= [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
	NSDictionary *roundGameData=[[NSDictionary dictionaryWithContentsOfFile:plistPath] valueForKey:[NSString stringWithFormat:@"%d",pictureInfoID]];
	pictureName = [roundGameData objectForKey:@"PictureName"];
	[identifyPicture setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:pictureName]];
	attenuation = 120.0f;
}

-(void)leftHideChangeFun
{
	if (leftHide)
		leftHide = NO;
	else
		leftHide = YES;
}

-(void)rightHideChangeFun
{
	if (rightHide)
		rightHide = NO;
	else
		rightHide = YES;
}

-(void)identifyPictureSoundFun
{
	[playGameMusic thingsRotateInSound];
}

-(void)rightControlPanelCanTouchChangeFun
{
	leftHide
	?[rightPanel_leftHalf setIsTouchEnabled:YES]
	:[rightPanel_rightHalf setIsTouchEnabled:YES];
}

-(void)leftControlPanelCanTouchChangeFun
{
	rightHide
	?[leftPanel_rightHalf setIsTouchEnabled:YES]
	:[leftPanel_leftHalf setIsTouchEnabled:YES];
}

-(void)chooseOption1
{
	plistPath= [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
	NSDictionary *roundGameData=[[NSDictionary dictionaryWithContentsOfFile:plistPath] valueForKey:[NSString stringWithFormat:@"%d",pictureInfoID]];
	trueOption = [[roundGameData objectForKey:@"TrueOptions"] intValue];
	
	id leftCallLabelUpdate = [CCCallFunc actionWithTarget:self selector:@selector(leftControlPanelSendArgument)];
	id rightCallLabelUpdate = [CCCallFunc actionWithTarget:self selector:@selector(rightControlPanelSendArgument)];
	
	id leftControlpanelCanTouchChange = [CCCallFunc actionWithTarget:self selector:@selector(leftControlPanelCanTouchChangeFun)];
	id rightControlPanelCanTouchChange = [CCCallFunc actionWithTarget:self selector:@selector(rightControlPanelCanTouchChangeFun)];
	
	id leftControlPanelRotateAction = [CCRotateBy actionWithDuration:0.5 angle:180];
	id rightControlPanelRotateAction = [CCRotateBy actionWithDuration:0.5 angle:180];
	id leftHideChange = [CCCallFunc actionWithTarget:self selector:@selector(leftHideChangeFun)];
	id rightHideChange = [CCCallFunc actionWithTarget:self selector:@selector(rightHideChangeFun)];
	
	id preIdentifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.4 scale:0];
	id identifyPictureChange = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureFun)];
	
	id identifyPictureScaleToLarge = [CCScaleTo actionWithDuration:0.4 scale:1.4];
	id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
	
	id identifyPictureSound = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureSoundFun)];
	
	if (trueOption == kOptionA)
	{
		if(![leftControlPanel numberOfRunningActions])
		{
			if(leftHide)
			{
				[rightPanel_rightHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_rightHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_rightHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_rightHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_rightHalfMenuItem1 setIsEnabled:NO];
				[rightPanel_rightHalfMenuItem2 setIsEnabled:NO];
				[rightPanel_rightHalfMenuItem3 setIsEnabled:NO];
				[rightPanel_rightHalfMenuItem4 setIsEnabled:NO];
			}
			else 
			{
				[rightPanel_leftHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_leftHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_leftHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_leftHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_leftHalfMenuItem1 setIsEnabled:NO];
				[rightPanel_leftHalfMenuItem2 setIsEnabled:NO];
				[rightPanel_leftHalfMenuItem3 setIsEnabled:NO];
				[rightPanel_leftHalfMenuItem4 setIsEnabled:NO];
			}
			[playGameMusic chooseTrueSound];
			++leftPlayerScoreCount;
			[leftPlayerScoreCountLabel setString:[NSString stringWithFormat:@"%d",leftPlayerScoreCount]];
			[self randomPictureInfoID];
			[leftControlPanel runAction:[CCSequence actions:leftControlpanelCanTouchChange,leftCallLabelUpdate,rightHideChange,leftControlPanelRotateAction,nil]];
			[rightControlPanel runAction:[CCSequence actions:rightControlPanelCanTouchChange,rightCallLabelUpdate,leftHideChange,rightControlPanelRotateAction,nil]];
			[identifyPicture runAction:[CCSequence actions:preIdentifyPictureScaleToSmall,identifyPictureChange,identifyPictureScaleToLarge,identifyPictureSound,identifyPictureScaleToSmall, nil]];
		}
	}
	else 
	{
		[playGameMusic chooseFalseSound];
		leftDirectionPlayerControl = NO;
		if(rightHide)
		{
			
			[leftPanel_leftHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_leftHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_leftHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_leftHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_leftHalfMenuItem1 setIsEnabled:NO];
			[leftPanel_leftHalfMenuItem2 setIsEnabled:NO];
			[leftPanel_leftHalfMenuItem3 setIsEnabled:NO];
			[leftPanel_leftHalfMenuItem4 setIsEnabled:NO];
		}
		else 
		{
			[leftPanel_rightHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_rightHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_rightHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_rightHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_rightHalfMenuItem1 setIsEnabled:NO];
			[leftPanel_rightHalfMenuItem2 setIsEnabled:NO];
			[leftPanel_rightHalfMenuItem3 setIsEnabled:NO];
			[leftPanel_rightHalfMenuItem4 setIsEnabled:NO];
		}
		
		
		if (!rightDirectionPlayerControl&&!leftDirectionPlayerControl) 
		{
			[self randomPictureInfoID];
			popInfoLayer.position = ccp(512,384);
			[playGameMusic infoLayerSound];
			id popInfoScaleToLarge = [CCScaleTo actionWithDuration:0.6 scale:1.2];
			id popInfoScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
			id popInfoDelayTime = [CCDelayTime actionWithDuration:1.0];
			id popInfoEndisableScale = [CCScaleTo actionWithDuration:0.6 scale:0];
			id popInfoSequence = [CCSequence actions:popInfoScaleToLarge,popInfoScaleToSmall,popInfoDelayTime,popInfoEndisableScale,nil];
			CCSprite* popInfoLayerInfo = (CCSprite*)[popInfoLayer getChildByTag:kFrameInfo];
			[popInfoLayerInfo setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"ComeOn.png"]];
			[popInfoLayer runAction:popInfoSequence];
			[leftControlPanel runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.4],leftControlpanelCanTouchChange,leftCallLabelUpdate,rightHideChange,leftControlPanelRotateAction,nil]];
			[rightControlPanel runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.4],rightControlPanelCanTouchChange,rightCallLabelUpdate,leftHideChange,rightControlPanelRotateAction,nil]];
			[identifyPicture runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.4],preIdentifyPictureScaleToSmall,identifyPictureChange,identifyPictureScaleToLarge,identifyPictureSound,identifyPictureScaleToSmall, nil]];
			rightDirectionPlayerControl = YES;
			leftDirectionPlayerControl = YES;
		}
	}
}

-(void)chooseOption2
{
	plistPath= [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
	NSDictionary *roundGameData=[[NSDictionary dictionaryWithContentsOfFile:plistPath] valueForKey:[NSString stringWithFormat:@"%d",pictureInfoID]];
	trueOption = [[roundGameData objectForKey:@"TrueOptions"] intValue];
	
	id leftCallLabelUpdate = [CCCallFunc actionWithTarget:self selector:@selector(leftControlPanelSendArgument)];
	id rightCallLabelUpdate = [CCCallFunc actionWithTarget:self selector:@selector(rightControlPanelSendArgument)];
	
	id leftControlpanelCanTouchChange = [CCCallFunc actionWithTarget:self selector:@selector(leftControlPanelCanTouchChangeFun)];
	id rightControlPanelCanTouchChange = [CCCallFunc actionWithTarget:self selector:@selector(rightControlPanelCanTouchChangeFun)];
	
	id leftControlPanelRotateAction = [CCRotateBy actionWithDuration:0.5 angle:180];
	id rightControlPanelRotateAction = [CCRotateBy actionWithDuration:0.5 angle:180];
	id leftHideChange = [CCCallFunc actionWithTarget:self selector:@selector(leftHideChangeFun)];
	id rightHideChange = [CCCallFunc actionWithTarget:self selector:@selector(rightHideChangeFun)];
	
	id preIdentifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.4 scale:0];
	id identifyPictureChange = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureFun)];
	
	id identifyPictureScaleToLarge = [CCScaleTo actionWithDuration:0.4 scale:1.4];
	id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
	
	id identifyPictureSound = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureSoundFun)];
	
	if (trueOption == kOptionB)
	{
		if(![leftControlPanel numberOfRunningActions])
		{
			if(leftHide)
			{
				[rightPanel_rightHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_rightHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_rightHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_rightHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_rightHalfMenuItem1 setIsEnabled:NO];
				[rightPanel_rightHalfMenuItem2 setIsEnabled:NO];
				[rightPanel_rightHalfMenuItem3 setIsEnabled:NO];
				[rightPanel_rightHalfMenuItem4 setIsEnabled:NO];
			}
			else 
			{
				[rightPanel_leftHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_leftHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_leftHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_leftHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_leftHalfMenuItem1 setIsEnabled:NO];
				[rightPanel_leftHalfMenuItem2 setIsEnabled:NO];
				[rightPanel_leftHalfMenuItem3 setIsEnabled:NO];
				[rightPanel_leftHalfMenuItem4 setIsEnabled:NO];
			}
			[playGameMusic chooseTrueSound];
			++leftPlayerScoreCount;
			[leftPlayerScoreCountLabel setString:[NSString stringWithFormat:@"%d",leftPlayerScoreCount]];
			[self randomPictureInfoID];
			[leftControlPanel runAction:[CCSequence actions:leftControlpanelCanTouchChange,leftCallLabelUpdate,rightHideChange,leftControlPanelRotateAction,nil]];
			[rightControlPanel runAction:[CCSequence actions:rightControlPanelCanTouchChange,rightCallLabelUpdate,leftHideChange,rightControlPanelRotateAction,nil]];
			[identifyPicture runAction:[CCSequence actions:preIdentifyPictureScaleToSmall,identifyPictureChange,identifyPictureScaleToLarge,identifyPictureSound,identifyPictureScaleToSmall, nil]];
		}
	}
	else 
	{
		[playGameMusic chooseFalseSound];
		leftDirectionPlayerControl = NO;
		if(rightHide)
		{
			[leftPanel_leftHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_leftHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_leftHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_leftHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_leftHalfMenuItem1 setIsEnabled:NO];
			[leftPanel_leftHalfMenuItem2 setIsEnabled:NO];
			[leftPanel_leftHalfMenuItem3 setIsEnabled:NO];
			[leftPanel_leftHalfMenuItem4 setIsEnabled:NO];
		}
		else 
		{
			[leftPanel_rightHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_rightHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_rightHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_rightHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_rightHalfMenuItem1 setIsEnabled:NO];
			[leftPanel_rightHalfMenuItem2 setIsEnabled:NO];
			[leftPanel_rightHalfMenuItem3 setIsEnabled:NO];
			[leftPanel_rightHalfMenuItem4 setIsEnabled:NO];
		}
		
		
		if (!rightDirectionPlayerControl&&!leftDirectionPlayerControl) 
		{
			[self randomPictureInfoID];
			popInfoLayer.position = ccp(512,384);
			[playGameMusic infoLayerSound];
			id popInfoScaleToLarge = [CCScaleTo actionWithDuration:0.6 scale:1.2];
			id popInfoScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
			id popInfoDelayTime = [CCDelayTime actionWithDuration:1.0];
			id popInfoEndisableScale = [CCScaleTo actionWithDuration:0.6 scale:0];
			id popInfoSequence = [CCSequence actions:popInfoScaleToLarge,popInfoScaleToSmall,popInfoDelayTime,popInfoEndisableScale,nil];
			CCSprite* popInfoLayerInfo = (CCSprite*)[popInfoLayer getChildByTag:kFrameInfo];
			[popInfoLayerInfo setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"ComeOn.png"]];
			[popInfoLayer runAction:popInfoSequence];
			[leftControlPanel runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.4],leftControlpanelCanTouchChange,leftCallLabelUpdate,rightHideChange,leftControlPanelRotateAction,nil]];
			[rightControlPanel runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.4],rightControlPanelCanTouchChange,rightCallLabelUpdate,leftHideChange,rightControlPanelRotateAction,nil]];
			[identifyPicture runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.4],preIdentifyPictureScaleToSmall,identifyPictureChange,identifyPictureScaleToLarge,identifyPictureSound,identifyPictureScaleToSmall, nil]];
			
			rightDirectionPlayerControl = YES;
			leftDirectionPlayerControl = YES;
		}
	}
}

-(void)chooseOption3
{
	plistPath= [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
	NSDictionary *roundGameData=[[NSDictionary dictionaryWithContentsOfFile:plistPath] valueForKey:[NSString stringWithFormat:@"%d",pictureInfoID]];
	trueOption = [[roundGameData objectForKey:@"TrueOptions"] intValue];
	
	id leftCallLabelUpdate = [CCCallFunc actionWithTarget:self selector:@selector(leftControlPanelSendArgument)];
	id rightCallLabelUpdate = [CCCallFunc actionWithTarget:self selector:@selector(rightControlPanelSendArgument)];
	
	id leftControlpanelCanTouchChange = [CCCallFunc actionWithTarget:self selector:@selector(leftControlPanelCanTouchChangeFun)];
	id rightControlPanelCanTouchChange = [CCCallFunc actionWithTarget:self selector:@selector(rightControlPanelCanTouchChangeFun)];
	
	id leftControlPanelRotateAction = [CCRotateBy actionWithDuration:0.5 angle:180];
	id rightControlPanelRotateAction = [CCRotateBy actionWithDuration:0.5 angle:180];
	id leftHideChange = [CCCallFunc actionWithTarget:self selector:@selector(leftHideChangeFun)];
	id rightHideChange = [CCCallFunc actionWithTarget:self selector:@selector(rightHideChangeFun)];
	
	id preIdentifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.4 scale:0];
	id identifyPictureChange = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureFun)];
	
	id identifyPictureScaleToLarge = [CCScaleTo actionWithDuration:0.4 scale:1.4];
	id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
	
	id identifyPictureSound = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureSoundFun)];
	
	if (trueOption == kOptionC)
	{
		if(![leftControlPanel numberOfRunningActions])
		{
			if(leftHide)
			{
				[rightPanel_rightHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_rightHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_rightHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_rightHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_rightHalfMenuItem1 setIsEnabled:NO];
				[rightPanel_rightHalfMenuItem2 setIsEnabled:NO];
				[rightPanel_rightHalfMenuItem3 setIsEnabled:NO];
				[rightPanel_rightHalfMenuItem4 setIsEnabled:NO];
			}
			else 
			{
				[rightPanel_leftHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_leftHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_leftHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_leftHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_leftHalfMenuItem1 setIsEnabled:NO];
				[rightPanel_leftHalfMenuItem2 setIsEnabled:NO];
				[rightPanel_leftHalfMenuItem3 setIsEnabled:NO];
				[rightPanel_leftHalfMenuItem4 setIsEnabled:NO];
			}
			[playGameMusic chooseTrueSound];
			++leftPlayerScoreCount;
			[leftPlayerScoreCountLabel setString:[NSString stringWithFormat:@"%d",leftPlayerScoreCount]];
			[self randomPictureInfoID];
			[leftControlPanel runAction:[CCSequence actions:leftControlpanelCanTouchChange,leftCallLabelUpdate,rightHideChange,leftControlPanelRotateAction,nil]];
			[rightControlPanel runAction:[CCSequence actions:rightControlPanelCanTouchChange,rightCallLabelUpdate,leftHideChange,rightControlPanelRotateAction,nil]];
			[identifyPicture runAction:[CCSequence actions:preIdentifyPictureScaleToSmall,identifyPictureChange,identifyPictureScaleToLarge,identifyPictureSound,identifyPictureScaleToSmall, nil]];			
		}
	}
	else 
	{
		[playGameMusic chooseFalseSound];
		leftDirectionPlayerControl = NO;
		if(rightHide)
		{
			[leftPanel_leftHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_leftHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_leftHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_leftHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_leftHalfMenuItem1 setIsEnabled:NO];
			[leftPanel_leftHalfMenuItem2 setIsEnabled:NO];
			[leftPanel_leftHalfMenuItem3 setIsEnabled:NO];
			[leftPanel_leftHalfMenuItem4 setIsEnabled:NO];
		}
		else 
		{
			[leftPanel_rightHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_rightHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_rightHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_rightHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_rightHalfMenuItem1 setIsEnabled:NO];
			[leftPanel_rightHalfMenuItem2 setIsEnabled:NO];
			[leftPanel_rightHalfMenuItem3 setIsEnabled:NO];
			[leftPanel_rightHalfMenuItem4 setIsEnabled:NO];
		}
		
		
		if (!rightDirectionPlayerControl&&!leftDirectionPlayerControl) 
		{
			[self randomPictureInfoID];
			popInfoLayer.position = ccp(512,384);
			[playGameMusic infoLayerSound];
			id popInfoScaleToLarge = [CCScaleTo actionWithDuration:0.6 scale:1.2];
			id popInfoScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
			id popInfoDelayTime = [CCDelayTime actionWithDuration:1.0];
			id popInfoEndisableScale = [CCScaleTo actionWithDuration:0.6 scale:0];
			id popInfoSequence = [CCSequence actions:popInfoScaleToLarge,popInfoScaleToSmall,popInfoDelayTime,popInfoEndisableScale,nil];
			CCSprite* popInfoLayerInfo = (CCSprite*)[popInfoLayer getChildByTag:kFrameInfo];
			[popInfoLayerInfo setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"ComeOn.png"]];
			[popInfoLayer runAction:popInfoSequence];
			[leftControlPanel runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.4],leftControlpanelCanTouchChange,leftCallLabelUpdate,rightHideChange,leftControlPanelRotateAction,nil]];
			[rightControlPanel runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.4],rightControlPanelCanTouchChange,rightCallLabelUpdate,leftHideChange,rightControlPanelRotateAction,nil]];
			[identifyPicture runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.4],preIdentifyPictureScaleToSmall,identifyPictureChange,identifyPictureScaleToLarge,identifyPictureSound,identifyPictureScaleToSmall, nil]];			
			rightDirectionPlayerControl = YES;
			leftDirectionPlayerControl = YES;
		}
	}
}

-(void)chooseOption4
{
	plistPath= [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
	NSDictionary *roundGameData=[[NSDictionary dictionaryWithContentsOfFile:plistPath] valueForKey:[NSString stringWithFormat:@"%d",pictureInfoID]];
	trueOption = [[roundGameData objectForKey:@"TrueOptions"] intValue];
	
	id leftCallLabelUpdate = [CCCallFunc actionWithTarget:self selector:@selector(leftControlPanelSendArgument)];
	id rightCallLabelUpdate = [CCCallFunc actionWithTarget:self selector:@selector(rightControlPanelSendArgument)];
	
	id leftControlpanelCanTouchChange = [CCCallFunc actionWithTarget:self selector:@selector(leftControlPanelCanTouchChangeFun)];
	id rightControlPanelCanTouchChange = [CCCallFunc actionWithTarget:self selector:@selector(rightControlPanelCanTouchChangeFun)];
	
	id leftControlPanelRotateAction = [CCRotateBy actionWithDuration:0.5 angle:180];
	id rightControlPanelRotateAction = [CCRotateBy actionWithDuration:0.5 angle:180];
	
	id leftHideChange = [CCCallFunc actionWithTarget:self selector:@selector(leftHideChangeFun)];
	id rightHideChange = [CCCallFunc actionWithTarget:self selector:@selector(rightHideChangeFun)];
	
	
	id preIdentifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.4 scale:0];
	id identifyPictureChange = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureFun)];
	
	id identifyPictureScaleToLarge = [CCScaleTo actionWithDuration:0.4 scale:1.4];
	id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
	
	id identifyPictureSound = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureSoundFun)];
	
	if (trueOption == kOptionD)
	{
		if(![leftControlPanel numberOfRunningActions])
		{
			if(leftHide)
			{
				[rightPanel_rightHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_rightHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_rightHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_rightHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_rightHalfMenuItem1 setIsEnabled:NO];
				[rightPanel_rightHalfMenuItem2 setIsEnabled:NO];
				[rightPanel_rightHalfMenuItem3 setIsEnabled:NO];
				[rightPanel_rightHalfMenuItem4 setIsEnabled:NO];
			}
			else 
			{
				[rightPanel_leftHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_leftHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_leftHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_leftHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
				[rightPanel_leftHalfMenuItem1 setIsEnabled:NO];
				[rightPanel_leftHalfMenuItem2 setIsEnabled:NO];
				[rightPanel_leftHalfMenuItem3 setIsEnabled:NO];
				[rightPanel_leftHalfMenuItem4 setIsEnabled:NO];
			}
			[playGameMusic chooseTrueSound];
			++leftPlayerScoreCount;
			[leftPlayerScoreCountLabel setString:[NSString stringWithFormat:@"%d",leftPlayerScoreCount]];
			[self randomPictureInfoID];
			[leftControlPanel runAction:[CCSequence actions:leftControlpanelCanTouchChange,leftCallLabelUpdate,rightHideChange,leftControlPanelRotateAction,nil]];
			[rightControlPanel runAction:[CCSequence actions:rightControlPanelCanTouchChange,rightCallLabelUpdate,leftHideChange,rightControlPanelRotateAction,nil]];
			[identifyPicture runAction:[CCSequence actions:preIdentifyPictureScaleToSmall,identifyPictureChange,identifyPictureScaleToLarge,identifyPictureSound,identifyPictureScaleToSmall, nil]];			
		}
	}
	else 
	{
		[playGameMusic chooseFalseSound];
		leftDirectionPlayerControl = NO;
		if(rightHide)
		{
			[leftPanel_leftHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_leftHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_leftHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_leftHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_leftHalfMenuItem1 setIsEnabled:NO];
			[leftPanel_leftHalfMenuItem2 setIsEnabled:NO];
			[leftPanel_leftHalfMenuItem3 setIsEnabled:NO];
			[leftPanel_leftHalfMenuItem4 setIsEnabled:NO];
		}
		else 
		{
			[leftPanel_rightHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_rightHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_rightHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_rightHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]];
			[leftPanel_rightHalfMenuItem1 setIsEnabled:NO];
			[leftPanel_rightHalfMenuItem2 setIsEnabled:NO];
			[leftPanel_rightHalfMenuItem3 setIsEnabled:NO];
			[leftPanel_rightHalfMenuItem4 setIsEnabled:NO];
		}
		
		
		if (!rightDirectionPlayerControl&&!leftDirectionPlayerControl) 
		{
			[self randomPictureInfoID];
			popInfoLayer.position = ccp(512,384);
			[playGameMusic infoLayerSound];
			id popInfoScaleToLarge = [CCScaleTo actionWithDuration:0.6 scale:1.2];
			id popInfoScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
			id popInfoDelayTime = [CCDelayTime actionWithDuration:1.0];
			id popInfoEndisableScale = [CCScaleTo actionWithDuration:0.6 scale:0];
			id popInfoSequence = [CCSequence actions:popInfoScaleToLarge,popInfoScaleToSmall,popInfoDelayTime,popInfoEndisableScale,nil];
			CCSprite* popInfoLayerInfo = (CCSprite*)[popInfoLayer getChildByTag:kFrameInfo];
			[popInfoLayerInfo setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"ComeOn.png"]];
			[popInfoLayer runAction:popInfoSequence];
			[leftControlPanel runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.4],leftControlpanelCanTouchChange,leftCallLabelUpdate,rightHideChange,leftControlPanelRotateAction,nil]];
			[rightControlPanel runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.4],rightControlPanelCanTouchChange,rightCallLabelUpdate,leftHideChange,rightControlPanelRotateAction,nil]];
			[identifyPicture runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.4],preIdentifyPictureScaleToSmall,identifyPictureChange,identifyPictureScaleToLarge,identifyPictureSound,identifyPictureScaleToSmall, nil]];			
			rightDirectionPlayerControl = YES;
			leftDirectionPlayerControl = YES;
		}
	}
}

-(void)rightControlPanelSendArgument
{
	[self rightControlPanelLabelUpdate:pictureInfoID];
}

-(void)leftControlPanelSendArgument
{
	[self leftControlPanelLabelUpdate:pictureInfoID];
}

-(void)leftControlPanelLabelInit
{
	plistPath= [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
	
	NSDictionary *roundGameData=[[NSDictionary dictionaryWithContentsOfFile:plistPath] valueForKey:[NSString stringWithFormat:@"%d",pictureInfoID]];
	if (!rightHide) 
	{
		optionAString = [[roundGameData objectForKey:@"Options"]objectForKey:@"OptionA"];
		[leftPanel_leftHalfLabel1 setString:optionAString];
		optionBString = [[roundGameData objectForKey:@"Options"]objectForKey:@"OptionB"];
		[leftPanel_leftHalfLabel2 setString:optionBString];
		optionCString = [[roundGameData objectForKey:@"Options"] objectForKey:@"OptionC"];
		[leftPanel_leftHalfLabel3 setString:optionCString];
		optionDString = [[roundGameData objectForKey:@"Options"] objectForKey:@"OptionD"];
		[leftPanel_leftHalfLabel4 setString:optionDString];
		[leftPanel_leftHalfMenuItem1 setIsEnabled:YES];
		[leftPanel_leftHalfMenuItem2 setIsEnabled:YES];
		[leftPanel_leftHalfMenuItem3 setIsEnabled:YES];
		[leftPanel_leftHalfMenuItem4 setIsEnabled:YES];
		[leftPanel_leftHalf setIsTouchEnabled:YES];
		rightDirectionPlayerControl = YES;
		leftDirectionPlayerControl = YES;
	}
	else
	{
		optionAString = [[roundGameData objectForKey:@"Options"]objectForKey:@"OptionA"];
		[leftPanel_rightHalfLabel1 setString:optionAString];
		optionBString = [[roundGameData objectForKey:@"Options"]objectForKey:@"OptionB"];
		[leftPanel_rightHalfLabel2 setString:optionBString];
		optionCString = [[roundGameData objectForKey:@"Options"] objectForKey:@"OptionC"];
		[leftPanel_rightHalfLabel3 setString:optionCString];
		optionDString = [[roundGameData objectForKey:@"Options"] objectForKey:@"OptionD"];
		[leftPanel_rightHalfLabel4 setString:optionDString];
		[leftPanel_rightHalfMenuItem1 setIsEnabled:YES];
		[leftPanel_rightHalfMenuItem2 setIsEnabled:YES];
		[leftPanel_rightHalfMenuItem3 setIsEnabled:YES];
		[leftPanel_rightHalfMenuItem4 setIsEnabled:YES];
		[leftPanel_rightHalf setIsTouchEnabled:YES];
		rightDirectionPlayerControl = YES;
		leftDirectionPlayerControl = YES;
	}
	
}

-(void)rightControlPanelLabelUpdate:(int)spriteInfoNumber
{
	
	NSString *plistPath= [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
	if (leftHide)
	{
		NSDictionary *nextRoundGameData = [[NSDictionary dictionaryWithContentsOfFile:plistPath] valueForKey:[NSString stringWithFormat:@"%d",spriteInfoNumber]];
		optionAString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionA"];
		[rightPanel_leftHalfLabel1 setString:optionAString];
		optionBString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionB"];
		[rightPanel_leftHalfLabel2 setString:optionBString];
		optionCString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionC"];
		[rightPanel_leftHalfLabel3 setString:optionCString];
		optionDString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionD"];
		[rightPanel_leftHalfLabel4 setString:optionDString];
		[rightPanel_leftHalfMenuItem1 setIsEnabled:YES];
		[rightPanel_leftHalfMenuItem2 setIsEnabled:YES];
		[rightPanel_leftHalfMenuItem3 setIsEnabled:YES];
		[rightPanel_leftHalfMenuItem4 setIsEnabled:YES];
		rightDirectionPlayerControl = YES;
		leftDirectionPlayerControl = YES;
	}
	else 
	{
		NSDictionary *nextRoundGameData = [[NSDictionary dictionaryWithContentsOfFile:plistPath] valueForKey:[NSString stringWithFormat:@"%d",spriteInfoNumber]];
		optionAString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionA"];
		[rightPanel_rightHalfLabel1 setString:optionAString];
		optionBString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionB"];
		[rightPanel_rightHalfLabel2 setString:optionBString];
		optionCString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionC"];
		[rightPanel_rightHalfLabel3 setString:optionCString];
		optionDString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionD"];
		[rightPanel_rightHalfLabel4 setString:optionDString];
		[rightPanel_rightHalfMenuItem1 setIsEnabled:YES];
		[rightPanel_rightHalfMenuItem2 setIsEnabled:YES];
		[rightPanel_rightHalfMenuItem3 setIsEnabled:YES];
		[rightPanel_rightHalfMenuItem4 setIsEnabled:YES];
		rightDirectionPlayerControl = YES;
		leftDirectionPlayerControl = YES;
	}
}

-(void)leftControlPanelLabelUpdate:(int)spriteInfoNumber
{
	
	NSString *plistPath= [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
	if (rightHide)
	{
		NSDictionary *nextRoundGameData = [[NSDictionary dictionaryWithContentsOfFile:plistPath] valueForKey:[NSString stringWithFormat:@"%d",spriteInfoNumber]];
		optionAString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionA"];
		[leftPanel_rightHalfLabel1 setString:optionAString];
		optionBString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionB"];
		[leftPanel_rightHalfLabel2 setString:optionBString];
		optionCString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionC"];
		[leftPanel_rightHalfLabel3 setString:optionCString];
		optionDString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionD"];
		[leftPanel_rightHalfLabel4 setString:optionDString];
		
		[leftPanel_rightHalfMenuItem1 setIsEnabled:YES];
		[leftPanel_rightHalfMenuItem2 setIsEnabled:YES];
		[leftPanel_rightHalfMenuItem3 setIsEnabled:YES];
		[leftPanel_rightHalfMenuItem4 setIsEnabled:YES];
		rightDirectionPlayerControl = YES;
		leftDirectionPlayerControl = YES;
	}
	else 
	{
		NSDictionary *nextRoundGameData = [[NSDictionary dictionaryWithContentsOfFile:plistPath] valueForKey:[NSString stringWithFormat:@"%d",spriteInfoNumber]];
		optionAString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionA"];
		[leftPanel_leftHalfLabel1 setString:optionAString];
		optionBString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionB"];
		[leftPanel_leftHalfLabel2 setString:optionBString];
		optionCString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionC"];
		[leftPanel_leftHalfLabel3 setString:optionCString];
		optionDString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionD"];
		[leftPanel_leftHalfLabel4 setString:optionDString];
		[leftPanel_leftHalfMenuItem1 setIsEnabled:YES];
		[leftPanel_leftHalfMenuItem2 setIsEnabled:YES];
		[leftPanel_leftHalfMenuItem3 setIsEnabled:YES];
		[leftPanel_leftHalfMenuItem4 setIsEnabled:YES];
		rightDirectionPlayerControl = YES;
		leftDirectionPlayerControl = YES;
	}
}

- (void) dealloc
{
	[super dealloc];
}

@end