//
//  PlayGameMusic.m
//  ChildIdentifyPicture
//
//  Created by the9_15 on 12-3-5.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "PlayGameMusic.h"


@implementation PlayGameMusic

-(id) init
{
	if( (self=[super init])) 
	{
		[CDSoundEngine setMixerSampleRate:CD_SAMPLE_RATE_MID];
		[[CDAudioManager sharedManager] setResignBehavior:kAMRBStopPlay autoHandle:YES];
		audioEngine = [SimpleAudioEngine sharedEngine];
		
		[audioEngine preloadBackgroundMusic:@"GameBG.caf"];
		[audioEngine preloadEffect:@"TitleMove.caf"];
		[audioEngine preloadEffect:@"CloudMove.caf"];
		[audioEngine preloadEffect:@"ThingsIn.caf"];
		[audioEngine preloadEffect:@"ChooseTrue.caf"];
		[audioEngine preloadEffect:@"ChooseFalse.caf"];
		[audioEngine preloadEffect:@"FinalFiveSecond.caf"];
		[audioEngine preloadEffect:@"GameStart.caf"];
		[audioEngine preloadEffect:@"InfoLayer.caf"];
		[audioEngine preloadEffect:@"Star.caf"];
		[audioEngine preloadEffect:@"TimeDown1.caf"];
		[audioEngine preloadEffect:@"TimeDown2.caf"];
	}
	return self;
}

-(void)gameBGSoundStateChange
{
	[audioEngine playBackgroundMusic:@"GameBG.caf" loop:YES];
}

-(void)thingsRotateInSound
{
	if([MusicSwitch shareConfig].gameSoundState)
		thingsRotateIn = [audioEngine playEffect:@"ThingsIn.caf"];
}

-(void)cloudMoveSound
{
	if([MusicSwitch shareConfig].gameSoundState)
		cloudMoveSound = [audioEngine playEffect:@"CloudMove.caf"];
}

-(void)titleMoveSound
{
	if([MusicSwitch shareConfig].gameSoundState)
		titleMoveSound = [audioEngine playEffect:@"TitleMove.caf"];
}
-(void)chooseTrueSound
{
	if([MusicSwitch shareConfig].gameSoundState)
		chooseTrueSound = [audioEngine playEffect:@"ChooseTrue.caf"];
}

-(void)chooseFalseSound
{
	if([MusicSwitch shareConfig].gameSoundState)
		chooseFalseSound = [audioEngine playEffect:@"ChooseFalse.caf"];
}

-(void)finalFiveSecondSound
{
	if([MusicSwitch shareConfig].gameSoundState)
		finalFiveSecondSound = [audioEngine playEffect:@"FinalFiveSecond.caf"];
}

-(void)gameMenuClickSound
{
	if([MusicSwitch shareConfig].gameSoundState)
		gameStartSound = [audioEngine playEffect:@"MenuClick.caf"];
}

-(void)infoLayerSound
{
	if([MusicSwitch shareConfig].gameSoundState)
		infoLayerSound = [audioEngine playEffect:@"InfoLayer.caf"];
}

-(void)starSound
{
	if([MusicSwitch shareConfig].gameSoundState)
		starSound = [audioEngine playEffect:@"Star.caf"];
}

-(void)timeDown1Sound
{
	if([MusicSwitch shareConfig].gameSoundState)
		timeDown1Sound = [audioEngine playEffect:@"TimeDown1.caf"];
}

-(void)timeDown2Sound
{
	if([MusicSwitch shareConfig].gameSoundState)
		timeDown2Sound = [audioEngine playEffect:@"TimeDown2.caf"];
}

-(void)gameSoundStateChangeOn
{
	if([MusicSwitch shareConfig].gameSoundState)
	{
		[[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"MusicStateKey"];
		[MusicSwitch shareConfig].gameSoundState = NO;
		[audioEngine pauseBackgroundMusic];
		
		[audioEngine stopEffect:chooseTrueSound];
		[audioEngine stopEffect:chooseFalseSound];
		[audioEngine stopEffect:finalFiveSecondSound];
		[audioEngine stopEffect:gameStartSound];
		[audioEngine stopEffect:infoLayerSound];
		[audioEngine stopEffect:starSound];
		[audioEngine stopEffect:timeDown1Sound];
		[audioEngine stopEffect:timeDown2Sound];
	}
	else
	{
		[[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"MusicStateKey"];
		[MusicSwitch shareConfig].gameSoundState = YES;
		[audioEngine setBackgroundMusicVolume:1.0f];
		[audioEngine rewindBackgroundMusic];
		[audioEngine resumeBackgroundMusic];
	}
}

-(void)gameSoundStateChangeOff
{
	if(![MusicSwitch shareConfig].gameSoundState)
	{
		[[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"MusicStateKey"];
		[MusicSwitch shareConfig].gameSoundState = YES;
		
		[audioEngine setBackgroundMusicVolume:1.0f];
		[audioEngine rewindBackgroundMusic];
		if(![audioEngine isBackgroundMusicPlaying])
			[audioEngine playBackgroundMusic:@"GameBG.caf"];
		else
			[audioEngine resumeBackgroundMusic];
	}
	else
	{
		[[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"MusicStateKey"];
		[MusicSwitch shareConfig].gameSoundState = NO;
		[audioEngine pauseBackgroundMusic];
		
		[audioEngine stopEffect:chooseTrueSound];
		[audioEngine stopEffect:chooseFalseSound];
		[audioEngine stopEffect:finalFiveSecondSound];
		[audioEngine stopEffect:gameStartSound];
		[audioEngine stopEffect:infoLayerSound];
		[audioEngine stopEffect:starSound];
		[audioEngine stopEffect:timeDown1Sound];
		[audioEngine stopEffect:timeDown2Sound];
		[audioEngine stopEffect:thingsRotateIn];
		[audioEngine stopEffect:cloudMoveSound];
		[audioEngine stopEffect:titleMoveSound];
		
	}
}

- (void) dealloc
{
	[super dealloc];
}
@end
