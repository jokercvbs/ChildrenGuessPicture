//
//  HelloWorldLayer.h
//  ChildIdentifyPicture
//
//  Created by LXC on 12-2-18.
//  Copyright __MyCompanyName__ 2012年. All rights reserved.
//

NSString* pictureName;
float attenuation;

int rightPlayerScoreCount;
int leftPlayerScoreCount;
BOOL pauseState;
enum  
{
	kRoundOne,
	kRoundTwo,
	kRoundThree,
	kRoundFour,
};
#import "cocos2d.h"
#import "ControlPanelLogic.h"
#import "MainMenuScene.h"
#import "ControlPanelUI.h"
#import "PopInfoLayer.h"
#import "PlayGameMusic.h"
#import "SimpleAudioEngine.h"
#import "GameConfigDefine.h"
#import "GamePauseScene.h"

@class RightControlPanelUI;
@class LeftControlPanelUI;

RightControlPanelUI* rightControlPanel;
LeftControlPanelUI* leftControlPanel;

CCLabelTTF* rightPlayerScoreCountLabel;
CCLabelTTF* leftPlayerScoreCountLabel;
CCSprite* identifyPicture;

PopInfoLayer* popInfoLayer;

@interface PlayGameScene : CCLayer
{
	CGSize winSize;
	CCSprite* playGameSceneBG;
	CCSprite* blackboard;
	CCMenu* playGameMenu;
	CCLabelTTF* rightUpCornerClockLabel;
	CCLabelTTF* leftDownCornerClockLabel;
	
	CCMenuItemSprite* gamePauseMenuItem;
	CCMenuItemSprite* gameResumeMenuItem;
	
	CCMenuItemSprite* gameMusicPlayMenuItem;
	CCMenuItemSprite* gameMusicStopMenuItem;
	
	CCMenuItemToggle* gameMusicStateChange;
	
	CCSprite* Windmill;
	
	CCSprite* rightControlPanelYellowFlower;
	CCSprite* rightControlPanelGreenFlower;
	CCSprite* rightControlPanelBlueFlower;
	CCSprite* rightControlPanelPinkFlower;
	
	CCSprite *leftControlPanelYellowFlower;
	CCSprite *leftControlPanelGreenFlower;
	CCSprite *leftControlPanelBlueFlower;
	CCSprite *leftControlPanelPinkFlower;
	
	CCSprite* rightControlPanelCountBG;
	CCSprite* leftControlPanelCountBG;
	
	int rightRoundCount;
	int leftRoundCount;
	
	int time;
	
	CCSprite* readyLabelOne;
	CCSprite* readyLabelTwo;
	CCSprite* readyLabelThree;
	
	CCParticleSystem *rightControlPanelParticle;
	CCParticleSystem *leftControlPanelParticle;
	
	CCMenuItemToggle* gameStateChange;
	
	BOOL gameRunState;
}

+(CCScene *) scene;
-(void)show;
-(void)gameStart;
-(void)readyTime;
-(void)playGameSceneUIInit;
@end
