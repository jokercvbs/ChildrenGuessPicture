//
//  ControlPanelUI.h
//  ChildIdentifyPicture
//
//  Created by LXC on 12-2-25.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "ControlPanelLogic.h"
#import "GameConfigDefine.h"

//右控制面板UI变量
CCMenuItemSprite* rightPanel_leftHalfMenuItem1;
CCMenuItemSprite* rightPanel_leftHalfMenuItem2;
CCMenuItemSprite* rightPanel_leftHalfMenuItem3;
CCMenuItemSprite* rightPanel_leftHalfMenuItem4;
CCMenuItemSprite* rightPanel_rightHalfMenuItem1;
CCMenuItemSprite* rightPanel_rightHalfMenuItem2;
CCMenuItemSprite* rightPanel_rightHalfMenuItem3;
CCMenuItemSprite* rightPanel_rightHalfMenuItem4;

CCLabelTTF *rightPanel_rightHalfLabel1;
CCLabelTTF *rightPanel_rightHalfLabel2;
CCLabelTTF *rightPanel_rightHalfLabel3;
CCLabelTTF *rightPanel_rightHalfLabel4;
CCLabelTTF *rightPanel_leftHalfLabel1;
CCLabelTTF *rightPanel_leftHalfLabel2;
CCLabelTTF *rightPanel_leftHalfLabel3;
CCLabelTTF *rightPanel_leftHalfLabel4;


//左控制面板UI变量
CCMenuItemSprite* leftPanel_rightHalfMenuItem1;
CCMenuItemSprite* leftPanel_rightHalfMenuItem2;
CCMenuItemSprite* leftPanel_rightHalfMenuItem3;
CCMenuItemSprite* leftPanel_rightHalfMenuItem4;
CCMenuItemSprite* leftPanel_leftHalfMenuItem1;
CCMenuItemSprite* leftPanel_leftHalfMenuItem2;
CCMenuItemSprite* leftPanel_leftHalfMenuItem3;
CCMenuItemSprite* leftPanel_leftHalfMenuItem4;

CCLabelTTF *leftPanel_rightHalfLabel1;
CCLabelTTF *leftPanel_rightHalfLabel2;
CCLabelTTF *leftPanel_rightHalfLabel3;
CCLabelTTF *leftPanel_rightHalfLabel4;
CCLabelTTF *leftPanel_leftHalfLabel1;
CCLabelTTF *leftPanel_leftHalfLabel2;
CCLabelTTF *leftPanel_leftHalfLabel3;
CCLabelTTF *leftPanel_leftHalfLabel4;

CCMenu *rightPanel_leftHalf;
CCMenu *rightPanel_rightHalf;
CCMenu *leftPanel_leftHalf;
CCMenu *leftPanel_rightHalf;

@class RightControlPanelLogic;
@class LeftControlPanelLogic;
RightControlPanelLogic *rightControlPanelLogic;
LeftControlPanelLogic *leftControlPanelLogic;

@interface RightControlPanelUI : CCSprite
{
    
}

@end


@interface LeftControlPanelUI : CCSprite
{
    
}

@end
