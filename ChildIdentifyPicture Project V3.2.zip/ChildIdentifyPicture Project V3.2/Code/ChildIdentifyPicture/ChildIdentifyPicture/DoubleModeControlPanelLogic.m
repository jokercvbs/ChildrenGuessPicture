//
//  DoubleModeControlPanelLogic.m
//  ChildIdentifyPicture
//
//  Created by the9_15 on 12-3-9.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "DoubleModeControlPanelLogic.h"


@implementation DoubleModeControlPanelLogic
-(id) init
{
	if( (self=[super init])) 
	{
		doubleModePlistPath= [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
		doubleModeSaveRandomArray = [[NSMutableArray alloc] initWithCapacity:20];
	}
	return self;
}

-(void)randomPictureInfoID
{
	doubleModePictureInfoID = arc4random()%INFO_COUNT;
	if ([doubleModeSaveRandomArray count])
	{
		for (int i=0; i<[doubleModeSaveRandomArray count];) 
		{
			for (int j=0; j<=100; ++j)
			{
				if (doubleModePictureInfoID == [[doubleModeSaveRandomArray objectAtIndex:i] intValue])
				{
					i=0;
					doubleModePictureInfoID = arc4random()%INFO_COUNT;
					//break;
				}
				else if (i==[doubleModeSaveRandomArray count]-1)
				{
					[doubleModeSaveRandomArray addObject:[NSNumber numberWithInt:doubleModePictureInfoID]];
					break;
				}
				else
				{
					++i;
					continue;
				}
			}
			break;
		}
	}
	else
	{
		[doubleModeSaveRandomArray addObject:[NSNumber numberWithInt:doubleModePictureInfoID]];
	}
}

-(void)identifyPictureFun
{
	doubleModePlistPath= [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
	NSDictionary *roundGameData=[[NSDictionary dictionaryWithContentsOfFile:doubleModePlistPath] valueForKey:[NSString stringWithFormat:@"%d",doubleModePictureInfoID]];
	doubleModePictureName = [roundGameData objectForKey:@"PictureName"];
	[doubleModeIdentifyPicture setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:doubleModePictureName]];
	doubleModeAttenuation = 120.0f;
}
-(void)timeIsDown
{
	//控制面板动作
	id callLabelUpdate = [CCCallFunc actionWithTarget:self selector:@selector(controlPanelSendArgument)];
	id controlPanelCanTouchChange = [CCCallFunc actionWithTarget:self selector:@selector(controlPanelCanTouchChangeFun)];
	id upHideChange = [CCCallFunc actionWithTarget:self selector:@selector(upHideChangeFun)];
	id controlPanelRotateAction = [CCRotateBy actionWithDuration:0.5 angle:180];
	
	//识别图片动作
	id preIdentifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.4 scale:0];
	id identifyPictureChange = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureFun)];
	
	id identifyPictureScaleToLarge = [CCScaleTo actionWithDuration:0.4 scale:1.4];
	id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
	
	id identifyPictureSound = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureSoundFun)];
	
	if (doubleSceneTime > 0)
	{
		[controlPanel runAction:[CCSequence actions:controlPanelCanTouchChange,callLabelUpdate,upHideChange,controlPanelRotateAction,nil]];
		[doubleModeIdentifyPicture runAction:[CCSequence actions:preIdentifyPictureScaleToSmall,identifyPictureChange,identifyPictureScaleToLarge,identifyPictureSound,identifyPictureScaleToSmall, nil]];
	}
	
}

-(void)chooseOption1
{
	doubleModePlistPath= [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
	NSDictionary *roundGameData=[[NSDictionary dictionaryWithContentsOfFile:doubleModePlistPath] valueForKey:[NSString stringWithFormat:@"%d",doubleModePictureInfoID]];
	trueOption = [[roundGameData objectForKey:@"TrueOptions"] intValue];
	
	id callLabelUpdate = [CCCallFunc actionWithTarget:self selector:@selector(controlPanelSendArgument)];
	
	id controlPanelCanTouchChange = [CCCallFunc actionWithTarget:self selector:@selector(controlPanelCanTouchChangeFun)];
	
	id upHideChange = [CCCallFunc actionWithTarget:self selector:@selector(upHideChangeFun)];
	
	id controlPanelRotateAction = [CCRotateBy actionWithDuration:0.5 angle:180];
	
	
	id preIdentifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.4 scale:0];
	id identifyPictureChange = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureFun)];
	
	id identifyPictureScaleToLarge = [CCScaleTo actionWithDuration:0.4 scale:1.4];
	id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
	
	id identifyPictureSound = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureSoundFun)];
	
	if (trueOption == kOptionA)
	{
		if(![controlPanel numberOfRunningActions])
		{
			if(upHide)
			{
				[controlPanel_downHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_downHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_downHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_downHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_downHalfMenuItem1 setIsEnabled:NO];
				[controlPanel_downHalfMenuItem2 setIsEnabled:NO];
				[controlPanel_downHalfMenuItem3 setIsEnabled:NO];
				[controlPanel_downHalfMenuItem4 setIsEnabled:NO];
			}
			else 
			{
				[controlPanel_upHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_upHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_upHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_upHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_upHalfMenuItem1 setIsEnabled:NO];
				[controlPanel_upHalfMenuItem2 setIsEnabled:NO];
				[controlPanel_upHalfMenuItem3 setIsEnabled:NO];
				[controlPanel_upHalfMenuItem4 setIsEnabled:NO];
			}
            
            ++trueOptionCount;
            if (trueOptionCount < doubleSceneRoundCount) 
            {
                [self randomPictureInfoID];
                [controlPanel runAction:[CCSequence actions:controlPanelCanTouchChange,callLabelUpdate,upHideChange,controlPanelRotateAction,nil]];
                [doubleModeIdentifyPicture runAction:[CCSequence actions:preIdentifyPictureScaleToSmall,identifyPictureChange,identifyPictureScaleToLarge,identifyPictureSound,identifyPictureScaleToSmall, nil]];
            }
            else if(trueOptionCount == doubleSceneRoundCount)
            {
                [[DoubleModePlayGameScene shareScene]gotoNextRound];
            }
            [scoreLabel setString:[NSString stringWithFormat:@"%d/%d",trueOptionCount,doubleSceneRoundCount]];
			[playGameMusic chooseTrueSound];

		}
	}
	else 
	{
		[playGameMusic chooseFalseSound];
		if(upHide)
		{
			[controlPanel_downHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_downHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_downHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_downHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_downHalfMenuItem1 setIsEnabled:NO];
			[controlPanel_downHalfMenuItem2 setIsEnabled:NO];
			[controlPanel_downHalfMenuItem3 setIsEnabled:NO];
			[controlPanel_downHalfMenuItem4 setIsEnabled:NO];
		}
		else 
		{
			[controlPanel_upHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_upHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_upHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_upHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_upHalfMenuItem1 setIsEnabled:NO];
			[controlPanel_upHalfMenuItem2 setIsEnabled:NO];
			[controlPanel_upHalfMenuItem3 setIsEnabled:NO];
			[controlPanel_upHalfMenuItem4 setIsEnabled:NO];
		}
		[self randomPictureInfoID];
		doubleModePopInfolayer.position = ccp(512,384);
		[playGameMusic infoLayerSound];
		id popInfoScaleToLarge = [CCScaleTo actionWithDuration:0.6 scale:1.2];
		id popInfoScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
		id popInfoDelayTime = [CCDelayTime actionWithDuration:1.0];
		id popInfoEndisableScale = [CCScaleTo actionWithDuration:0.6 scale:0];
		id identifyPictureAndControlPanelAction = [CCCallFunc actionWithTarget:self selector:@selector(timeIsDown)];
		id popInfoSequence = [CCSequence actions:popInfoScaleToLarge,popInfoScaleToSmall,popInfoDelayTime,popInfoEndisableScale,identifyPictureAndControlPanelAction,nil];
		CCSprite* popInfoLayerInfo = (CCSprite*)[doubleModePopInfolayer getChildByTag:kFrameInfo];
		[popInfoLayerInfo setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"ComeOn.png"]];
		[doubleModePopInfolayer runAction:popInfoSequence];
		
		
	}	
}

-(void)chooseOption2
{
	doubleModePlistPath= [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
	NSDictionary *roundGameData=[[NSDictionary dictionaryWithContentsOfFile:doubleModePlistPath] valueForKey:[NSString stringWithFormat:@"%d",doubleModePictureInfoID]];
	trueOption = [[roundGameData objectForKey:@"TrueOptions"] intValue];
	
	id callLabelUpdate = [CCCallFunc actionWithTarget:self selector:@selector(controlPanelSendArgument)];
	
	id controlPanelCanTouchChange = [CCCallFunc actionWithTarget:self selector:@selector(controlPanelCanTouchChangeFun)];
	
	id upHideChange = [CCCallFunc actionWithTarget:self selector:@selector(upHideChangeFun)];
	
	id controlPanelRotateAction = [CCRotateBy actionWithDuration:0.5 angle:180];
	
	
	id preIdentifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.4 scale:0];
	id identifyPictureChange = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureFun)];
	
	id identifyPictureScaleToLarge = [CCScaleTo actionWithDuration:0.4 scale:1.4];
	id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
	
	id identifyPictureSound = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureSoundFun)];
	
	if (trueOption == kOptionB)
	{
		if(![controlPanel numberOfRunningActions])
		{
			if(upHide)
			{
				[controlPanel_downHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_downHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_downHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_downHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_downHalfMenuItem1 setIsEnabled:NO];
				[controlPanel_downHalfMenuItem2 setIsEnabled:NO];
				[controlPanel_downHalfMenuItem3 setIsEnabled:NO];
				[controlPanel_downHalfMenuItem4 setIsEnabled:NO];
			}
			else 
			{
				[controlPanel_upHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_upHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_upHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_upHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_upHalfMenuItem1 setIsEnabled:NO];
				[controlPanel_upHalfMenuItem2 setIsEnabled:NO];
				[controlPanel_upHalfMenuItem3 setIsEnabled:NO];
				[controlPanel_upHalfMenuItem4 setIsEnabled:NO];
			}
            ++trueOptionCount;
            if (trueOptionCount < doubleSceneRoundCount) 
            {
                [self randomPictureInfoID];
                [controlPanel runAction:[CCSequence actions:controlPanelCanTouchChange,callLabelUpdate,upHideChange,controlPanelRotateAction,nil]];
                [doubleModeIdentifyPicture runAction:[CCSequence actions:preIdentifyPictureScaleToSmall,identifyPictureChange,identifyPictureScaleToLarge,identifyPictureSound,identifyPictureScaleToSmall, nil]];
            }
            else if(trueOptionCount == doubleSceneRoundCount)
            {
                [[DoubleModePlayGameScene shareScene]gotoNextRound];
            }
            [scoreLabel setString:[NSString stringWithFormat:@"%d/%d",trueOptionCount,doubleSceneRoundCount]];
			[playGameMusic chooseTrueSound];
		}
	}
	else 
	{
		[playGameMusic chooseFalseSound];
		if(upHide)
		{
			[controlPanel_downHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_downHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_downHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_downHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_downHalfMenuItem1 setIsEnabled:NO];
			[controlPanel_downHalfMenuItem2 setIsEnabled:NO];
			[controlPanel_downHalfMenuItem3 setIsEnabled:NO];
			[controlPanel_downHalfMenuItem4 setIsEnabled:NO];
		}
		else 
		{
			[controlPanel_upHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_upHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_upHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_upHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_upHalfMenuItem1 setIsEnabled:NO];
			[controlPanel_upHalfMenuItem2 setIsEnabled:NO];
			[controlPanel_upHalfMenuItem3 setIsEnabled:NO];
			[controlPanel_upHalfMenuItem4 setIsEnabled:NO];
		}
		[self randomPictureInfoID];
		doubleModePopInfolayer.position = ccp(512,384);
		[playGameMusic infoLayerSound];
		id popInfoScaleToLarge = [CCScaleTo actionWithDuration:0.6 scale:1.2];
		id popInfoScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
		id popInfoDelayTime = [CCDelayTime actionWithDuration:1.0];
		id popInfoEndisableScale = [CCScaleTo actionWithDuration:0.6 scale:0];
		id identifyPictureAndControlPanelAction = [CCCallFunc actionWithTarget:self selector:@selector(timeIsDown)];
		id popInfoSequence = [CCSequence actions:popInfoScaleToLarge,popInfoScaleToSmall,popInfoDelayTime,popInfoEndisableScale,identifyPictureAndControlPanelAction,nil];
		CCSprite* popInfoLayerInfo = (CCSprite*)[doubleModePopInfolayer getChildByTag:kFrameInfo];
		[popInfoLayerInfo setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"ComeOn.png"]];
		[doubleModePopInfolayer runAction:popInfoSequence];
		
	}
}

-(void)chooseOption3
{
	doubleModePlistPath= [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
	NSDictionary *roundGameData=[[NSDictionary dictionaryWithContentsOfFile:doubleModePlistPath] valueForKey:[NSString stringWithFormat:@"%d",doubleModePictureInfoID]];
	trueOption = [[roundGameData objectForKey:@"TrueOptions"] intValue];
	
	id callLabelUpdate = [CCCallFunc actionWithTarget:self selector:@selector(controlPanelSendArgument)];
	
	id controlPanelCanTouchChange = [CCCallFunc actionWithTarget:self selector:@selector(controlPanelCanTouchChangeFun)];
	
	id upHideChange = [CCCallFunc actionWithTarget:self selector:@selector(upHideChangeFun)];
	
	id controlPanelRotateAction = [CCRotateBy actionWithDuration:0.5 angle:180];
	
	
	id preIdentifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.4 scale:0];
	id identifyPictureChange = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureFun)];
	
	id identifyPictureScaleToLarge = [CCScaleTo actionWithDuration:0.4 scale:1.4];
	id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
	
	id identifyPictureSound = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureSoundFun)];
	
	if (trueOption == kOptionC)
	{
		if(![controlPanel numberOfRunningActions])
		{
			if(upHide)
			{
				[controlPanel_downHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_downHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_downHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_downHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_downHalfMenuItem1 setIsEnabled:NO];
				[controlPanel_downHalfMenuItem2 setIsEnabled:NO];
				[controlPanel_downHalfMenuItem3 setIsEnabled:NO];
				[controlPanel_downHalfMenuItem4 setIsEnabled:NO];
			}
			else 
			{
				[controlPanel_upHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_upHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_upHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_upHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_upHalfMenuItem1 setIsEnabled:NO];
				[controlPanel_upHalfMenuItem2 setIsEnabled:NO];
				[controlPanel_upHalfMenuItem3 setIsEnabled:NO];
				[controlPanel_upHalfMenuItem4 setIsEnabled:NO];
			}
            ++trueOptionCount;
            if (trueOptionCount < doubleSceneRoundCount) 
            {
                [self randomPictureInfoID];
                [controlPanel runAction:[CCSequence actions:controlPanelCanTouchChange,callLabelUpdate,upHideChange,controlPanelRotateAction,nil]];
                [doubleModeIdentifyPicture runAction:[CCSequence actions:preIdentifyPictureScaleToSmall,identifyPictureChange,identifyPictureScaleToLarge,identifyPictureSound,identifyPictureScaleToSmall, nil]];
            }
            else if(trueOptionCount == doubleSceneRoundCount)
            {
                [[DoubleModePlayGameScene shareScene]gotoNextRound];
            }
            [scoreLabel setString:[NSString stringWithFormat:@"%d/%d",trueOptionCount,doubleSceneRoundCount]];
			[playGameMusic chooseTrueSound];
		}
	}
	else 
	{
		[playGameMusic chooseFalseSound];
		if(upHide)
		{
			[controlPanel_downHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_downHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_downHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_downHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_downHalfMenuItem1 setIsEnabled:NO];
			[controlPanel_downHalfMenuItem2 setIsEnabled:NO];
			[controlPanel_downHalfMenuItem3 setIsEnabled:NO];
			[controlPanel_downHalfMenuItem4 setIsEnabled:NO];
		}
		else 
		{
			[controlPanel_upHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_upHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_upHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_upHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_upHalfMenuItem1 setIsEnabled:NO];
			[controlPanel_upHalfMenuItem2 setIsEnabled:NO];
			[controlPanel_upHalfMenuItem3 setIsEnabled:NO];
			[controlPanel_upHalfMenuItem4 setIsEnabled:NO];
		}
		[self randomPictureInfoID];
		doubleModePopInfolayer.position = ccp(512,384);
		[playGameMusic infoLayerSound];
		id popInfoScaleToLarge = [CCScaleTo actionWithDuration:0.6 scale:1.2];
		id popInfoScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
		id popInfoDelayTime = [CCDelayTime actionWithDuration:1.0];
		id popInfoEndisableScale = [CCScaleTo actionWithDuration:0.6 scale:0];
		id identifyPictureAndControlPanelAction = [CCCallFunc actionWithTarget:self selector:@selector(timeIsDown)];
		id popInfoSequence = [CCSequence actions:popInfoScaleToLarge,popInfoScaleToSmall,popInfoDelayTime,popInfoEndisableScale,identifyPictureAndControlPanelAction,nil];
		CCSprite* popInfoLayerInfo = (CCSprite*)[doubleModePopInfolayer getChildByTag:kFrameInfo];
		[popInfoLayerInfo setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"ComeOn.png"]];
		[doubleModePopInfolayer runAction:popInfoSequence];
	}
}

-(void)chooseOption4
{
	doubleModePlistPath= [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
	NSDictionary *roundGameData=[[NSDictionary dictionaryWithContentsOfFile:doubleModePlistPath] valueForKey:[NSString stringWithFormat:@"%d",doubleModePictureInfoID]];
	trueOption = [[roundGameData objectForKey:@"TrueOptions"] intValue];
	
	id callLabelUpdate = [CCCallFunc actionWithTarget:self selector:@selector(controlPanelSendArgument)];
	
	id controlPanelCanTouchChange = [CCCallFunc actionWithTarget:self selector:@selector(controlPanelCanTouchChangeFun)];
	
	id upHideChange = [CCCallFunc actionWithTarget:self selector:@selector(upHideChangeFun)];
	
	id controlPanelRotateAction = [CCRotateBy actionWithDuration:0.5 angle:180];
	
	
	id preIdentifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.4 scale:0];
	id identifyPictureChange = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureFun)];
	
	id identifyPictureScaleToLarge = [CCScaleTo actionWithDuration:0.4 scale:1.4];
	id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
	
	id identifyPictureSound = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureSoundFun)];
	
	if (trueOption == kOptionD)
	{
		if(![controlPanel numberOfRunningActions])
		{
			if(upHide)
			{
				[controlPanel_downHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_downHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_downHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_downHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_downHalfMenuItem1 setIsEnabled:NO];
				[controlPanel_downHalfMenuItem2 setIsEnabled:NO];
				[controlPanel_downHalfMenuItem3 setIsEnabled:NO];
				[controlPanel_downHalfMenuItem4 setIsEnabled:NO];
			}
			else 
			{
				[controlPanel_upHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_upHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_upHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_upHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
				[controlPanel_upHalfMenuItem1 setIsEnabled:NO];
				[controlPanel_upHalfMenuItem2 setIsEnabled:NO];
				[controlPanel_upHalfMenuItem3 setIsEnabled:NO];
				[controlPanel_upHalfMenuItem4 setIsEnabled:NO];
			}
            ++trueOptionCount;
            if (trueOptionCount < doubleSceneRoundCount) 
            {
                [self randomPictureInfoID];
                [controlPanel runAction:[CCSequence actions:controlPanelCanTouchChange,callLabelUpdate,upHideChange,controlPanelRotateAction,nil]];
                [doubleModeIdentifyPicture runAction:[CCSequence actions:preIdentifyPictureScaleToSmall,identifyPictureChange,identifyPictureScaleToLarge,identifyPictureSound,identifyPictureScaleToSmall, nil]];
            }
            else if(trueOptionCount == doubleSceneRoundCount)
            {
                [[DoubleModePlayGameScene shareScene]gotoNextRound];
            }
            [scoreLabel setString:[NSString stringWithFormat:@"%d/%d",trueOptionCount,doubleSceneRoundCount]];
			[playGameMusic chooseTrueSound];
		}
	}
	else 
	{
		[playGameMusic chooseFalseSound];
		if(upHide)
		{
			[controlPanel_downHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_downHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_downHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_downHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_downHalfMenuItem1 setIsEnabled:NO];
			[controlPanel_downHalfMenuItem2 setIsEnabled:NO];
			[controlPanel_downHalfMenuItem3 setIsEnabled:NO];
			[controlPanel_downHalfMenuItem4 setIsEnabled:NO];
		}
		else 
		{
			[controlPanel_upHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_upHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_upHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_upHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]];
			[controlPanel_upHalfMenuItem1 setIsEnabled:NO];
			[controlPanel_upHalfMenuItem2 setIsEnabled:NO];
			[controlPanel_upHalfMenuItem3 setIsEnabled:NO];
			[controlPanel_upHalfMenuItem4 setIsEnabled:NO];
		}
		[self randomPictureInfoID];
		doubleModePopInfolayer.position = ccp(512,384);
		[playGameMusic infoLayerSound];
		id popInfoScaleToLarge = [CCScaleTo actionWithDuration:0.6 scale:1.2];
		id popInfoScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
		id popInfoDelayTime = [CCDelayTime actionWithDuration:1.0];
		id popInfoEndisableScale = [CCScaleTo actionWithDuration:0.6 scale:0];
		id identifyPictureAndControlPanelAction = [CCCallFunc actionWithTarget:self selector:@selector(timeIsDown)];
		id popInfoSequence = [CCSequence actions:popInfoScaleToLarge,popInfoScaleToSmall,popInfoDelayTime,popInfoEndisableScale,identifyPictureAndControlPanelAction,nil];
		CCSprite* popInfoLayerInfo = (CCSprite*)[doubleModePopInfolayer getChildByTag:kFrameInfo];
		[popInfoLayerInfo setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"ComeOn.png"]];
		[doubleModePopInfolayer runAction:popInfoSequence];
	}
}

-(void)upHideChangeFun
{
	if (upHide)
		upHide = NO;
	else
		upHide = YES;
}

-(void)controlPanelSendArgument
{
	[self controlPanelLabelUpdate:doubleModePictureInfoID];
}

-(void)controlPanelLabelInit
{
	[self randomPictureInfoID];
	doubleModePlistPath = [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
	NSDictionary *roundGameData=[[NSDictionary dictionaryWithContentsOfFile:doubleModePlistPath] valueForKey:[NSString stringWithFormat:@"%d",doubleModePictureInfoID]];
	doubleModePictureName = [roundGameData objectForKey:@"PictureName"];
	[doubleModeIdentifyPicture setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:doubleModePictureName]];
	
	if(!upHide)
	{
		optionAString = [[roundGameData objectForKey:@"Options"]objectForKey:@"OptionA"];
		[controlPanel_downHalfLabel1 setString:optionAString];
		optionBString = [[roundGameData objectForKey:@"Options"]objectForKey:@"OptionB"];
		[controlPanel_downHalfLabel2 setString:optionBString];
		optionCString = [[roundGameData objectForKey:@"Options"] objectForKey:@"OptionC"];
		[controlPanel_downHalfLabel3 setString:optionCString];
		optionDString = [[roundGameData objectForKey:@"Options"] objectForKey:@"OptionD"];
		[controlPanel_downHalfLabel4 setString:optionDString];
		
		[controlPanel_downHalfMenuItem1 setIsEnabled:YES];
		[controlPanel_downHalfMenuItem2 setIsEnabled:YES];
		[controlPanel_downHalfMenuItem3 setIsEnabled:YES];
		[controlPanel_downHalfMenuItem4 setIsEnabled:YES];
		[controlPanel_downHalf setIsTouchEnabled:YES];
	}
	else
	{
		optionAString = [[roundGameData objectForKey:@"Options"]objectForKey:@"OptionA"];
		[controlPanel_upHalfLabel1 setString:optionAString];
		optionBString = [[roundGameData objectForKey:@"Options"]objectForKey:@"OptionB"];
		[controlPanel_upHalfLabel2 setString:optionBString];
		optionCString = [[roundGameData objectForKey:@"Options"] objectForKey:@"OptionC"];
		[controlPanel_upHalfLabel3 setString:optionCString];
		optionDString = [[roundGameData objectForKey:@"Options"] objectForKey:@"OptionD"];
		[controlPanel_upHalfLabel4 setString:optionDString];
		
		[controlPanel_upHalfMenuItem1 setIsEnabled:YES];
		[controlPanel_upHalfMenuItem2 setIsEnabled:YES];
		[controlPanel_upHalfMenuItem3 setIsEnabled:YES];
		[controlPanel_upHalfMenuItem4 setIsEnabled:YES];
		[controlPanel_upHalf setIsTouchEnabled:YES];
	}
}

-(void)controlPanelLabelUpdate:(int)spriteInfoNumber
{
	
	doubleModePlistPath= [[NSBundle mainBundle] pathForResource:@"SpriteSelectOptions" ofType:@"plist"];
	
	if (upHide)
	{
		NSDictionary *nextRoundGameData = [[NSDictionary dictionaryWithContentsOfFile:doubleModePlistPath] valueForKey:[NSString stringWithFormat:@"%d",spriteInfoNumber]];
		optionAString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionA"];
		[controlPanel_upHalfLabel1 setString:optionAString];
		optionBString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionB"];
		[controlPanel_upHalfLabel2 setString:optionBString];
		optionCString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionC"];
		[controlPanel_upHalfLabel3 setString:optionCString];
		optionDString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionD"];
		[controlPanel_upHalfLabel4 setString:optionDString];
		[controlPanel_upHalfMenuItem1 setIsEnabled:YES];
		[controlPanel_upHalfMenuItem2 setIsEnabled:YES];
		[controlPanel_upHalfMenuItem3 setIsEnabled:YES];
		[controlPanel_upHalfMenuItem4 setIsEnabled:YES];
		rightDirectionPlayerControl = YES;
		leftDirectionPlayerControl = YES;
	}
	else 
	{
		NSDictionary *nextRoundGameData = [[NSDictionary dictionaryWithContentsOfFile:doubleModePlistPath] valueForKey:[NSString stringWithFormat:@"%d",spriteInfoNumber]];
		optionAString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionA"];
		[controlPanel_downHalfLabel1 setString:optionAString];
		optionBString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionB"];
		[controlPanel_downHalfLabel2 setString:optionBString];
		optionCString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionC"];
		[controlPanel_downHalfLabel3 setString:optionCString];
		optionDString = [[nextRoundGameData objectForKey:@"Options"]objectForKey:@"OptionD"];
		[controlPanel_downHalfLabel4 setString:optionDString];
		[controlPanel_downHalfMenuItem1 setIsEnabled:YES];
		[controlPanel_downHalfMenuItem2 setIsEnabled:YES];
		[controlPanel_downHalfMenuItem3 setIsEnabled:YES];
		[controlPanel_downHalfMenuItem4 setIsEnabled:YES];
		rightDirectionPlayerControl = YES;
		leftDirectionPlayerControl = YES;
	}
}

-(void)controlPanelCanTouchChangeFun
{
	upHide
	?[controlPanel_upHalf setIsTouchEnabled:YES]
	:[controlPanel_downHalf setIsTouchEnabled:YES];
}

-(void)identifyPictureSoundFun
{
	[playGameMusic thingsRotateInSound];
}

- (void) dealloc
{
	[doubleModeSaveRandomArray release];
	doubleModeSaveRandomArray = nil;
	[super dealloc];
}
@end
