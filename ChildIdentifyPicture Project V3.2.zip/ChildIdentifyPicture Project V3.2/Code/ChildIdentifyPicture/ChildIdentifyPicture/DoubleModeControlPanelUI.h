//
//  DoubleModeControlPanel.h
//  ChildIdentifyPicture
//
//  Created by the9_15 on 12-3-9.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "GameConfigDefine.h"
#import "DoubleModeControlPanelLogic.h"

CCLabelTTF* controlPanel_upHalfLabel1;
CCLabelTTF* controlPanel_upHalfLabel2;
CCLabelTTF* controlPanel_upHalfLabel3;
CCLabelTTF* controlPanel_upHalfLabel4;
CCLabelTTF* controlPanel_downHalfLabel1;
CCLabelTTF* controlPanel_downHalfLabel2;
CCLabelTTF* controlPanel_downHalfLabel3;
CCLabelTTF* controlPanel_downHalfLabel4;
CCMenuItemSprite* controlPanel_upHalfMenuItem1;
CCMenuItemSprite* controlPanel_upHalfMenuItem2;
CCMenuItemSprite* controlPanel_upHalfMenuItem3;
CCMenuItemSprite* controlPanel_upHalfMenuItem4;
CCMenuItemSprite* controlPanel_downHalfMenuItem1;
CCMenuItemSprite* controlPanel_downHalfMenuItem2;
CCMenuItemSprite* controlPanel_downHalfMenuItem3;
CCMenuItemSprite* controlPanel_downHalfMenuItem4;
CCMenu* controlPanel_upHalf;
CCMenu* controlPanel_downHalf;

@class DoubleModeControlPanelLogic;
DoubleModeControlPanelLogic* doubleModeControlPanelLogic;

@interface DoubleModeControlPanelUI : CCNode 
{
	
}

@end