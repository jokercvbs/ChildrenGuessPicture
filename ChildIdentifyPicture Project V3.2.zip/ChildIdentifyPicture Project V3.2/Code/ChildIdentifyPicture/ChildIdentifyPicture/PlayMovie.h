//
//  PlayMovie.h
//  childflower
//
//  Created by Ben on 12-2-20.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import <MediaPlayer/MediaPlayer.h>
#import <AVFoundation/AVFoundation.h>



@interface PlayMovie : CCLayer 
{
	MPMoviePlayerController *moviePlayer;
	NSURL *videoURL;
	EAGLView *view;
	NSLock *_pCondition; 
	CCSpriteFrameCache* pSharedSpriteFrameCache;
}

@property (nonatomic,retain) EAGLView *view;

+(id) scene;
-(void)play;
@end
