//
//  DoubleModeGamePauseScene.m
//  ChildIdentifyPicture
//
//  Created by the9_15 on 12-3-19.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "DoubleModeGamePauseScene.h"


@implementation DoubleModeGamePauseScene
+(CCScene *) scene
{
	CCScene *scene = [CCScene node];
	DoubleModeGamePauseScene *layer = [DoubleModeGamePauseScene node];
	[scene addChild: layer];
	return scene;
}

-(id) init
{
	if( (self=[super init])) 
	{
		CCLayer* gamePauseLayer = [CCLayer node];
		gamePauseLayer.scale = 0;
		gamePauseLayer.rotation = -90;
		
		CCSprite* pauseFrame = [CCSprite spriteWithSpriteFrameName:@"PauseFrame.png"];
		pauseFrame.position = ccp(512,384);
		[gamePauseLayer addChild:pauseFrame];
		
		CCSprite* frameinfo_Zan = [CCSprite spriteWithSpriteFrameName:@"FrameInfo_Zan.png"];
		frameinfo_Zan.position = ccp(443.00,428.00);
		[gamePauseLayer addChild:frameinfo_Zan];
		
		CCSprite* frameinfo_Ting = [CCSprite spriteWithSpriteFrameName:@"FrameInfo_Ting.png"];
		frameinfo_Ting.position = ccp(596.00,426.00);
		[gamePauseLayer addChild:frameinfo_Ting];
		
		CCMenuItem* returnToGameSceneMenuItem = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"ReturnGameSceneNormal.png"] 
												    selectedSprite:[CCSprite spriteWithSpriteFrameName:@"ReturnGameSceneSelected.png"] 
														target:self 
													    selector:@selector(popToGameScene)];
		CCMenu* returnToGameScene = [CCMenu menuWithItems:returnToGameSceneMenuItem,nil];
		returnToGameScene.position = ccp(599.00,299.00);
		[gamePauseLayer addChild:returnToGameScene];
		[self addChild:gamePauseLayer];
		
		id gamePauseLayerScaleLarge = [CCScaleTo actionWithDuration:0.3 scale:1.1];
		id gamePauseLayerScaleSmall = [CCScaleTo actionWithDuration:0.15 scale:1.0];
		id gamePauseLayerAction = [CCSequence actions:gamePauseLayerScaleLarge,gamePauseLayerScaleSmall,nil];
		[gamePauseLayer runAction:gamePauseLayerAction];
		
	}
	return self;
}

- (void) popToGameScene
{
	[playGameMusic gameMenuClickSound];
	[[CCDirector sharedDirector] popScene];
}

- (void) dealloc
{
	[super dealloc];
}

@end
