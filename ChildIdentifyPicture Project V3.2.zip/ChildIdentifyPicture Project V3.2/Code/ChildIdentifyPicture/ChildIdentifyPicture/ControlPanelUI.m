//
//  ControlPanelUI.m
//  ChildIdentifyPicture
//
//  Created by LXC on 12-2-25.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "ControlPanelUI.h"


@implementation RightControlPanelUI

-(id) init
{
	if( (self=[super init])) 
	{
		CCSprite* controlPanelBG = [CCSprite spriteWithSpriteFrameName:@"ControlPanelCircular.png"];
		controlPanelBG.position = CGPointZero;
		[self addChild:controlPanelBG];
		
		rightPanel_rightHalfLabel1 = [CCLabelTTF labelWithString:@"" 
										fontName:@"FZKaTong-M19S" 
										fontSize:LABEL_FONT_SIZE];
		[rightPanel_rightHalfLabel1 setPosition:ccp(-146, -83)];
		[rightPanel_rightHalfLabel1 setRotation:-120];
		[rightPanel_rightHalfLabel1 setColor:ccc3(50,20,10)];
		[self addChild:rightPanel_rightHalfLabel1 z:1];
		
		rightPanel_rightHalfLabel2 = [CCLabelTTF labelWithString:@"" 
										fontName:@"FZKaTong-M19S" 
										fontSize:LABEL_FONT_SIZE];
		[rightPanel_rightHalfLabel2 setPosition:ccp(-57, -158)];
		[rightPanel_rightHalfLabel2 setRotation:-160];
		[rightPanel_rightHalfLabel2 setColor:ccc3(50,20,10)];
		[self addChild:rightPanel_rightHalfLabel2 z:1];
		
		rightPanel_rightHalfLabel3 = [CCLabelTTF labelWithString:@"" 
										fontName:@"FZKaTong-M19S" 
										fontSize:LABEL_FONT_SIZE];
		[rightPanel_rightHalfLabel3 setPosition:ccp(58, -158)];
		[rightPanel_rightHalfLabel3 setRotation:160];
		[rightPanel_rightHalfLabel3 setColor:ccc3(50,20,10)];
		[self addChild:rightPanel_rightHalfLabel3 z:1];
		
		rightPanel_rightHalfLabel4 = [CCLabelTTF labelWithString:@"" 
										fontName:@"FZKaTong-M19S" 
										fontSize:LABEL_FONT_SIZE];
		[rightPanel_rightHalfLabel4 setPosition:ccp(146, -85)];
		[rightPanel_rightHalfLabel4 setRotation:120];
		[rightPanel_rightHalfLabel4 setColor:ccc3(50,20,10)];
		[self addChild:rightPanel_rightHalfLabel4 z:1];
		
		rightPanel_leftHalfLabel1 = [CCLabelTTF labelWithString:@""
									     fontName:@"FZKaTong-M19S" 
									     fontSize:LABEL_FONT_SIZE];
		[rightPanel_leftHalfLabel1 setPosition:ccp(146, 83)];
		[rightPanel_leftHalfLabel1 setRotation:57];
		[rightPanel_leftHalfLabel1 setColor:ccc3(50,20,10)];
		[self addChild:rightPanel_leftHalfLabel1 z:1];
		
		rightPanel_leftHalfLabel2 = [CCLabelTTF labelWithString:@""
									     fontName:@"FZKaTong-M19S"
									     fontSize:LABEL_FONT_SIZE];
		[rightPanel_leftHalfLabel2 setPosition:ccp(59, 158)];
		[rightPanel_leftHalfLabel2 setRotation:20];
		[rightPanel_leftHalfLabel2 setColor:ccc3(50,20,10)];
		[self addChild:rightPanel_leftHalfLabel2 z:1];
		
		rightPanel_leftHalfLabel3 = [CCLabelTTF labelWithString:@""
									     fontName:@"FZKaTong-M19S"
									     fontSize:LABEL_FONT_SIZE];
		[rightPanel_leftHalfLabel3 setPosition:ccp(-55, 157)];
		[rightPanel_leftHalfLabel3 setRotation:-20];
		[rightPanel_leftHalfLabel3 setColor:ccc3(50,20,10)];
		[self addChild:rightPanel_leftHalfLabel3 z:1];
		
		rightPanel_leftHalfLabel4 = [CCLabelTTF labelWithString:@"" 
									     fontName:@"FZKaTong-M19S" 
									     fontSize:LABEL_FONT_SIZE];
		[rightPanel_leftHalfLabel4 setPosition:ccp(-143, 85)];
		[rightPanel_leftHalfLabel4 setRotation:-60];
		[rightPanel_leftHalfLabel4 setColor:ccc3(50,20,10)];
		[self addChild:rightPanel_leftHalfLabel4 z:1];
		
		rightControlPanelLogic = [[RightControlPanelLogic alloc] init];
		
        rightPanel_leftHalfMenuItem1 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]
                                                               selectedSprite:[CCSprite spriteWithSpriteFrameName:@"CircularSelected.png"]
                                                               disabledSprite:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]
                                                                       target:rightControlPanelLogic
                                                                     selector:@selector(chooseOption1)];
		[rightPanel_leftHalfMenuItem1 setPosition:ccp(144, 81)];
		[rightPanel_leftHalfMenuItem1 setRotation:60];
		
        rightPanel_leftHalfMenuItem2 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]
                                                               selectedSprite:[CCSprite spriteWithSpriteFrameName:@"CircularSelected.png"]
                                                               disabledSprite:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]
                                                                       target:rightControlPanelLogic
                                                                     selector:@selector(chooseOption2)];
		rightPanel_leftHalfMenuItem2.position = ccp(58, 154);
		rightPanel_leftHalfMenuItem2.rotation = 20;
		
        rightPanel_leftHalfMenuItem3 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]
                                                               selectedSprite:[CCSprite spriteWithSpriteFrameName:@"CircularSelected.png"]
                                                               disabledSprite:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]
                                                                       target:rightControlPanelLogic
                                                                     selector:@selector(chooseOption3)];
		rightPanel_leftHalfMenuItem3.position = ccp(-54, 155);
		rightPanel_leftHalfMenuItem3.rotation = -20;
		
        rightPanel_leftHalfMenuItem4 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]
                                                               selectedSprite:[CCSprite spriteWithSpriteFrameName:@"CircularSelected.png"]
                                                               disabledSprite:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]
                                                                       target:rightControlPanelLogic
                                                                     selector:@selector(chooseOption4)];
		rightPanel_leftHalfMenuItem4.position = ccp(-141,84);
		rightPanel_leftHalfMenuItem4.rotation = -60;
		
        rightPanel_rightHalfMenuItem1 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]
                                                               selectedSprite:[CCSprite spriteWithSpriteFrameName:@"CircularSelected.png"]
                                                               disabledSprite:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]
                                                                       target:rightControlPanelLogic
                                                                     selector:@selector(chooseOption1)];
		rightPanel_rightHalfMenuItem1.position = ccp(-142, -81);
		rightPanel_rightHalfMenuItem1.rotation = -120;
		
        rightPanel_rightHalfMenuItem2 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]
                                                                selectedSprite:[CCSprite spriteWithSpriteFrameName:@"CircularSelected.png"]
                                                                disabledSprite:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]
                                                                        target:rightControlPanelLogic
                                                                      selector:@selector(chooseOption2)];
		[rightPanel_rightHalfMenuItem2 setPosition:ccp(-56, -154)];
		[rightPanel_rightHalfMenuItem2 setRotation:-160];
		
		
        rightPanel_rightHalfMenuItem3 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]
                                                                selectedSprite:[CCSprite spriteWithSpriteFrameName:@"CircularSelected.png"]
                                                                disabledSprite:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]
                                                                        target:rightControlPanelLogic
                                                                      selector:@selector(chooseOption3)];
		rightPanel_rightHalfMenuItem3.position = ccp(57, -155);
		rightPanel_rightHalfMenuItem3.rotation = 160;
		
        rightPanel_rightHalfMenuItem4 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]
                                                                selectedSprite:[CCSprite spriteWithSpriteFrameName:@"CircularSelected.png"]
                                                                disabledSprite:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]
                                                                        target:rightControlPanelLogic
                                                                      selector:@selector(chooseOption4)];
		[rightPanel_rightHalfMenuItem4 setPosition:ccp(143, -83)];
		[rightPanel_rightHalfMenuItem4 setRotation:120];
		
		rightPanel_leftHalf = [CCMenu menuWithItems:rightPanel_leftHalfMenuItem1,rightPanel_leftHalfMenuItem2,rightPanel_leftHalfMenuItem3,rightPanel_leftHalfMenuItem4,nil];
		rightPanel_leftHalf.position = CGPointZero;
		[self addChild:rightPanel_leftHalf];
		
		rightPanel_rightHalf = [CCMenu menuWithItems:rightPanel_rightHalfMenuItem1,rightPanel_rightHalfMenuItem2,rightPanel_rightHalfMenuItem3,rightPanel_rightHalfMenuItem4,nil];
		rightPanel_rightHalf.position = CGPointZero;
		[self addChild:rightPanel_rightHalf];
	}
	return self;
}

- (void) dealloc
{
	[rightControlPanelLogic release];
	rightControlPanelLogic = nil;
	[super dealloc];
}

@end



@implementation LeftControlPanelUI
-(id) init
{
	if( (self=[super init])) 
	{
		CCSprite* controlPanelBG = [CCSprite spriteWithSpriteFrameName:@"ControlPanelCircular.png"];
		controlPanelBG.position = CGPointZero;
		[self addChild:controlPanelBG];
		
		leftPanel_rightHalfLabel1 = [CCLabelTTF labelWithString:@"" 
									     fontName:@"FZKaTong-M19S" 
									     fontSize:LABEL_FONT_SIZE];
		[leftPanel_rightHalfLabel1 setPosition:ccp(146, 83)];
		[leftPanel_rightHalfLabel1 setRotation:57];
		[leftPanel_rightHalfLabel1 setColor:ccc3(50,20,10)];
		[self addChild:leftPanel_rightHalfLabel1 z:1];
		
		leftPanel_rightHalfLabel2 = [CCLabelTTF labelWithString:@"" 
									     fontName:@"FZKaTong-M19S" 
									     fontSize:LABEL_FONT_SIZE];
		[leftPanel_rightHalfLabel2 setPosition:ccp(57, 158)];
		[leftPanel_rightHalfLabel2 setRotation:20];
		[leftPanel_rightHalfLabel2 setColor:ccc3(50,20,10)];
		[self addChild:leftPanel_rightHalfLabel2 z:1];
		
		leftPanel_rightHalfLabel3 = [CCLabelTTF labelWithString:@"" 
									     fontName:@"FZKaTong-M19S" 
									     fontSize:LABEL_FONT_SIZE];
		[leftPanel_rightHalfLabel3 setPosition:ccp(-58, 158)];
		[leftPanel_rightHalfLabel3 setRotation:-20];
		[leftPanel_rightHalfLabel3 setColor:ccc3(50,20,10)];
		[self addChild:leftPanel_rightHalfLabel3 z:1];
		
		leftPanel_rightHalfLabel4 = [CCLabelTTF labelWithString:@"" 
									     fontName:@"FZKaTong-M19S" 
									     fontSize:LABEL_FONT_SIZE];
		[leftPanel_rightHalfLabel4 setPosition:ccp(-146, 85)];
		[leftPanel_rightHalfLabel4 setRotation:-60];
		[leftPanel_rightHalfLabel4 setColor:ccc3(50,20,10)];
		[self addChild:leftPanel_rightHalfLabel4 z:1];
		
		leftPanel_leftHalfLabel1 = [CCLabelTTF labelWithString:@"" 
									    fontName:@"FZKaTong-M19S" 
									    fontSize:LABEL_FONT_SIZE];
		[leftPanel_leftHalfLabel1 setPosition:ccp(-146, -83)];
		[leftPanel_leftHalfLabel1 setRotation:-120];
		[leftPanel_leftHalfLabel1 setColor:ccc3(50,20,10)];
		[self addChild:leftPanel_leftHalfLabel1 z:1];
		
		leftPanel_leftHalfLabel2 = [CCLabelTTF labelWithString:@""
									    fontName:@"FZKaTong-M19S"
									    fontSize:LABEL_FONT_SIZE];
		[leftPanel_leftHalfLabel2 setPosition:ccp(-59, -158)];
		[leftPanel_leftHalfLabel2 setRotation:-160];
		[leftPanel_leftHalfLabel2 setColor:ccc3(50,20,10)];
		[self addChild:leftPanel_leftHalfLabel2 z:1];
		
		leftPanel_leftHalfLabel3 = [CCLabelTTF labelWithString:@""
									    fontName:@"FZKaTong-M19S"
									    fontSize:LABEL_FONT_SIZE];
		[leftPanel_leftHalfLabel3 setPosition:ccp(55, -157)];
		[leftPanel_leftHalfLabel3 setRotation:160];
		[leftPanel_leftHalfLabel3 setColor:ccc3(50,20,10)];
		[self addChild:leftPanel_leftHalfLabel3 z:1];
		
		leftPanel_leftHalfLabel4 = [CCLabelTTF labelWithString:@""
									    fontName:@"FZKaTong-M19S" 
									    fontSize:LABEL_FONT_SIZE];
		[leftPanel_leftHalfLabel4 setPosition:ccp(143, -85)];
		[leftPanel_leftHalfLabel4 setRotation:120];
		[leftPanel_leftHalfLabel4 setColor:ccc3(50,20,10)];
		[self addChild:leftPanel_leftHalfLabel4 z:1];
		
		leftControlPanelLogic = [[LeftControlPanelLogic alloc] init];
		
        leftPanel_rightHalfMenuItem1 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]
                                                               selectedSprite:[CCSprite spriteWithSpriteFrameName:@"CircularSelected.png"]
                                                               disabledSprite:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]
                                                                       target:leftControlPanelLogic
                                                                     selector:@selector(chooseOption1)];
		[leftPanel_rightHalfMenuItem1 setPosition:ccp(144, 81)];
		[leftPanel_rightHalfMenuItem1 setRotation:60];
		
        leftPanel_rightHalfMenuItem2 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]
                                                               selectedSprite:[CCSprite spriteWithSpriteFrameName:@"CircularSelected.png"]
                                                               disabledSprite:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]
                                                                       target:leftControlPanelLogic
                                                                     selector:@selector(chooseOption2)];
		leftPanel_rightHalfMenuItem2.position = ccp(58, 154);
		leftPanel_rightHalfMenuItem2.rotation = 20;
		
        leftPanel_rightHalfMenuItem3 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]
                                                               selectedSprite:[CCSprite spriteWithSpriteFrameName:@"CircularSelected.png"]
                                                               disabledSprite:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]
                                                                       target:leftControlPanelLogic
                                                                     selector:@selector(chooseOption3)];
		leftPanel_rightHalfMenuItem3.position = ccp(-54, 155);
		leftPanel_rightHalfMenuItem3.rotation = -20;
		
		
        leftPanel_rightHalfMenuItem4 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]
                                                               selectedSprite:[CCSprite spriteWithSpriteFrameName:@"CircularSelected.png"]
                                                               disabledSprite:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]
                                                                       target:leftControlPanelLogic
                                                                     selector:@selector(chooseOption4)];
		leftPanel_rightHalfMenuItem4.position = ccp(-141,84);
		leftPanel_rightHalfMenuItem4.rotation = -60;
		
		
        leftPanel_leftHalfMenuItem1 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]
                                                               selectedSprite:[CCSprite spriteWithSpriteFrameName:@"CircularSelected.png"]
                                                               disabledSprite:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]
                                                                       target:leftControlPanelLogic
                                                                     selector:@selector(chooseOption1)];
		leftPanel_leftHalfMenuItem1.position = ccp(-142, -81);
		leftPanel_leftHalfMenuItem1.rotation = -120;
		
        leftPanel_leftHalfMenuItem2 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]
                                                              selectedSprite:[CCSprite spriteWithSpriteFrameName:@"CircularSelected.png"]
                                                              disabledSprite:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]
                                                                      target:leftControlPanelLogic
                                                                    selector:@selector(chooseOption2)];
		[leftPanel_leftHalfMenuItem2 setPosition:ccp(-56, -154)];
		[leftPanel_leftHalfMenuItem2 setRotation:-160];
		
        leftPanel_leftHalfMenuItem3 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]
                                                              selectedSprite:[CCSprite spriteWithSpriteFrameName:@"CircularSelected.png"]
                                                              disabledSprite:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]
                                                                      target:leftControlPanelLogic
                                                                    selector:@selector(chooseOption3)];
		leftPanel_leftHalfMenuItem3.position = ccp(57, -155);
		leftPanel_leftHalfMenuItem3.rotation = 160;
		
		
        leftPanel_leftHalfMenuItem4 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"CircularNormal.png"]
                                                              selectedSprite:[CCSprite spriteWithSpriteFrameName:@"CircularSelected.png"]
                                                              disabledSprite:[CCSprite spriteWithSpriteFrameName:@"CircularDisabled.png"]
                                                                      target:leftControlPanelLogic
                                                                    selector:@selector(chooseOption4)];
		[leftPanel_leftHalfMenuItem4 setPosition:ccp(143, -83)];
		[leftPanel_leftHalfMenuItem4 setRotation:120];
		
		
		leftPanel_leftHalf = [CCMenu menuWithItems:leftPanel_leftHalfMenuItem1,leftPanel_leftHalfMenuItem2,leftPanel_leftHalfMenuItem3,leftPanel_leftHalfMenuItem4,nil];
		leftPanel_leftHalf.position = CGPointZero;
		[self addChild:leftPanel_leftHalf];
		
		leftPanel_rightHalf = [CCMenu menuWithItems:leftPanel_rightHalfMenuItem1,leftPanel_rightHalfMenuItem2,leftPanel_rightHalfMenuItem3,leftPanel_rightHalfMenuItem4,nil];        
		leftPanel_rightHalf.position = CGPointZero;
		[self addChild:leftPanel_rightHalf];
		
	}
	return self;
}

- (void) dealloc
{
	[leftControlPanelLogic release];
	leftControlPanelLogic = nil;
	[super dealloc];
}


@end