//
//  DoubleModeControlPanel.m
//  ChildIdentifyPicture
//
//  Created by the9_15 on 12-3-9.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "DoubleModeControlPanelUI.h"


@implementation DoubleModeControlPanelUI
-(id) init
{
	if( (self=[super init])) 
	{
		CCSprite* controlPanelBG = [CCSprite spriteWithSpriteFrameName:@"BigControlPanelCircular.png"];
		controlPanelBG.position = CGPointZero;
		[self addChild:controlPanelBG];
		
		controlPanel_upHalfLabel1 = [CCLabelTTF labelWithString:@""
									     fontName:@"FZKaTong-M19S" 
									     fontSize:Big_LABEL_FONT_SIZE];
		[controlPanel_upHalfLabel1 setPosition:ccp(-121.00,213.00)];
		[controlPanel_upHalfLabel1 setRotation:-30];
		[controlPanel_upHalfLabel1 setColor:ccc3(50,20,10)];
		[self addChild:controlPanel_upHalfLabel1 z:1];
		
		controlPanel_upHalfLabel2 = [CCLabelTTF labelWithString:@""
									     fontName:@"FZKaTong-M19S"
									     fontSize:Big_LABEL_FONT_SIZE];
		[controlPanel_upHalfLabel2 setPosition:ccp(-228.00, 85.00)];
		[controlPanel_upHalfLabel2 setRotation:-70];
		[controlPanel_upHalfLabel2 setColor:ccc3(50,20,10)];
		[self addChild:controlPanel_upHalfLabel2 z:1];
		
		controlPanel_upHalfLabel3 = [CCLabelTTF labelWithString:@""
									     fontName:@"FZKaTong-M19S"
									     fontSize:Big_LABEL_FONT_SIZE];
		[controlPanel_upHalfLabel3 setPosition:ccp(-229.00, -82.00)];
		[controlPanel_upHalfLabel3 setRotation:-110];
		[controlPanel_upHalfLabel3 setColor:ccc3(50,20,10)];
		[self addChild:controlPanel_upHalfLabel3 z:1];
		
		controlPanel_upHalfLabel4 = [CCLabelTTF labelWithString:@"" 
									     fontName:@"FZKaTong-M19S" 
									     fontSize:Big_LABEL_FONT_SIZE];
		[controlPanel_upHalfLabel4 setPosition:ccp(-123.00, -210.00)];
		[controlPanel_upHalfLabel4 setRotation:-150];
		[controlPanel_upHalfLabel4 setColor:ccc3(50,20,10)];
		[self addChild:controlPanel_upHalfLabel4 z:1];
		
		controlPanel_downHalfLabel1 = [CCLabelTTF labelWithString:@"" 
									     fontName:@"FZKaTong-M19S" 
									     fontSize:Big_LABEL_FONT_SIZE];
		[controlPanel_downHalfLabel1 setPosition:ccp(122.00, -212.00)];
		[controlPanel_downHalfLabel1 setRotation:150];
		[controlPanel_downHalfLabel1 setColor:ccc3(50,20,10)];
		[self addChild:controlPanel_downHalfLabel1 z:1];
		
		controlPanel_downHalfLabel2 = [CCLabelTTF labelWithString:@""
									     fontName:@"FZKaTong-M19S" 
									     fontSize:Big_LABEL_FONT_SIZE];
		[controlPanel_downHalfLabel2 setPosition:ccp(229.00, -84.00)];
		[controlPanel_downHalfLabel2 setRotation:110];
		[controlPanel_downHalfLabel2 setColor:ccc3(50,20,10)];
		[self addChild:controlPanel_downHalfLabel2 z:1];
		
		controlPanel_downHalfLabel3 = [CCLabelTTF labelWithString:@""
									     fontName:@"FZKaTong-M19S" 
									     fontSize:Big_LABEL_FONT_SIZE];
		[controlPanel_downHalfLabel3 setPosition:ccp(229.00, 82.00)];
		[controlPanel_downHalfLabel3 setRotation:70];
		[controlPanel_downHalfLabel3 setColor:ccc3(50,20,10)];
		[self addChild:controlPanel_downHalfLabel3 z:1];
		
		controlPanel_downHalfLabel4 = [CCLabelTTF labelWithString:@""
									     fontName:@"FZKaTong-M19S" 
									     fontSize:Big_LABEL_FONT_SIZE];
		[controlPanel_downHalfLabel4 setPosition:ccp(120.00, 210.00)];
		[controlPanel_downHalfLabel4 setRotation:30];
		[controlPanel_downHalfLabel4 setColor:ccc3(50,20,10)];
		[self addChild:controlPanel_downHalfLabel4 z:1];

		
		doubleModeControlPanelLogic = [[DoubleModeControlPanelLogic alloc] init];
		
		controlPanel_upHalfMenuItem4 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]
											 selectedSprite:[CCSprite spriteWithSpriteFrameName:@"BigCircularSelected.png"]
											 disabledSprite:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]
												   target:doubleModeControlPanelLogic
												 selector:@selector(chooseOption4)];
		[controlPanel_upHalfMenuItem4 setPosition:ccp(-122.00, -208.00)];
		[controlPanel_upHalfMenuItem4 setRotation:-150.00];
		
		controlPanel_upHalfMenuItem3 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]
											 selectedSprite:[CCSprite spriteWithSpriteFrameName:@"BigCircularSelected.png"]
											 disabledSprite:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]
												   target:doubleModeControlPanelLogic
												 selector:@selector(chooseOption3)];
		controlPanel_upHalfMenuItem3.position = ccp(-227.00, -82.00);
		controlPanel_upHalfMenuItem3.rotation = -110.00;
		
		controlPanel_upHalfMenuItem2 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]
											 selectedSprite:[CCSprite spriteWithSpriteFrameName:@"BigCircularSelected.png"]
											 disabledSprite:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]
												   target:doubleModeControlPanelLogic
												 selector:@selector(chooseOption2)];
		controlPanel_upHalfMenuItem2.position = ccp(-228.00, 85.00);
		controlPanel_upHalfMenuItem2.rotation = -70.00;
		
		controlPanel_upHalfMenuItem1 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]
											 selectedSprite:[CCSprite spriteWithSpriteFrameName:@"BigCircularSelected.png"]
											 disabledSprite:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]
												   target:doubleModeControlPanelLogic
												 selector:@selector(chooseOption1)];
		controlPanel_upHalfMenuItem1.position = ccp(-120.00,212.00);
		controlPanel_upHalfMenuItem1.rotation = -30.00;
		
		controlPanel_downHalfMenuItem4 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]
											   selectedSprite:[CCSprite spriteWithSpriteFrameName:@"BigCircularSelected.png"]
											   disabledSprite:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]
												     target:doubleModeControlPanelLogic
												   selector:@selector(chooseOption4)];
		controlPanel_downHalfMenuItem4.position = ccp(123.00, 209.00);
		controlPanel_downHalfMenuItem4.rotation = 30.00;
		
		controlPanel_downHalfMenuItem3 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]
											   selectedSprite:[CCSprite spriteWithSpriteFrameName:@"BigCircularSelected.png"]
											   disabledSprite:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]
												     target:doubleModeControlPanelLogic
												   selector:@selector(chooseOption3)];
		[controlPanel_downHalfMenuItem3 setPosition:ccp(229.00, 83.00)];
		[controlPanel_downHalfMenuItem3 setRotation:70.00];
		
		
		controlPanel_downHalfMenuItem2 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]
											   selectedSprite:[CCSprite spriteWithSpriteFrameName:@"BigCircularSelected.png"]
											   disabledSprite:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]
												     target:doubleModeControlPanelLogic
												   selector:@selector(chooseOption2)];
		controlPanel_downHalfMenuItem2.position = ccp(229.00, -84.00);
		controlPanel_downHalfMenuItem2.rotation = 110.00;
		
		controlPanel_downHalfMenuItem1 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]
											   selectedSprite:[CCSprite spriteWithSpriteFrameName:@"BigCircularSelected.png"]
											   disabledSprite:[CCSprite spriteWithSpriteFrameName:@"BigCircularDisabled.png"]
												     target:doubleModeControlPanelLogic
												   selector:@selector(chooseOption1)];
		[controlPanel_downHalfMenuItem1 setPosition:ccp(121.00, -211.00)];
		[controlPanel_downHalfMenuItem1 setRotation:150.00];
		
		controlPanel_upHalf = [CCMenu menuWithItems:controlPanel_upHalfMenuItem1,controlPanel_upHalfMenuItem2,controlPanel_upHalfMenuItem3,controlPanel_upHalfMenuItem4,nil];
		controlPanel_upHalf.position = CGPointZero;
		[self addChild:controlPanel_upHalf];
		
		controlPanel_downHalf = [CCMenu menuWithItems:controlPanel_downHalfMenuItem1,controlPanel_downHalfMenuItem2,controlPanel_downHalfMenuItem3,controlPanel_downHalfMenuItem4,nil];
		controlPanel_downHalf.position = CGPointZero;
		[self addChild:controlPanel_downHalf];
	}
	return self;
}

- (void) dealloc
{
	[doubleModeControlPanelLogic release];
	doubleModeControlPanelLogic = nil;
	
	[super dealloc];
}
@end
