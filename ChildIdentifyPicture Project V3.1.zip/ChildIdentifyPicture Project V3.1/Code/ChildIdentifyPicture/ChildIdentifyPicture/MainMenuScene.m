//
//  MainMenuScene.m
//  ChildIdentifyPicture
//
//  Created by the9_15 on 12-2-20.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "MainMenuScene.h"


@implementation MainMenuScene

+(CCScene *) scene
{
	CCScene *scene = [CCScene node];
	MainMenuScene *layer = [MainMenuScene node];
	[scene addChild: layer];
	return scene;
}

-(id) init
{
	if( (self=[super init])) 
	{
		winSize = [[CCDirector sharedDirector] winSize];
		
		//透明通道像素预乘渲染优化
//		[CCTexture2D PVRImagesHavePremultipliedAlpha:YES];
//		[CCTexture2D setDefaultAlphaPixelFormat:kCCTexture2DPixelFormat_RGBA4444];
//		[[CCSpriteFrameCache sharedSpriteFrameCache]addSpriteFramesWithFile:@"ThingsBatchOne.pv.plist"];
//		[[CCSpriteFrameCache sharedSpriteFrameCache]addSpriteFramesWithFile:@"ThingsBatchTwo.pv.plist"];
//		[[CCSpriteFrameCache sharedSpriteFrameCache]addSpriteFramesWithFile:@"InfoLayer.pv.plist"];
//		[[CCSpriteFrameCache sharedSpriteFrameCache]addSpriteFramesWithFile:@"MainMenuSceneBatch.pv.plist"];
//		[[CCSpriteFrameCache sharedSpriteFrameCache]addSpriteFramesWithFile:@"MainMenuSceneBG.pv.plist"];
//		[[CCSpriteFrameCache sharedSpriteFrameCache]addSpriteFramesWithFile:@"PlayGameSceneBatch.pv.plist"];
//		[[CCSpriteFrameCache sharedSpriteFrameCache]addSpriteFramesWithFile:@"PlayGameSceneBG.pv.plist"];
//		
//		[CCTexture2D PVRImagesHavePremultipliedAlpha:NO];
//		[[CCSpriteFrameCache sharedSpriteFrameCache]addSpriteFramesWithFile:@"MainMenuShineBG.pv.plist"];
		
		playGameMusic = [[PlayGameMusic alloc] init];
		
		[MusicSwitch shareConfig].gameSoundState=[[NSUserDefaults standardUserDefaults] boolForKey:@"MusicStateKey"];
		if (![MusicSwitch shareConfig].gameSoundState) 
		{
			[playGameMusic gameBGSoundStateChange];
			[MusicSwitch shareConfig].gameSoundState = YES;
		}
		else 
		{
			[MusicSwitch shareConfig].gameSoundState = NO;
		}



		[[CCScheduler sharedScheduler]setTimeScale:2.0];
		
		CCSprite* mainMenuSceneBG = [CCSprite spriteWithSpriteFrameName:@"MainMenuSceneBG.png"];
		mainMenuSceneBG.position = ccp(winSize.width*0.5,winSize.height*0.5);
		[self addChild:mainMenuSceneBG z:0];
		
		shine = [CCSprite spriteWithSpriteFrameName:@"Shine.png"];
		shine.position = ccp(winSize.width*0.5,winSize.height*0.5);
		[self addChild:shine z:1];
		
		whale= [CCSprite spriteWithSpriteFrameName:@"Whale.png"];
		whale.scale = 0;
		whale.position =ccp(463.00, 428.00);
		[self addChild:whale z:2];
		
		elephant = [CCSprite spriteWithSpriteFrameName:@"Elephant.png"];
		elephant.position = ccp(winSize.width+[elephant texture].contentSize.width*0.5,122.00);
		[self addChild:elephant z:2];
		
		blackboardCorner = [CCSprite spriteWithSpriteFrameName:@"Blackboard-Corner.png"];
		blackboardCorner.position = ccp(-[blackboardCorner texture].contentSize.width*0.5,-[blackboardCorner texture].contentSize.height*0.5);
		blackboardCorner.anchorPoint = ccp(0.00,0.00);
		[self addChild:blackboardCorner z:2];
		
		pen = [CCSprite spriteWithSpriteFrameName:@"Pen.png"];
		pen.position = ccp(winSize.width+[pen texture].contentSize.width*0.5, 768.00+[pen texture].contentSize.height*0.5);
		pen.anchorPoint = ccp(1.00, 1.00);
		[self addChild:pen z:2];
		
		windmill = [CCSprite spriteWithSpriteFrameName:@"Windmill1.png"];
		windmill.position =ccp(746,768+[windmill texture].contentSize.height*0.5);
		[self addChild:windmill z:2];
		
		cloudBlue = [CCSprite spriteWithSpriteFrameName:@"Cloud-Blue.png"];
		cloudBlue.position = ccp(winSize.width+[cloudBlue texture].contentSize.width*0.5, 445.00);
		[self addChild:cloudBlue z:3];
		
		cloudWhite = [CCSprite spriteWithSpriteFrameName:@"Cloud-White.png"];
		cloudWhite.position = ccp(0-[cloudWhite texture].contentSize.width*0.5, 352.00);
		[self addChild:cloudWhite z:4];
		
		star = [CCSprite spriteWithSpriteFrameName:@"Star.png"];
		star.position = ccp(888.00, winSize.height+[star texture].contentSize.height*0.5);
		[self addChild:star z:4];
		
		title = [CCSprite spriteWithSpriteFrameName:@"Title.png"];
		title.position = ccp(winSize.width*0.5,winSize.height+[title texture].contentSize.height*0.5);
		[self addChild:title z:5];
		
		singleModeMenu = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"SingleModeNormal.png"]
								selectedSprite:[CCSprite spriteWithSpriteFrameName:@"SingleModeSelected.png"]
									  target:self
									selector:@selector(gotoSingleModePlayGameScene)];
		doubleModeMenu = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"DoubleModeNormal.png"]
								     selectedSprite:[CCSprite spriteWithSpriteFrameName:@"DoubleModeSelected.png"]
										 target:self
									     selector:@selector(gotoDoubleModePlayGameScene)];
		mainMenu = [CCMenu menuWithItems:singleModeMenu,doubleModeMenu,nil];
		mainMenu.position = ccp(512.00, 114.00);
		[mainMenu alignItemsHorizontallyWithPadding:70];
		mainMenu.visible = NO;
		[self addChild:mainMenu z:3];
		[mainMenu setOpacity:0];
		[self scheduleUpdate];
	}
	return self;
}

-(void)sceneAnimation
{
	id titleDelay = [CCDelayTime actionWithDuration:1.2];
	id titleMoveIntoScreen = [CCMoveTo actionWithDuration:0.2 position:ccp(516.00, 357.00)];
	id titleDropIntoScreen= [CCEaseSineIn actionWithAction:titleMoveIntoScreen];
	id titleSound = [CCCallFunc actionWithTarget:self selector:@selector(titleMoveSoundFun)];
	id titleJump = [CCJumpTo actionWithDuration:0.4 position:ccp(516.00,407.00) height:150 jumps:1];
	id titleAction = [CCSequence actions:titleDelay,titleDropIntoScreen,titleSound,titleJump, nil];
	[title runAction:titleAction];
	
	id cloudBlueMoveIntoScreen1 = [CCMoveTo actionWithDuration:0.8 position:ccp(550.00, 446.00)];
	id cloudBlueMoveIntoScreen2 = [CCMoveTo actionWithDuration:0.4 position:ccp(635.00, 446.00)];
	id cloundSound = [CCCallFunc actionWithTarget:self selector:@selector(cloudSoundFun)];
	id cloudBlueAction = [CCSequence actions:cloudBlueMoveIntoScreen1,cloundSound,cloudBlueMoveIntoScreen2, nil];
	[cloudBlue runAction:cloudBlueAction];
	
	id cloudWhiteMoveIntoScreen1 = [CCMoveTo actionWithDuration:0.8 position:ccp(445.00, 352.00)];
	id cloudWhiteMoveIntoScreen2 = [CCMoveTo actionWithDuration:0.4 position:ccp(360.00, 352.00)];
	id cloudWhiteAction = [CCSequence actions:cloudWhiteMoveIntoScreen1,cloudWhiteMoveIntoScreen2, nil];
	[cloudWhite runAction:cloudWhiteAction];
	
	id starMoveToScreen = [CCMoveTo actionWithDuration:0.8 position:ccp(889.00, 559.00)];
	id starJump = [CCJumpTo actionWithDuration:0.4 position:ccp(889.00, 589.00) height:30 jumps:1];
	id starAction = [CCSequence actions:starMoveToScreen,starJump, nil];
	[star runAction:starAction];
	
	id startMenuVisibleChange = [CCCallFunc actionWithTarget:self selector:@selector(visibleChange)];
	id delayTime = [CCDelayTime actionWithDuration:3.4];
	id showStartMenuFadeIn = [CCFadeIn actionWithDuration:1.0];
	id startMenuAction = [CCSequence actions:delayTime,startMenuVisibleChange,showStartMenuFadeIn, nil];
	[mainMenu runAction:startMenuAction];
	
	id penMoveToScreen = [CCMoveTo actionWithDuration:0.8 position:ccp(winSize.width,winSize.height)];
	[pen runAction:penMoveToScreen];
	
	id windmillMoveTo = [CCMoveTo actionWithDuration:0.8 position:ccp(746, 766)];
	[windmill runAction:windmillMoveTo];
	
	id blackboardMoveToScreen = [CCMoveTo actionWithDuration:0.8 position:ccp(0.00,0.00)];
	[blackboardCorner runAction:blackboardMoveToScreen];
	
	id whaleDelayTime = [CCDelayTime actionWithDuration:2.8];
	id whaleMoveIntoScreen = [CCMoveTo actionWithDuration:0.4 position:ccp(216.00, 581.00)];
	id whaleScale = [CCScaleTo actionWithDuration:0.01 scale:1.0];
	id whaleAction = [CCSequence actions:whaleDelayTime,[CCSpawn actions:whaleScale, whaleMoveIntoScreen,nil], nil];
	[whale runAction:whaleAction];
	
	id elephantDelayTime = [CCDelayTime actionWithDuration:2.8];
	id elephantMoveIntoScreen = [CCMoveTo actionWithDuration:0.4 position:ccp(1089.00, 122.00)];
	id elephantAction = [CCSequence actions:elephantDelayTime, elephantMoveIntoScreen, nil];
	[elephant runAction:elephantAction];
}

-(void)visibleChange
{
	mainMenu.visible = YES;
}

- (void)gotoSingleModePlayGameScene
{
	[playGameMusic gameMenuClickSound];
	[[CCDirector sharedDirector]replaceScene:[CCTransitionFade transitionWithDuration:0.8f
													    scene:[DoubleModePlayGameScene scene]
													withColor:ccBLACK]];
}

-(void)gotoDoubleModePlayGameScene
{
	[playGameMusic gameMenuClickSound];
	[[CCDirector sharedDirector] replaceScene: [CCTransitionFade transitionWithDuration:0.8f 
														scene:[PlayGameScene scene] 
													  withColor:ccBLACK]];
}

-(void)cloudSoundFun
{
	[playGameMusic cloudMoveSound];
}

-(void)titleMoveSoundFun
{
	[playGameMusic titleMoveSound];
}

- (void)update:(ccTime)delta
{
	shine.rotation+=0.2;
}

-(void) onEnterTransitionDidFinish
{
	[audioEngine stopEffect:chooseTrueSound];
	[audioEngine stopEffect:chooseFalseSound];
	[audioEngine stopEffect:finalFiveSecondSound];
	[audioEngine stopEffect:gameStartSound];
	[audioEngine stopEffect:infoLayerSound];
	[audioEngine stopEffect:starSound];
	[audioEngine stopEffect:timeDown1Sound];
	[audioEngine stopEffect:timeDown2Sound];
	[audioEngine stopEffect:thingsRotateIn];
	[audioEngine stopEffect:cloudMoveSound];
	[audioEngine stopEffect:titleMoveSound];
	[self sceneAnimation];
	[super onEnterTransitionDidFinish];
}

- (void) dealloc
{
	[super dealloc];
}

@end
