//
//  GamePauseScene.h
//  ChildIdentifyPicture
//
//  Created by the9_15 on 12-3-15.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "MainMenuScene.h"

@interface GamePauseScene : CCLayer 
{

}

+(CCScene *) scene;
@end
