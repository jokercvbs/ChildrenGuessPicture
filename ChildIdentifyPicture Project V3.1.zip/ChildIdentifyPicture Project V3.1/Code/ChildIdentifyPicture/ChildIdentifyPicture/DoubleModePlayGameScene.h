//
//  DoubleModePlayGameScene.h
//  ChildIdentifyPicture
//
//  Created by the9_15 on 12-3-9.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

enum  
{
	kRoundOneQuestionCount = 1,
	kRoundTwoQuestionCount = 2,
	kRoundThreeQuestionCount = 3,
	kRoundFourQuestionCount = 4,
	kRoundFiveQuestionCount = 5,
};

enum  
{
	kRoundOneTime = 5,
	kRoundTwoTime = 6,
	kRoundThreeTime = 7,
	kRoundFourTime = 8,
	kRoundFiveTime = 9,
};

enum 
{
	kRoundCountOne,
	kRoundCountTwo,
	kRoundCountThree,
	kRoundCountFour,
	kRoundCountFive,
};

NSString* doubleModePictureName;
float doubleModeAttenuation;

BOOL doubleModePauseState;
#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "DoubleModeControlPanelUI.h"
#import "MainMenuScene.h"
#import "PopInfoLayer.h"
#import "DoubleModeGamePauseScene.h"

@class DoubleModeControlPanelUI;
DoubleModeControlPanelUI* controlPanel;

int doubleSceneTime;
int doubleSceneRoundCount;
int roundCount;
int trueOptionCount;
CCLabelTTF* scoreLabel;
CCSprite* doubleModeIdentifyPicture;

PopInfoLayer* doubleModePopInfolayer;


@interface DoubleModePlayGameScene : CCNode 
{
	CGSize winSize;
	CCMenu* playGameMenu;
	CCSprite* readyLabelOne;
	CCSprite* readyLabelTwo;
	CCSprite* readyLabelThree;
	
	CCSprite* blackboard;
	CCMenuItemSprite* gamePauseMenuItem;
	CCMenuItemSprite* gameResumeMenuItem;
	CCMenuItemToggle* gameStateChange;
	
	CCMenuItemSprite* gameMusicPlayMenuItem;
	CCMenuItemSprite* gameMusicStopMenuItem;
	
	CCMenuItemToggle* gameMusicStateChange;
	
	CCSprite* windmill;
	
	CCLabelTTF* doubleModeCornerClockLabel;
	CCMenuItemSprite* playGameMenuItem;
	CCSprite* bigCircularScore;
	
	CCParticleSystem *controlPanelParticle;
	
	CCSprite* controlPanelYellowFlower;
	CCSprite* controlPanelGreenFlower;
	CCSprite* controlPanelBlueFlower;
	CCSprite* controlPanelPinkFlower;
	CCSprite* controlPanelRedFlower;
}
+(CCScene *)scene;
+(DoubleModePlayGameScene *)shareScene;
-(void)gotoNextRound;
-(void)playGameSceneUIAnimation;
-(void)playGameSceneUIInit;
-(void)readyTime;
-(void)show;
-(void)playGameMenuFadeAnimation;
@end
