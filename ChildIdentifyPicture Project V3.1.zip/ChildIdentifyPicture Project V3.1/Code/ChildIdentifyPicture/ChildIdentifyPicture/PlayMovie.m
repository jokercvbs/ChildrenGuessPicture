//
//  PlayMovie.m
//  childflower
//
//  Created by Ben on 12-2-20.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "PlayMovie.h"
#import "MainMenuScene.h"

@implementation PlayMovie
@synthesize view;

+(id) scene
{
	CCScene *scene = [CCScene node];
	PlayMovie *layer = [PlayMovie node];
	[scene addChild: layer];
	return scene;
}

-(id) init
{
	if((self=[super init])) 
	{
		CGSize winSize = [[CCDirector sharedDirector] winSize];
		CCSprite *defaultBG = [CCSprite spriteWithFile:@"Default.png"];
		defaultBG.position = ccp (winSize.width*0.5,winSize.height*0.5);
		[self addChild:defaultBG];

		_pCondition = [[NSLock alloc] init]; 
		[NSThread detachNewThreadSelector:@selector(doSomethong) toTarget:self withObject:nil];
		
		[self performSelector:@selector(play) withObject:nil afterDelay:0.3];
		
	}
	return self;
}

-(void)play
{
	view = [[CCDirector sharedDirector] openGLView];
	NSString *movieFilePath=[[NSBundle mainBundle]pathForResource:@"CompanyLogo" ofType:@"mp4"];
	NSURL *theMovieURL = [NSURL fileURLWithPath:movieFilePath];
	moviePlayer=[[MPMoviePlayerController alloc] initWithContentURL:theMovieURL];//用url初始化对象
	
	
	//设置电影装载时的回调方法 
	[[NSNotificationCenter defaultCenter] addObserver:self
							     selector:@selector(myMovieChangeCallback:)
								   name:MPMoviePlayerLoadStateDidChangeNotification
								 object:moviePlayer];
}

-(void)doSomethong{
	[_pCondition lock];

	@synchronized([CCSpriteFrameCache sharedSpriteFrameCache])
	{
		NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
		
		[CCTexture2D PVRImagesHavePremultipliedAlpha:YES];
		[CCTexture2D setDefaultAlphaPixelFormat:kCCTexture2DPixelFormat_RGBA4444];
		[[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"ThingsBatchOne.pv.plist"];
		[[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"ThingsBatchTwo.pv.plist"];
		[[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"InfoLayer.pv.plist"];
		[[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"MainMenuSceneBatch.pv.plist"];
		[[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"MainMenuSceneBG.pv.plist"];
		[[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"PlayGameSceneBatch.pv.plist"];
		[[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"PlayGameSceneBG.pv.plist"];
		[CCTexture2D PVRImagesHavePremultipliedAlpha:NO];
		[[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"MainMenuShineBG.pv.plist"];
		
		[self performSelectorOnMainThread:@selector(endThread) withObject:nil waitUntilDone:NO];
		[pool release];
		
		NSLog(@"abc");
	}

	
	
}

-(void)endThread
{

[_pCondition unlock];
}

-(void)myMovieFinishedCallback:(NSNotification*)notification
{
	MPMoviePlayerController *video = [notification object];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:video];
	[video release];
	video = nil;
	[[UIApplication sharedApplication] setStatusBarHidden:YES  withAnimation:UIStatusBarAnimationNone];
	[moviePlayer.view removeFromSuperview];
	[[CCDirector sharedDirector]replaceScene:[MainMenuScene node]];
}

-(void)myMovieChangeCallback:(NSNotification*)notification
{
	//设置电影结束后的回调方法 
	[[NSNotificationCenter defaultCenter] addObserver:self
							     selector:@selector(myMovieFinishedCallback:)
								   name:MPMoviePlayerPlaybackDidFinishNotification
								 object:moviePlayer];
	
	
	moviePlayer.controlStyle = MPMovieControlStyleNone; 
	moviePlayer.fullscreen = YES;
	moviePlayer.scalingMode=MPMovieScalingModeAspectFill;
	[[moviePlayer view] setTransform:CGAffineTransformMakeRotation(M_PI*2)];
	[[moviePlayer view] setFrame:[view bounds]]; 
	[view addSubview:[moviePlayer view]]; 
	
	//开始播放
	[moviePlayer play];
}

- (void)dealloc 
{
	[view release];
	view = nil;
	
	[super dealloc];
}
@end
