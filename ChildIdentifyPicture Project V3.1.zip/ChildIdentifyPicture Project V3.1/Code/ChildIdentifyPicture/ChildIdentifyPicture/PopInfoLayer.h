//
//  PopInfoLayer.h
//  ChildIdentifyPicture
//
//  Created by the9_15 on 12-2-28.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//
enum  
{
	kFrameInfo = 61,
};

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface PopInfoLayer : CCSprite 
{

}

@end
