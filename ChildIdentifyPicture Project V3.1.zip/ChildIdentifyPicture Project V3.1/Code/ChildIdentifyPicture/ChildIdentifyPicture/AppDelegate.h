//
//  AppDelegate.h
//  ChildIdentifyPicture
//
//  Created by LXC on 12-2-18.
//  Copyright __MyCompanyName__ 2012年. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RootViewController;

@interface AppDelegate : NSObject <UIApplicationDelegate> 
{
	UIWindow *window;
	RootViewController *viewController;
	UIImageView *defaultView;
}

@property (nonatomic, retain) UIWindow *window;
@property (nonatomic, retain) UIImageView *defaultView;

@end
