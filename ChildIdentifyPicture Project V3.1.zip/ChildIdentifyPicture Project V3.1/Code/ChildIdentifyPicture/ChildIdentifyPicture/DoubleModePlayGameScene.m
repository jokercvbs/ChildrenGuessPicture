//
//  DoubleModePlayGameScene.m
//  ChildIdentifyPicture
//
//  Created by the9_15 on 12-3-9.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "DoubleModePlayGameScene.h"
static DoubleModePlayGameScene* instanceOfDoubleModePlayGameScene;

@implementation DoubleModePlayGameScene

+(CCScene *) scene
{
	CCScene *scene = [CCScene node];
	DoubleModePlayGameScene *layer = [DoubleModePlayGameScene node];
	[scene addChild: layer];
	return scene;
}

+(DoubleModePlayGameScene *)shareScene
{
	return instanceOfDoubleModePlayGameScene;
}

-(id) init
{
	if( (self=[super init])) 
	{
		instanceOfDoubleModePlayGameScene = self;
		
		winSize = [[CCDirector sharedDirector] winSize];
		[[CCScheduler sharedScheduler]setTimeScale:1.0];
		upHide = NO;
		roundCount = 0;
		trueOptionCount = 0;
		doubleModeAttenuation = 120.0f;
		[self playGameSceneUIInit];
	}
	return self;
}

-(void)playGameSceneUIInit
{
	//游戏主场景背景加载
	CCSprite* playGameSceneBG = [CCSprite spriteWithSpriteFrameName:@"PlayGameSceneBG.png"];
	playGameSceneBG.position = ccp(winSize.width*0.5f,winSize.height*0.5f);
	[self addChild:playGameSceneBG];
	
	//黄色便签纸加载
	CCSprite* yellowPaper = [CCSprite spriteWithSpriteFrameName:@"Paper.png"];
	yellowPaper.position = ccp(432.00,399.00);
	yellowPaper.rotation = -90.00;
	[self addChild:yellowPaper];
	
	//红色小花加载
	CCSprite* redFlower = [CCSprite spriteWithSpriteFrameName:@"RedFlower.png"];
	redFlower.position = ccp(229.00, 189.00);
	redFlower.rotation = -90.00;
	[self addChild:redFlower];
	
	//风车加载
	windmill = [CCSprite spriteWithSpriteFrameName:@"Windmill2.png"];
	windmill.position = ccp(74.00,758.00);
	[self addChild:windmill];
	
	//橡皮加载
	CCSprite* eraser = [CCSprite spriteWithSpriteFrameName:@"Eraser.png"];
	eraser.position = ccp(634.00,435.00);
	eraser.rotation = -115.00;
	[self addChild:eraser];
	
	//铅笔加载
	CCSprite*penOnly = [CCSprite spriteWithSpriteFrameName:@"PenOnly.png"];
	penOnly.position = ccp(577.00,764.00);
	penOnly.rotation = -40.00;
	[self addChild:penOnly];
	
	//时钟加载
	CCSprite* clock = [CCSprite spriteWithSpriteFrameName:@"Clock.png"];
	clock.position = ccp(702.00,105.00);
	clock.rotation = -115.00;
	[self addChild:clock];
	
	//时钟Label初始化加载
	doubleModeCornerClockLabel = [CCLabelTTF labelWithString:@"0:00" 
									fontName:@"FZKaTong-M19S" 
									fontSize:42];
	
	doubleModeCornerClockLabel.position = ccp(700.00,109.00);
	doubleModeCornerClockLabel.rotation = -115;
	[self addChild:doubleModeCornerClockLabel];
	
	
	//返回主菜单按钮
	CCMenuItemSprite* goToMainSceneMenuItem = [CCMenuItemImage itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"GoToMainSceneNormalImage.png"]
											     selectedSprite:[CCSprite spriteWithSpriteFrameName:@"GoToMainSceneSelectedImage.png"]
													 target:self
												     selector:@selector(gotoMainMenuScene)];
	
	//游戏运行状态按钮
	gamePauseMenuItem = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"GamePauseNormal.png"]
								  selectedSprite:[CCSprite spriteWithSpriteFrameName:@"GamePauseSelected.png"]];
	
	gameResumeMenuItem = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"GameResumeNormal.png"]
								   selectedSprite:[CCSprite spriteWithSpriteFrameName:@"GameResumeSelected.png"]];
	
	gameStateChange = [CCMenuItemToggle itemWithTarget:self 
								selector:@selector(gameRunStateChange)
								   items:gamePauseMenuItem,gameResumeMenuItem,nil];
	
	//游戏音乐状态按钮
	gameMusicPlayMenuItem = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"SoundOnNormal.png"]
									selectedSprite:[CCSprite spriteWithSpriteFrameName:@"SoundOnSelected.png"]];
	
	gameMusicStopMenuItem = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"SoundOffNormal.png"]
									selectedSprite:[CCSprite spriteWithSpriteFrameName:@"SoundOffSelected.png"]];
	if ([MusicSwitch shareConfig].gameSoundState) 
	{
		gameMusicStateChange = [CCMenuItemToggle itemWithTarget:playGameMusic
									     selector:@selector(gameSoundStateChangeOn)
										  items:gameMusicPlayMenuItem,gameMusicStopMenuItem,nil];
	}
	else 
	{
		gameMusicStateChange = [CCMenuItemToggle itemWithTarget:playGameMusic
									     selector:@selector(gameSoundStateChangeOff)
										  items:gameMusicStopMenuItem,gameMusicPlayMenuItem,nil];
	}
	goToMainSceneMenuItem.rotation = -90;
	
	gameStateChange.rotation = -90;
	[gameStateChange setOpacity:0];
	gameStateChange.isEnabled = NO;
	
	gameMusicStateChange.rotation = -90;
	CCMenu* UIMainMenu = [CCMenu menuWithItems:goToMainSceneMenuItem,gameStateChange,gameMusicStateChange,nil];
	[UIMainMenu alignItemsVerticallyWithPadding:70];
	UIMainMenu.position = ccp(72,384);
	[self addChild:UIMainMenu];
	
	//黑板初始化加载
	blackboard = [CCSprite spriteWithSpriteFrameName:@"Blackboard.png"];
	blackboard.position = ccp(400.00,384.00);
	blackboard.scale = 0; 
	blackboard.rotation = -90.00;
	[self addChild:blackboard];
	
	//识别图片初始化
	doubleModeIdentifyPicture = [CCSprite spriteWithSpriteFrameName:@"Things-Apple.png"];
	doubleModeIdentifyPicture.position = ccp(400,384);
	doubleModeIdentifyPicture.scale = 0;
	[self addChild:doubleModeIdentifyPicture z:2];
	
	//游戏开始按钮加载
	playGameMenuItem = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"GameStartNormal.png"]
								 selectedSprite:[CCSprite spriteWithSpriteFrameName:@"GameStartSelected.png"]
									   target:self 
									 selector:@selector(gameReady)];
	playGameMenuItem.rotation = -90;
	playGameMenu = [CCMenu menuWithItems:playGameMenuItem, nil];
	[playGameMenu setOpacity:0];
	[playGameMenu setIsTouchEnabled:NO];
	playGameMenu.position = ccp(winSize.width*0.5,winSize.height*0.5);
	[self addChild:playGameMenu];
	
	//玩家选项控制面板加载
	controlPanel = [DoubleModeControlPanelUI node];
	controlPanel.position = ccp(winSize.width+315.50,winSize.height*0.5);
	[controlPanel_upHalf setIsTouchEnabled:NO];
	[self addChild:controlPanel];
	
	//积分小花加载
	controlPanelYellowFlower = [CCSprite spriteWithSpriteFrameName:@"RightFlower-Yellow.png"];
	controlPanelYellowFlower.anchorPoint = ccp(0.5,1);
	controlPanelYellowFlower.scale = 0;
	controlPanelYellowFlower.rotation = 15;
	controlPanelYellowFlower.position = ccp(996,298);
	[self addChild:controlPanelYellowFlower];
	
	controlPanelRedFlower = [CCSprite spriteWithSpriteFrameName:@"Flower-Red.png"];
	controlPanelRedFlower.anchorPoint = ccp(1,0.3);
	controlPanelRedFlower.scale = 0;
	controlPanelRedFlower.rotation = -55;
	controlPanelRedFlower.position = ccp(972,343);
	[self addChild:controlPanelRedFlower];
	
	controlPanelGreenFlower = [CCSprite spriteWithSpriteFrameName:@"RightFlower-Green.png"];
	controlPanelGreenFlower.anchorPoint = ccp(1, 0.65);
	controlPanelGreenFlower.scale = 0;
	controlPanelGreenFlower.rotation = 15;
	controlPanelGreenFlower.position = ccp(939,386);
	[self addChild:controlPanelGreenFlower];
	
	controlPanelBlueFlower = [CCSprite spriteWithSpriteFrameName:@"RightFlower-Blue.png"];
	controlPanelBlueFlower.anchorPoint = ccp(1, 0.3);
	controlPanelBlueFlower.scale = 0;
	controlPanelBlueFlower.rotation = 10;
	controlPanelBlueFlower.position = ccp(977,432);
	[self addChild:controlPanelBlueFlower];
	
	controlPanelPinkFlower = [CCSprite spriteWithSpriteFrameName:@"RightFlower-Pink.png"];
	controlPanelPinkFlower.anchorPoint = ccp(0.7, 0);
	controlPanelPinkFlower.scale = 0;
	controlPanelPinkFlower.rotation = 5;
	controlPanelPinkFlower.position = ccp(1005,452);
	[self addChild:controlPanelPinkFlower];
	

	
	//分数背景加载
	bigCircularScore = [CCSprite spriteWithSpriteFrameName:@"BigCircularScore.png"];
	bigCircularScore.position = ccp(winSize.width+315.50,376.00);
	[self addChild:bigCircularScore];
	
	//答对选项累计Label
	scoreLabel = [CCLabelTTF labelWithString:[NSString stringWithFormat:@"%d/%d",0,0] fontName:@"FZKaTong-M19S" fontSize:48];
	scoreLabel.rotation = -90.00;
	scoreLabel.position = ccp(1315.50,378.00);
	[self addChild:scoreLabel];
	
	readyLabelOne = [CCSprite spriteWithSpriteFrameName:@"One.png"];
	readyLabelOne.position = ccp(winSize.width*0.5,winSize.height*0.5);
	readyLabelOne.opacity = 0;
	readyLabelOne.rotation = -90.00;
	[self addChild:readyLabelOne];
	
	readyLabelTwo = [CCSprite spriteWithSpriteFrameName:@"Two.png"];
	readyLabelTwo.position = ccp(winSize.width*0.5,winSize.height*0.5);
	readyLabelTwo.opacity = 0;
	readyLabelTwo.rotation = -90.00;
	[self addChild:readyLabelTwo];
	
	readyLabelThree = [CCSprite spriteWithSpriteFrameName:@"Three.png"];
	readyLabelThree.position = ccp(winSize.width*0.5,winSize.height*0.5);
	readyLabelThree.opacity = 0;
	readyLabelThree.rotation = -90;
	[self addChild:readyLabelThree];
	
	//信息框
	doubleModePopInfolayer = [PopInfoLayer node];
	doubleModePopInfolayer.position = ccp(512,384);
	doubleModePopInfolayer.scale = 0;
	doubleModePopInfolayer.rotation = -90;
	[self addChild:doubleModePopInfolayer z:3];
}

-(void)gotoMainMenuScene
{
	[playGameMusic gameMenuClickSound];
	doubleModePauseState = NO;
	[[CCDirector sharedDirector] replaceScene: [CCTransitionFade transitionWithDuration:1.6f 
														scene:[MainMenuScene scene] 
													  withColor:ccBLACK]];
}

-(void)gameRunStateChange
{
	[playGameMusic gameMenuClickSound];
	doubleModePauseState = YES;
	[self show];
}

-(void)gameReady
{
	[playGameMusic gameMenuClickSound];
	controlPanelYellowFlower.scale = 0;
	controlPanelRedFlower.scale = 0;
	controlPanelGreenFlower.scale = 0;
	controlPanelBlueFlower.scale = 0;
	controlPanelPinkFlower.scale = 0;
	//游戏开始按钮消退动画
	[playGameMenu setIsTouchEnabled:NO];
	[playGameMenu stopAllActions];
	id playGameMenuFadeOut = [CCFadeOut actionWithDuration:0.5];
	[playGameMenu runAction:playGameMenuFadeOut];
	[self readyTime];
}

-(void)timeDown1Sound
{
	[playGameMusic timeDown1Sound];
}

-(void)timeDown2Sound
{
	[playGameMusic timeDown2Sound];
}

-(void)readyTime
{
	trueOptionCount = 0;
	//关卡信息读取
	switch (roundCount)
	{
		case kRoundCountOne:
			doubleSceneTime = kRoundOneTime;
			[doubleModeCornerClockLabel setString:[NSString stringWithFormat:@"0:%02d",kRoundOneTime]];
			doubleSceneRoundCount = kRoundOneQuestionCount;
			[scoreLabel setString:[NSString stringWithFormat:@"%d/%d",0,kRoundOneQuestionCount]];
			break;
		case kRoundCountTwo:
			doubleSceneTime = kRoundTwoTime;
			[doubleModeCornerClockLabel setString:[NSString stringWithFormat:@"0:%02d",kRoundTwoTime]];
			doubleSceneRoundCount = kRoundTwoQuestionCount;
			[scoreLabel setString:[NSString stringWithFormat:@"%d/%d",0,kRoundTwoQuestionCount]];
			break;
		case kRoundCountThree:
			doubleSceneTime = kRoundThreeTime;
			[doubleModeCornerClockLabel setString:[NSString stringWithFormat:@"0:%02d",kRoundThreeTime]];
			doubleSceneRoundCount = kRoundThreeQuestionCount;
			[scoreLabel setString:[NSString stringWithFormat:@"%d/%d",0,kRoundThreeQuestionCount]];
			break;
		case kRoundCountFour:
			doubleSceneTime = kRoundFourTime;
			[doubleModeCornerClockLabel setString:[NSString stringWithFormat:@"0:%02d",kRoundFourTime]];
			doubleSceneRoundCount = kRoundFourQuestionCount;
			[scoreLabel setString:[NSString stringWithFormat:@"%d/%d",0,kRoundFourQuestionCount]];
			break;
		case kRoundCountFive:
			doubleSceneTime = kRoundFiveTime;
			[doubleModeCornerClockLabel setString:[NSString stringWithFormat:@"0:%02d",kRoundFiveTime]];
			doubleSceneRoundCount = kRoundFiveQuestionCount;
			[scoreLabel setString:[NSString stringWithFormat:@"%d/%d",0,kRoundFiveQuestionCount]];
			break;
		default:
			break;
	}
	
	readyLabelThree.opacity = 0;
	readyLabelTwo.opacity = 0;
	readyLabelOne.opacity = 0;
	
	id readyLabelThreeSound = [CCCallFunc actionWithTarget:self selector:@selector(timeDown2Sound)];
	id readyLabelThreeOpacityIn = [CCFadeIn actionWithDuration:0.01];
	id readyLabelThreeOpacityOut = [CCFadeOut actionWithDuration:0.01];
	id readyLabelThreeAction = [CCSequence actions:readyLabelThreeOpacityIn,readyLabelThreeSound,[CCDelayTime actionWithDuration:1.0],readyLabelThreeOpacityOut,nil];
	[readyLabelThree runAction:[CCSequence actions:[CCDelayTime actionWithDuration:0.5],readyLabelThreeAction,nil]];
	
	id readyLabelTwoSound = [CCCallFunc actionWithTarget:self selector:@selector(timeDown2Sound)];
	id readyLabelTwoOpacityIn = [CCFadeIn actionWithDuration:0.01];
	id readyLabelTwoOpacityOut = [CCFadeOut actionWithDuration:0.01];
	id readyLabelTwoAction = [CCSequence actions:readyLabelTwoOpacityIn,readyLabelTwoSound,[CCDelayTime actionWithDuration:1.0],readyLabelTwoOpacityOut,nil];
	[readyLabelTwo runAction:[CCSequence actions:[CCDelayTime actionWithDuration:1.5],readyLabelTwoAction,nil]];
	
	id readyLabelOneSound = [CCCallFunc actionWithTarget:self selector:@selector(timeDown1Sound)];
	id readyLabelOneOpacityIn = [CCFadeIn actionWithDuration:0.01];
	id readyLabelOneOpacityOut = [CCFadeOut actionWithDuration:0.01];
	id readyLabelOneAction = [CCSequence actions:readyLabelOneOpacityIn,readyLabelOneSound,[CCDelayTime actionWithDuration:1.0],readyLabelOneOpacityOut,nil];
	id gameStartCallFun = [CCCallFunc actionWithTarget:self selector:@selector(gameStart)];
	[readyLabelOne runAction:[CCSequence actions:[CCDelayTime actionWithDuration:2.5],readyLabelOneAction,[CCDelayTime actionWithDuration:0.2],gameStartCallFun,nil]];
}

-(void)gotoNextRound
{
	[self unschedule:@selector(timer)];
	id gamePauseMenuFadeOut = [CCFadeOut actionWithDuration:0.5];
	id gamePauseMenuEnableChange = [CCCallFunc actionWithTarget:self selector:@selector(gamePauseMenuEnableChangeFun2)];
	id gamePauseMenuAction = [CCSequence actions:gamePauseMenuEnableChange,gamePauseMenuFadeOut,nil];
	[gameStateChange runAction:gamePauseMenuAction];
	
	[controlPanel_upHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
	[controlPanel_upHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
	[controlPanel_upHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
	[controlPanel_upHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
	[controlPanel_downHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
	[controlPanel_downHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
	[controlPanel_downHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
	[controlPanel_downHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
	[controlPanel_upHalfMenuItem1 setIsEnabled:NO];
	[controlPanel_upHalfMenuItem2 setIsEnabled:NO];
	[controlPanel_upHalfMenuItem3 setIsEnabled:NO];
	[controlPanel_upHalfMenuItem4 setIsEnabled:NO];
	[controlPanel_downHalfMenuItem1 setIsEnabled:NO];
	[controlPanel_downHalfMenuItem2 setIsEnabled:NO];
	[controlPanel_downHalfMenuItem3 setIsEnabled:NO];
	[controlPanel_downHalfMenuItem4 setIsEnabled:NO];
	
//	NSLog(@"%@",[NSThread callStackSymbols]);
	id doubleModeIdentifyPictureToSmall = [CCScaleTo actionWithDuration:1.0f scale:0];
	id doubleModeIdentifyPictureUnUpdate = [CCCallFunc actionWithTarget:self selector:@selector(gotoDefaultRound)];
	[doubleModeIdentifyPicture runAction:[CCSequence actions:doubleModeIdentifyPictureToSmall,doubleModeIdentifyPictureUnUpdate, nil]];
	
	id controlPanelRotate = [CCRotateBy actionWithDuration:1.0 angle:180];
	id upHideChange = [CCCallFunc actionWithTarget:self selector:@selector(upHideChangeFun)];
	id controlPanelEmpty = [CCCallFunc actionWithTarget:self selector:@selector(controlPanelToEmpty)];
	id controlPanelActionSequence = [CCSequence actions:controlPanelEmpty,upHideChange,controlPanelRotate,nil];
	[controlPanel runAction:controlPanelActionSequence];
	
	CCSprite* flower = nil;
	switch (roundCount)
	{
		case kRoundCountOne:
			flower = controlPanelYellowFlower;
			break;
		case kRoundCountTwo:
			flower = controlPanelRedFlower;
			break;
		case kRoundCountThree:
			flower = controlPanelGreenFlower;
			break;
		case kRoundCountFour:
			flower = controlPanelBlueFlower;
			break;
		case kRoundCountFive:
			flower = controlPanelPinkFlower;
			break;
		default:
			break;
	}
	id action1 = [CCScaleTo actionWithDuration:0.2 scale:1.5];
	id action2 = [CCScaleTo actionWithDuration:0.1 scale:1.0];
	id action3 = [CCSequence actions:action1,action2,nil];
	[flower runAction:action3];
	controlPanelParticle = [ARCH_OPTIMAL_PARTICLE_SYSTEM particleWithFile:@"DoubleModeParticle.plist"];
	controlPanelParticle.position = ccp(winSize.width+64 , winSize.height*0.5);
	controlPanelParticle.autoRemoveOnFinish=YES;
	controlPanelParticle.rotation = -90;
	[self addChild:controlPanelParticle];
	
	if (roundCount<kRoundCountFive)
	{
		++roundCount;
		id popInfoScaleToLarge = [CCScaleTo actionWithDuration:0.6 scale:1.2];
		id popInfoScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
		id popInfoDelayTime = [CCDelayTime actionWithDuration:1.0];
		id popInfoEndisableScale = [CCScaleTo actionWithDuration:0.6 scale:0];
		id gotoNextRound = [CCCallFunc actionWithTarget:self selector:@selector(readyTime)];
		id popInfoSequence = [CCSequence actions:popInfoScaleToLarge,popInfoScaleToSmall,popInfoDelayTime,popInfoEndisableScale,gotoNextRound,nil];
		CCSprite* popInfoLayerInfo = (CCSprite*)[doubleModePopInfolayer getChildByTag:kFrameInfo];
		[popInfoLayerInfo setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"Clever.png"]];
		[doubleModePopInfolayer runAction:popInfoSequence];
	}
	else 
	{
		roundCount = kRoundCountOne;
		id popInfoScaleToLarge = [CCScaleTo actionWithDuration:0.6 scale:1.2];
		id popInfoScaleToSmall = [CCScaleTo actionWithDuration:0.2 scale:1.0];
		id popInfoDelayTime = [CCDelayTime actionWithDuration:1.0];
		id popInfoEndisableScale = [CCScaleTo actionWithDuration:0.6 scale:0];
		id gotoNextRound = [CCCallFunc actionWithTarget:self selector:@selector(playGameMenuFadeAnimation)];
		id popInfoSequence = [CCSequence actions:popInfoScaleToLarge,popInfoScaleToSmall,popInfoDelayTime,popInfoEndisableScale,gotoNextRound,nil];
		CCSprite* popInfoLayerInfo = (CCSprite*)[doubleModePopInfolayer getChildByTag:kFrameInfo];
		[popInfoLayerInfo setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"Good.png"]];
		[doubleModePopInfolayer runAction:popInfoSequence];
	}

}

-(void)gotoDefaultRound
{
	[self unscheduleUpdate];
}

-(void)controlPanelCanTouchChangeFun
{
	upHide
	?[controlPanel_upHalf setIsTouchEnabled:YES]
	:[controlPanel_downHalf setIsTouchEnabled:YES];
}

-(void)upHideChangeFun
{
	if (upHide)
		upHide = NO;
	else
		upHide = YES;
}

-(void)identifyPictureSoundFun
{
	[playGameMusic thingsRotateInSound];
}

-(void)gameStart
{
	[doubleModeControlPanelLogic controlPanelLabelInit];
	doubleModeAttenuation = 120.0f;
	
	id controlPanelRotate = [CCRotateBy actionWithDuration:0.5 angle:180];
	id controlPanelCanTouchChange = [CCCallFunc actionWithTarget:self selector:@selector(controlPanelCanTouchChangeFun)];
	id upHideChange = [CCCallFunc actionWithTarget:self selector:@selector(upHideChangeFun)];
	id controlPanelActionSequence = [CCSequence actions:controlPanelCanTouchChange,upHideChange,controlPanelRotate,nil];
	[controlPanel runAction:controlPanelActionSequence];
	
	//识别图片旋转启动
	[self scheduleUpdate];
	
	//识别图片动画
	id identifyPictureScaleToLarge = [CCScaleTo actionWithDuration:1.0 scale:1.4];
	id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:0.4 scale:1.0];
	id identifyPictureSound = [CCCallFunc actionWithTarget:self selector:@selector(identifyPictureSoundFun)];
	id identifyPictureSequence = [CCSequence actions:identifyPictureSound,identifyPictureScaleToLarge,identifyPictureScaleToSmall, nil];
	[doubleModeIdentifyPicture runAction:identifyPictureSequence];
	
	//计时器启动
	[self schedule:@selector(timer) interval:1.0];
	
	//游戏暂停按钮进场动画
	id gamePauseMenuFadeIn = [CCFadeIn actionWithDuration:0.5];
	id gamePauseMenuEnableChange = [CCCallFunc actionWithTarget:self selector:@selector(gamePauseMenuEnableChangeFun1)];
	id gamePauseMenuAction = [CCSequence actions:gamePauseMenuEnableChange,gamePauseMenuFadeIn,nil];
	[gameStateChange runAction:gamePauseMenuAction];
}

-(void)gamePauseMenuEnableChangeFun1
{
	gameStateChange.isEnabled = YES;
}

-(void)gamePauseMenuEnableChangeFun2
{
	gameStateChange.isEnabled = NO;
}

-(void)timer
{
	--doubleSceneTime;
	if (doubleSceneTime>=0) 
	{
		if (doubleSceneTime<=4)
		{
			[playGameMusic finalFiveSecondSound];
		}
		[doubleModeCornerClockLabel setString:[NSString stringWithFormat:@"0:%02d",doubleSceneTime]];
	}
	else 
	{
		//游戏暂停按钮退场动画
		id gamePauseMenuFadeOut = [CCFadeOut actionWithDuration:0.5];
		id gamePauseMenuEnableChange = [CCCallFunc actionWithTarget:self selector:@selector(gamePauseMenuEnableChangeFun2)];
		id gamePauseMenuAction = [CCSequence actions:gamePauseMenuEnableChange,gamePauseMenuFadeOut,nil];
		[gameStateChange runAction:gamePauseMenuAction];
		
		//计时器停止
		[self unschedule:@selector(timer)];
		
		//识别图片缩小
		id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:1.0 scale:0];
		id defaultRound = [CCCallFunc actionWithTarget:self selector:@selector(gotoDefaultRound)];
		[doubleModeIdentifyPicture runAction:[CCSequence actions:identifyPictureScaleToSmall,defaultRound,nil]];
		
		[controlPanel_upHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
		[controlPanel_upHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
		[controlPanel_upHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
		[controlPanel_upHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
		[controlPanel_downHalfMenuItem1 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
		[controlPanel_downHalfMenuItem2 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
		[controlPanel_downHalfMenuItem3 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
		[controlPanel_downHalfMenuItem4 setDisabledImage:[CCSprite spriteWithSpriteFrameName:@"BigCircularNormal.png"]];
		[controlPanel_upHalfMenuItem1 setIsEnabled:NO];
		[controlPanel_upHalfMenuItem2 setIsEnabled:NO];
		[controlPanel_upHalfMenuItem3 setIsEnabled:NO];
		[controlPanel_upHalfMenuItem4 setIsEnabled:NO];
		[controlPanel_downHalfMenuItem1 setIsEnabled:NO];
		[controlPanel_downHalfMenuItem2 setIsEnabled:NO];
		[controlPanel_downHalfMenuItem3 setIsEnabled:NO];
		[controlPanel_downHalfMenuItem4 setIsEnabled:NO];
		
		id controlPanelRotate = [CCRotateBy actionWithDuration:1.0 angle:180];
		
		id upHideChange = [CCCallFunc actionWithTarget:self selector:@selector(upHideChangeFun)];
		
		id controlPanelEmpty = [CCCallFunc actionWithTarget:self selector:@selector(controlPanelToEmpty)];
		
		id controlPanelActionSequence = [CCSequence actions:controlPanelEmpty,upHideChange,controlPanelRotate,nil];
		if (![controlPanel numberOfRunningActions])
		{
			[controlPanel runAction:controlPanelActionSequence];
		}
		else 
		{
			[self schedule:@selector(frameTestPanelActionStop)];
		}
		roundCount = 0;
		trueOptionCount = 0;
		[self playGameMenuFadeAnimation];
	}
}

-(void)controlPanelToEmpty
{
	if(upHide)
	{
		[controlPanel_upHalfLabel1 setString:@""];
		[controlPanel_upHalfLabel2 setString:@""];
		[controlPanel_upHalfLabel3 setString:@""];
		[controlPanel_upHalfLabel4 setString:@""];
	}
	else 
	{
		[controlPanel_downHalfLabel1 setString:@""];
		[controlPanel_downHalfLabel2 setString:@""];
		[controlPanel_downHalfLabel3 setString:@""];
		[controlPanel_downHalfLabel4 setString:@""];
	}
	
}

-(void)frameTestPanelActionStop
{
	if([controlPanel numberOfRunningActions]==0)
	{
		[self unschedule:@selector(frameTestPanelActionStop)];
		id controlPanelRotate = [CCRotateBy actionWithDuration:0.5 angle:180];
		id upHideChange = [CCCallFunc actionWithTarget:self selector:@selector(upHideChangeFun)];
		id controlPanelEmpty = [CCCallFunc actionWithTarget:self selector:@selector(controlPanelToEmpty)];
		
		id controlPanelActionSequence = [CCSequence actions:controlPanelEmpty,upHideChange,controlPanelRotate,nil];
		[controlPanel runAction:controlPanelActionSequence];
		
		id identifyPictureScaleToSmall = [CCScaleTo actionWithDuration:1.0 scale:0];
		id nextRoundReadyAction = [CCSequence actions:identifyPictureScaleToSmall,nil];
		[doubleModeIdentifyPicture runAction:nextRoundReadyAction];
	}
}

- (void)update:(ccTime)delta
{
	if (doubleModeAttenuation>2) 
	{
		doubleModeIdentifyPicture.rotation += doubleModeAttenuation;
		doubleModeAttenuation *= 0.99f;
	}
	else
		doubleModeIdentifyPicture.rotation += 2;
}

-(void)playGameMenuIsTouchEnabledChangeFun
{
	[playGameMenu setIsTouchEnabled:YES];
}

//开始按钮进场动画附属回调方法
-(void)playGameMenuFadeAnimation
{
	[playGameMenu setIsTouchEnabled:YES];
	id playGameMenuFadeIn = [CCFadeIn actionWithDuration:1.0];
	id playGameMenuAction = [CCSequence actions:[CCDelayTime actionWithDuration:1.0],playGameMenuFadeIn,nil];
	[playGameMenu runAction:playGameMenuAction];
}

-(void)show
{
	CCRenderTexture* renderTexture = [CCRenderTexture renderTextureWithWidth:winSize.width height:winSize.height];        
	[renderTexture begin];
	[self visit];
	[renderTexture end];
	[renderTexture setPosition:ccp(winSize.width*0.5, winSize.height*0.5)];        
	CCScene* pauseScene = [CCScene node];
	CCLayerColor* colorLayer = [CCLayerColor layerWithColor:ccc4(0, 0, 0, 200)];
	[pauseScene addChild:renderTexture];
	[pauseScene addChild:colorLayer z:1 tag:1];
	[pauseScene addChild:[DoubleModeGamePauseScene scene] z:2 tag:2];
	[[CCDirector sharedDirector] pushScene:pauseScene];
}

-(void) onEnterTransitionDidFinish
{	
	if(!doubleModePauseState)
		[self playGameSceneUIAnimation];
	else 
		[gameStateChange setSelectedIndex:0];
	
	[super onEnterTransitionDidFinish];
}

-(void)playGameSceneUIAnimation
{
	//黑板进场动画
	id blackboardRotateIntoScreen = [CCRotateTo actionWithDuration:1.0 angle:990];
	id blackboardScale = [CCScaleTo actionWithDuration:1.0 scale:1.0];
	id blackboardAction = [CCSpawn actions:blackboardRotateIntoScreen,blackboardScale,nil];
	[blackboard runAction:blackboardAction];
	
	//控制面板进场动画
	id controlPanelDelay = [CCDelayTime actionWithDuration:1.0];
	id controlPanelIntoScreen = [CCMoveTo actionWithDuration:1.0 position:ccp(winSize.width,winSize.height*0.5)];
	id controlPanelAction = [CCSequence actions:controlPanelDelay,controlPanelIntoScreen,nil];
	[controlPanel runAction:controlPanelAction];
	
	//玩家计分圆环进场动画
	id bigCircularScoreDelay = [CCDelayTime actionWithDuration:1.0];
	id bigCircularScoreIntoScreen = [CCMoveTo actionWithDuration:1.0 position:ccp(winSize.width,winSize.height*0.5-8)];
	id bigCircularScoreAction = [CCSequence actions:bigCircularScoreDelay,bigCircularScoreIntoScreen,nil];
	[bigCircularScore runAction:bigCircularScoreAction];
	
	//玩家计分Label进场动画
	id scoreLabelDelay = [CCDelayTime actionWithDuration:1.0];
	id scoreLabelIntoScreen = [CCMoveTo actionWithDuration:1.0 position:ccp(1000,378)];
	id scoreLabelAction = [CCSequence actions:scoreLabelDelay,scoreLabelIntoScreen,nil];
	[scoreLabel runAction:scoreLabelAction];
	
	//开始按钮进场动画
	id playGameMenuDelayTime1 = [CCDelayTime actionWithDuration:2.0];
	id playGameMenuIsTouchEnabledChange = [CCCallFunc actionWithTarget:self selector:@selector(playGameMenuIsTouchEnabledChangeFun)];
	id playGameMenuFadeInitIn = [CCFadeIn actionWithDuration:1.0];
	id playGameMenuAction = [CCSequence actions:playGameMenuDelayTime1,playGameMenuIsTouchEnabledChange,playGameMenuFadeInitIn,nil];
	[playGameMenu runAction:playGameMenuAction];
}

- (void) dealloc
{
	[super dealloc];
}

@end
