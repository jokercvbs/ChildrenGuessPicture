//
//  MainMenuScene.h
//  ChildIdentifyPicture
//
//  Created by the9_15 on 12-2-20.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "PlayGameScene.h"
#import "DoubleModePlayGameScene.h"

@class PlayGameMusic;
PlayGameMusic* playGameMusic;

@interface MainMenuScene : CCLayer 
{
	CGSize winSize;
	CCSprite* cloudBlue;
	CCSprite* cloudWhite;
	CCSprite* title;
	CCSprite* star;
	CCSprite* shine;
	CCMenu* mainMenu;
	CCSprite* whale;
	CCSprite* elephant;
	CCSprite* blackboardCorner;
	CCSprite* pen;
	CCSprite* windmill;
	CCMenuItem *singleModeMenu;
	CCMenuItem* doubleModeMenu;
}
+(CCScene *) scene;
-(void)sceneAnimation;
@end
