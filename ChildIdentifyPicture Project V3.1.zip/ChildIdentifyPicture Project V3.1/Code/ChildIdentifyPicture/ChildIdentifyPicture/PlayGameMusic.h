//
//  PlayGameMusic.h
//  ChildIdentifyPicture
//
//  Created by the9_15 on 12-3-5.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "SimpleAudioEngine.h"
#import "CDXPropertyModifierAction.h"
#import "MusicSwitch.h"

ALuint gameBG;
ALuint cloudMoveSound;
ALuint titleMoveSound;
ALuint thingsRotateIn;
ALuint chooseTrueSound;
ALuint chooseFalseSound;
ALuint finalFiveSecondSound;
ALuint gameStartSound;
ALuint infoLayerSound;
ALuint starSound;
ALuint timeDown1Sound;
ALuint timeDown2Sound;
SimpleAudioEngine *audioEngine;

@interface PlayGameMusic : CCNode 
{
    
}

-(void)thingsRotateInSound;
-(void)cloudMoveSound;
-(void)titleMoveSound;
-(void)thingsRotateInSound;
-(void)gameBGSoundStateChange;
-(void)gameSoundStateChangeOn;
-(void)chooseTrueSound;
-(void)chooseFalseSound;
-(void)finalFiveSecondSound;
-(void)gameMenuClickSound;
-(void)infoLayerSound;
-(void)starSound;
-(void)timeDown1Sound;
-(void)timeDown2Sound;
@end
