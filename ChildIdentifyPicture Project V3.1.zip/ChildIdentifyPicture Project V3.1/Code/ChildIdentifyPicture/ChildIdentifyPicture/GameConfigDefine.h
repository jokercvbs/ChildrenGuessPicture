//
//  untitled.h
//  ChildIdentifyPicture
//
//  Created by the9_15 on 12-3-9.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

//图片信息量
#define INFO_COUNT 80

//左右控制面板Label字体大小
#define LABEL_FONT_SIZE 36
#define Big_LABEL_FONT_SIZE 48

//每回合的时间
#define ROUND_TIME 60

//菜单判断选项
enum  
{
	kOptionA,
	kOptionB,
	kOptionC,
	kOptionD,
};